package com.bookstore.monolithic.dto;

import java.math.BigDecimal;

public class OrderItemDTO {
    private Long productId;
    private String productTitle;
    private String productAuthor;
    private String productImageUrl;
    private Integer count;
    private BigDecimal price;
    private BigDecimal subtotal;
    private Integer orderType;

    // getters and setters
    public Long getProductId() { return productId; }
    public void setProductId(Long productId) { this.productId = productId; }
    public String getProductTitle() { return productTitle; }
    public void setProductTitle(String productTitle) { this.productTitle = productTitle; }
    public String getProductAuthor() { return productAuthor; }
    public void setProductAuthor(String productAuthor) { this.productAuthor = productAuthor; }
    public String getProductImageUrl() { return productImageUrl; }
    public void setProductImageUrl(String productImageUrl) { this.productImageUrl = productImageUrl; }
    public Integer getCount() { return count; }
    public void setCount(Integer count) { this.count = count; }
    public BigDecimal getPrice() { return price; }
    public void setPrice(BigDecimal price) { this.price = price; }
    public BigDecimal getSubtotal() { return subtotal; }
    public void setSubtotal(BigDecimal subtotal) { this.subtotal = subtotal; }
    public Integer getOrderType() { return orderType; }
    public void setOrderType(Integer orderType) { this.orderType = orderType; }
}