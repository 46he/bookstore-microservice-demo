package com.bookstore.monolithic.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.bookstore.monolithic.dto.CartItemDTO;
import com.bookstore.monolithic.entity.Book;
import com.bookstore.monolithic.entity.Cart;
import com.bookstore.monolithic.mapper.CartMapper;
import com.bookstore.monolithic.service.BookService;
import com.bookstore.monolithic.service.CartService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class CartServiceImpl implements CartService {

    @Autowired
    private CartMapper cartMapper;
    @Autowired
    private BookService bookService;

    @Override
    @Transactional
    public void addToCart(Long userId, Long bookId, Integer count) {
        Book book = bookService.getById(bookId);
        if (book == null) throw new RuntimeException("图书不存在");
        if (book.getType() == 2 && book.getStock() < count) {
            throw new RuntimeException("库存不足");
        }
        QueryWrapper<Cart> wrapper = new QueryWrapper<>();
        wrapper.eq("user_id", userId).eq("book_id", bookId);
        Cart existing = cartMapper.selectOne(wrapper);
        if (existing != null) {
            existing.setCount(existing.getCount() + count);
            existing.setUpdatedAt(LocalDateTime.now());
            updateCartBookInfo(existing, book);
            cartMapper.updateById(existing);
        } else {
            Cart cart = new Cart();
            cart.setUserId(userId);
            cart.setBookId(bookId);
            cart.setCount(count);
            cart.setCreatedAt(LocalDateTime.now());
            cart.setUpdatedAt(LocalDateTime.now());
            updateCartBookInfo(cart, book);
            cartMapper.insert(cart);
        }
    }

    private void updateCartBookInfo(Cart cart, Book book) {
        cart.setBookTitle(book.getTitle());
        cart.setBookAuthor(book.getAuthor());
        cart.setBookCategory(book.getCategory());
        cart.setBookImageUrl(book.getImageUrl());
        cart.setBookType(book.getType());
        cart.setBookPrice(book.getPrice() != null ? book.getPrice().multiply(new java.math.BigDecimal(100)).intValue() : 0);
        cart.setBookPointsPrice(book.getPointsPrice() != null ? book.getPointsPrice().intValue() : 0);
        cart.setBookStock(book.getStock());
    }

    @Override
    @Transactional
    public void removeFromCart(Long userId, Long bookId) {
        cartMapper.delete(new QueryWrapper<Cart>().eq("user_id", userId).eq("book_id", bookId));
    }

    @Override
    @Transactional
    public void updateCartItem(Long userId, Long bookId, Integer count) {
        QueryWrapper<Cart> wrapper = new QueryWrapper<>();
        wrapper.eq("user_id", userId).eq("book_id", bookId);
        Cart cart = cartMapper.selectOne(wrapper);
        if (cart != null) {
            if (cart.getBookType() == 2 && count > cart.getBookStock()) {
                throw new RuntimeException("库存不足");
            }
            cart.setCount(count);
            cart.setUpdatedAt(LocalDateTime.now());
            cartMapper.updateById(cart);
        }
    }

    @Override
    @Transactional
    public void clearCart(Long userId) {
        cartMapper.delete(new QueryWrapper<Cart>().eq("user_id", userId));
    }

    @Override
    public List<CartItemDTO> getCartItems(Long userId) {
        List<Cart> carts = cartMapper.selectList(new QueryWrapper<Cart>().eq("user_id", userId));
        return carts.stream().map(c -> {
            CartItemDTO dto = new CartItemDTO();
            dto.setId(c.getId());
            dto.setBookId(c.getBookId());
            dto.setBookTitle(c.getBookTitle());
            dto.setBookAuthor(c.getBookAuthor());
            dto.setBookCategory(c.getBookCategory());
            dto.setBookImageUrl(c.getBookImageUrl());
            dto.setBookType(c.getBookType());
            dto.setPrice(c.getBookPrice());
            dto.setPointsPrice(c.getBookPointsPrice());
            dto.setStock(c.getBookStock());
            dto.setCount(c.getCount());
            dto.setSubtotal(c.getBookPrice() * c.getCount());
            return dto;
        }).collect(Collectors.toList());
    }

    @Override
    public int getCartItemCount(Long userId) {
        return cartMapper.selectCount(new QueryWrapper<Cart>().eq("user_id", userId)).intValue();
    }

    @Override
    public List<CartItemDTO> validateCartItems(Long userId) {
        List<CartItemDTO> items = getCartItems(userId);
        return items.stream()
                .filter(item -> item.getBookType() == 1 || item.getCount() <= item.getStock())
                .collect(Collectors.toList());
    }
}