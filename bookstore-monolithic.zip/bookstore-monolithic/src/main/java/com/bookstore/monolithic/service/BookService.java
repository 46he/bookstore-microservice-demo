package com.bookstore.monolithic.service;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.service.IService;
import com.bookstore.monolithic.entity.Book;

public interface BookService extends IService<Book> {
    boolean deductStock(Long bookId, Integer count);
    boolean addStock(Long bookId, Integer count);
    boolean updateImageUrl(Long bookId, String imageUrl);
    IPage<Book> searchBooks(Integer pageNum, Integer pageSize, String keyword);
}