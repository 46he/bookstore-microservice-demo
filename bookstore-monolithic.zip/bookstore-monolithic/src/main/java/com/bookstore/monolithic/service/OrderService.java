package com.bookstore.monolithic.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.bookstore.monolithic.entity.Order;
import com.bookstore.monolithic.entity.OrderItem;
import java.math.BigDecimal;
import java.util.List;

public interface OrderService extends IService<Order> {
    Long createOrder(Long userId, List<OrderItem> items, BigDecimal pointsUsed,
                     Long addressId, Integer orderType, Long couponId, String idempotentToken);
    List<Order> getOrdersByUserId(Long userId);
    Order getOrderById(Long orderId);
    boolean payOrder(Long orderId);
    boolean cancelOrder(Long orderId);
}