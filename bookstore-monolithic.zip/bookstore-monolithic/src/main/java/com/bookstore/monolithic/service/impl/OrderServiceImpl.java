package com.bookstore.monolithic.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.bookstore.monolithic.entity.*;
import com.bookstore.monolithic.mapper.OrderItemMapper;
import com.bookstore.monolithic.mapper.OrderMapper;
import com.bookstore.monolithic.service.BookService;
import com.bookstore.monolithic.service.OrderService;
import com.bookstore.monolithic.service.UserService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.LocalDateTime;
import java.util.List;

@Service
public class OrderServiceImpl extends ServiceImpl<OrderMapper, Order> implements OrderService {
    private static final Logger log = LoggerFactory.getLogger(OrderServiceImpl.class);

    @Autowired
    private BookService bookService;
    @Autowired
    private OrderItemMapper orderItemMapper;
    @Autowired
    private UserService userService;

    // 去掉了 RedisTemplate 字段和幂等性检查

    @Override
    @Transactional
    public Long createOrder(Long userId, List<OrderItem> items, BigDecimal pointsUsed,
                            Long addressId, Integer orderType, Long couponId, String idempotentToken) {
        // 直接调用业务逻辑，不做任何 Redis 幂等检查（与微服务当前行为一致）
        return doCreateOrder(userId, items, pointsUsed, addressId, orderType, couponId);
    }

    private Long doCreateOrder(Long userId, List<OrderItem> items, BigDecimal pointsUsed,
                               Long addressId, Integer orderType, Long couponId) {
        if (items == null || items.isEmpty()) {
            throw new RuntimeException("订单商品不能为空");
        }

        // 1. 扣减库存并计算总金额
        BigDecimal totalAmount = BigDecimal.ZERO;
        for (OrderItem item : items) {
            Book book = bookService.getById(item.getBookId());
            if (book == null) throw new RuntimeException("商品不存在");
            if (book.getType() == 2 && book.getStock() < item.getCount()) {
                throw new RuntimeException("商品 " + book.getTitle() + " 库存不足");
            }
            boolean deducted = bookService.deductStock(item.getBookId(), item.getCount());
            if (!deducted) throw new RuntimeException("商品 " + book.getTitle() + " 扣减库存失败");
            totalAmount = totalAmount.add(item.getPrice().multiply(BigDecimal.valueOf(item.getCount())));
        }

        // 2. 获取用户等级折扣
        User user = userService.getById(userId);
        double levelRate = 0.0;
        if (user != null) {
            switch (user.getLevel()) {
                case 1 -> levelRate = 0.05;
                case 2 -> levelRate = 0.10;
                case 3 -> levelRate = 0.15;
            }
        }
        BigDecimal levelDiscount = totalAmount.multiply(BigDecimal.valueOf(levelRate));

        // 3. 优惠券折扣（简单处理，与微服务未使用优惠券保持一致）
        BigDecimal couponDiscount = BigDecimal.ZERO;

        // 4. 积分抵扣
        if (pointsUsed == null) pointsUsed = BigDecimal.ZERO;
        BigDecimal actualPaid = totalAmount.subtract(pointsUsed).subtract(couponDiscount).subtract(levelDiscount);
        if (actualPaid.compareTo(BigDecimal.ZERO) < 0) actualPaid = BigDecimal.ZERO;

        // 5. 扣减积分（如果使用积分）
        if (pointsUsed.compareTo(BigDecimal.ZERO) > 0) {
            if (user.getPoints().compareTo(pointsUsed) < 0) throw new RuntimeException("积分不足");
            user.setPoints(user.getPoints().subtract(pointsUsed));
            userService.updateById(user);
        }

        // 6. 获取卖家ID（取第一个商品的卖家）
        Long firstProductId = items.get(0).getBookId();
        Book firstBook = bookService.getById(firstProductId);
        Long sellerId = firstBook != null && firstBook.getSellerId() != null ? firstBook.getSellerId() : 0L;

        // 7. 创建订单主记录
        int totalCount = items.stream().mapToInt(OrderItem::getCount).sum();
        Order order = new Order();
        order.setUserId(userId);
        order.setProductId(firstProductId);
        order.setCount(totalCount);
        order.setAmount(totalAmount);
        order.setPointsUsed(pointsUsed);
        order.setCouponDiscount(couponDiscount);
        order.setLevelDiscount(levelDiscount);
        order.setActualPaid(actualPaid);
        order.setAddressId(addressId);
        order.setOrderType(orderType);
        order.setCouponId(couponId);
        order.setSellerId(sellerId);
        order.setStatus(Order.STATUS_PENDING);
        order.setDeliveryStatus(0);
        order.setCreateTime(LocalDateTime.now());
        this.save(order);
        Long orderId = order.getId();

        // 8. 保存订单项
        for (OrderItem item : items) {
            item.setOrderId(orderId);
            orderItemMapper.insert(item);
        }

        log.info("订单创建成功，orderId={}", orderId);
        return orderId;
    }

    // ========== 以下是您原有代码中必须保留的其他方法 ==========
    // 注意：这些方法中如果有使用 stringRedisTemplate 的，也需要注释掉。
    // 由于您没有提供完整的其他方法代码，我假设您原有的 getOrdersByUserId, payOrder, cancelOrder 等方法
    // 都没有使用 Redis。如果使用了，请自行注释掉相关行。

    @Override
    public List<Order> getOrdersByUserId(Long userId) {
        return this.list(new QueryWrapper<Order>().eq("user_id", userId).orderByDesc("create_time"));
    }

    @Override
    public Order getOrderById(Long orderId) {
        return this.getById(orderId);
    }

    @Override
    @Transactional
    public boolean payOrder(Long orderId) {
        Order order = this.getById(orderId);
        if (order == null || order.getStatus() != Order.STATUS_PENDING) return false;
        order.setStatus(Order.STATUS_PAID);
        if (order.getOrderType() == 1) {
            order.setDeliveryStatus(2);
            order.setReceivedAt(LocalDateTime.now());
            order.setStatus(Order.STATUS_COMPLETED);
        } else {
            order.setDeliveryStatus(0);
        }
        this.updateById(order);
        // 增加图书销量
        Book book = bookService.getById(order.getProductId());
        if (book != null) {
            book.setPurchaseCount((book.getPurchaseCount() == null ? 0 : book.getPurchaseCount()) + order.getCount());
            book.setSoldCount((book.getSoldCount() == null ? 0 : book.getSoldCount()) + order.getCount());
            bookService.updateById(book);
        }
        // 增加用户积分（实付金额/10）
        BigDecimal pointsEarned = order.getActualPaid().divide(BigDecimal.TEN, 1, RoundingMode.DOWN);
        if (pointsEarned.compareTo(BigDecimal.ZERO) > 0) {
            User user = userService.getById(order.getUserId());
            if (user != null) {
                user.setPoints(user.getPoints().add(pointsEarned));
                userService.updateById(user);
            }
        }
        // 增加消费累计
        userService.addConsumption(order.getUserId(), order.getActualPaid());
        log.info("支付成功，orderId={}", orderId);
        return true;
    }

    @Override
    @Transactional
    public boolean cancelOrder(Long orderId) {
        Order order = this.getById(orderId);
        if (order == null || order.getStatus() != Order.STATUS_PENDING) return false;
        // 恢复库存
        List<OrderItem> items = orderItemMapper.selectList(new QueryWrapper<OrderItem>().eq("order_id", orderId));
        for (OrderItem item : items) {
            bookService.addStock(item.getBookId(), item.getCount());
        }
        // 恢复积分
        if (order.getPointsUsed().compareTo(BigDecimal.ZERO) > 0) {
            User user = userService.getById(order.getUserId());
            if (user != null) {
                user.setPoints(user.getPoints().add(order.getPointsUsed()));
                userService.updateById(user);
            }
        }
        order.setStatus(Order.STATUS_CANCELLED);
        this.updateById(order);
        log.info("取消订单成功，orderId={}", orderId);
        return true;
    }
}
//package com.bookstore.monolithic.service.impl;
//
//import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
//import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
//import com.bookstore.monolithic.entity.*;
//        import com.bookstore.monolithic.mapper.OrderItemMapper;
//import com.bookstore.monolithic.mapper.OrderMapper;
//import com.bookstore.monolithic.service.BookService;
//import com.bookstore.monolithic.service.OrderService;
//import com.bookstore.monolithic.service.UserService;
//import org.slf4j.Logger;
//import org.slf4j.LoggerFactory;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.data.redis.core.StringRedisTemplate;
//import org.springframework.stereotype.Service;
//import org.springframework.transaction.annotation.Transactional;
//
//import java.math.BigDecimal;
//import java.math.RoundingMode;
//import java.time.LocalDateTime;
//import java.util.List;
//import java.util.concurrent.TimeUnit;
//
//@Service
//public class OrderServiceImpl extends ServiceImpl<OrderMapper, Order> implements OrderService {
//    private static final Logger log = LoggerFactory.getLogger(OrderServiceImpl.class);
//
//    @Autowired
//    private BookService bookService;
//    @Autowired
//    private OrderItemMapper orderItemMapper;
//    @Autowired
//    private UserService userService;
//    @Autowired
//    private StringRedisTemplate stringRedisTemplate;
//
//    private static final String IDEMPOTENT_KEY_PREFIX = "order:idempotent:";
//
//    @Override
//    @Transactional
//    public Long createOrder(Long userId, List<OrderItem> items, BigDecimal pointsUsed,
//                            Long addressId, Integer orderType, Long couponId, String idempotentToken) {
//        // 幂等性检查
//        if (idempotentToken != null && !idempotentToken.isEmpty()) {
//            String key = IDEMPOTENT_KEY_PREFIX + idempotentToken;
//            Boolean success = stringRedisTemplate.opsForValue().setIfAbsent(key, "processing", 5, TimeUnit.MINUTES);
//            if (Boolean.FALSE.equals(success)) {
//                throw new RuntimeException("请勿重复提交订单");
//            }
//            try {
//                // 执行订单创建逻辑
//                Long orderId = doCreateOrder(userId, items, pointsUsed, addressId, orderType, couponId);
//                stringRedisTemplate.opsForValue().set(key, "done:" + orderId, 5, TimeUnit.MINUTES);
//                return orderId;
//            } catch (RuntimeException e) {
//                stringRedisTemplate.delete(key);
//                throw e;
//            }
//        } else {
//            return doCreateOrder(userId, items, pointsUsed, addressId, orderType, couponId);
//        }
//    }
//
//    private Long doCreateOrder(Long userId, List<OrderItem> items, BigDecimal pointsUsed,
//                               Long addressId, Integer orderType, Long couponId) {
//        if (items == null || items.isEmpty()) {
//            throw new RuntimeException("订单商品不能为空");
//        }
//
//        // 1. 扣减库存并计算总金额
//        BigDecimal totalAmount = BigDecimal.ZERO;
//        for (OrderItem item : items) {
//            Book book = bookService.getById(item.getBookId());
//            if (book == null) throw new RuntimeException("商品不存在");
//            if (book.getType() == 2 && book.getStock() < item.getCount()) {
//                throw new RuntimeException("商品 " + book.getTitle() + " 库存不足");
//            }
//            boolean deducted = bookService.deductStock(item.getBookId(), item.getCount());
//            if (!deducted) throw new RuntimeException("商品 " + book.getTitle() + " 扣减库存失败");
//            totalAmount = totalAmount.add(item.getPrice().multiply(BigDecimal.valueOf(item.getCount())));
//        }
//
//        // 2. 获取用户等级折扣
//        User user = userService.getById(userId);
//        double levelRate = 0.0;
//        if (user != null) {
//            switch (user.getLevel()) {
//                case 1 -> levelRate = 0.05;
//                case 2 -> levelRate = 0.10;
//                case 3 -> levelRate = 0.15;
//            }
//        }
//        BigDecimal levelDiscount = totalAmount.multiply(BigDecimal.valueOf(levelRate));
//
//        // 3. 优惠券折扣
//        BigDecimal couponDiscount = BigDecimal.ZERO;
//        if (couponId != null) {
//            // 简化：调用用户服务获取优惠券减免金额
//            // 这里直接查询 user_coupon 表
//            // 实际应通过 service，为简化，使用 Mapper 查询（需注入 CouponMapper 和 UserCouponMapper）
//            // 此处略，假设已注入
//        }
//
//        // 4. 积分抵扣
//        if (pointsUsed == null) pointsUsed = BigDecimal.ZERO;
//        BigDecimal actualPaid = totalAmount.subtract(pointsUsed).subtract(couponDiscount).subtract(levelDiscount);
//        if (actualPaid.compareTo(BigDecimal.ZERO) < 0) actualPaid = BigDecimal.ZERO;
//
//        // 5. 扣减积分
//        if (pointsUsed.compareTo(BigDecimal.ZERO) > 0) {
//            // 调用用户服务扣减积分
//            // 简化：直接操作 user 表
//            if (user.getPoints().compareTo(pointsUsed) < 0) throw new RuntimeException("积分不足");
//            user.setPoints(user.getPoints().subtract(pointsUsed));
//            userService.updateById(user);
//        }
//
//        // 6. 使用优惠券（标记已使用）
//        if (couponId != null) {
//            // 更新 user_coupon 表
//        }
//
//        // 7. 获取卖家ID（取第一个商品的卖家）
//        Long firstProductId = items.get(0).getBookId();
//        Book firstBook = bookService.getById(firstProductId);
//        Long sellerId = firstBook != null && firstBook.getSellerId() != null ? firstBook.getSellerId() : 0L;
//
//        // 8. 创建订单主记录
//        int totalCount = items.stream().mapToInt(OrderItem::getCount).sum();
//        Order order = new Order();
//        order.setUserId(userId);
//        order.setProductId(firstProductId);
//        order.setCount(totalCount);
//        order.setAmount(totalAmount);
//        order.setPointsUsed(pointsUsed);
//        order.setCouponDiscount(couponDiscount);
//        order.setLevelDiscount(levelDiscount);
//        order.setActualPaid(actualPaid);
//        order.setAddressId(addressId);
//        order.setOrderType(orderType);
//        order.setCouponId(couponId);
//        order.setSellerId(sellerId);
//        order.setStatus(Order.STATUS_PENDING);
//        order.setDeliveryStatus(0);
//        order.setCreateTime(LocalDateTime.now());
//        this.save(order);
//        Long orderId = order.getId();
//
//        // 9. 保存订单项
//        for (OrderItem item : items) {
//            item.setOrderId(orderId);
//            orderItemMapper.insert(item);
//        }
//
//        log.info("订单创建成功，orderId={}", orderId);
//        return orderId;
//    }
//
//    // 其他方法保持不变...
//    @Override
//    public List<Order> getOrdersByUserId(Long userId) {
//        return this.list(new QueryWrapper<Order>().eq("user_id", userId).orderByDesc("create_time"));
//    }
//
//    @Override
//    public Order getOrderById(Long orderId) {
//        return this.getById(orderId);
//    }
//
//    @Override
//    @Transactional
//    public boolean payOrder(Long orderId) {
//        Order order = this.getById(orderId);
//        if (order == null || order.getStatus() != Order.STATUS_PENDING) return false;
//        order.setStatus(Order.STATUS_PAID);
//        this.updateById(order);
//        // 增加图书销量
//        Book book = bookService.getById(order.getProductId());
//        if (book != null) {
//            book.setPurchaseCount((book.getPurchaseCount() == null ? 0 : book.getPurchaseCount()) + order.getCount());
//            book.setSoldCount((book.getSoldCount() == null ? 0 : book.getSoldCount()) + order.getCount());
//            bookService.updateById(book);
//        }
//        // 增加用户积分（实付金额/10）
//        BigDecimal pointsEarned = order.getActualPaid().divide(BigDecimal.TEN, 1, RoundingMode.DOWN);
//        if (pointsEarned.compareTo(BigDecimal.ZERO) > 0) {
//            User user = userService.getById(order.getUserId());
//            if (user != null) {
//                user.setPoints(user.getPoints().add(pointsEarned));
//                userService.updateById(user);
//            }
//        }
//        // 增加消费累计
//        userService.addConsumption(order.getUserId(), order.getActualPaid());
//        return true;
//    }
//
//    @Override
//    @Transactional
//    public boolean cancelOrder(Long orderId) {
//        Order order = this.getById(orderId);
//        if (order == null || order.getStatus() != Order.STATUS_PENDING) return false;
//        // 恢复库存
//        List<OrderItem> items = orderItemMapper.selectList(new QueryWrapper<OrderItem>().eq("order_id", orderId));
//        for (OrderItem item : items) {
//            bookService.addStock(item.getBookId(), item.getCount());
//        }
//        // 恢复积分
//        if (order.getPointsUsed().compareTo(BigDecimal.ZERO) > 0) {
//            User user = userService.getById(order.getUserId());
//            if (user != null) {
//                user.setPoints(user.getPoints().add(order.getPointsUsed()));
//                userService.updateById(user);
//            }
//        }
//        order.setStatus(Order.STATUS_CANCELLED);
//        return this.updateById(order);
//    }
//}