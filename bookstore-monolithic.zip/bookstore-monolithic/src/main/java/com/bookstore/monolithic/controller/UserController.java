package com.bookstore.monolithic.controller;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.conditions.update.UpdateWrapper;
import com.bookstore.monolithic.dto.ApiResponse;
import com.bookstore.monolithic.entity.*;
import com.bookstore.monolithic.mapper.AddressMapper;
import com.bookstore.monolithic.mapper.CouponMapper;
import com.bookstore.monolithic.mapper.UserCouponMapper;
import com.bookstore.monolithic.service.UserService;
import com.bookstore.monolithic.utils.JwtUtil;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.web.bind.annotation.*;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/users")
public class UserController {

    private final UserService userService;
    private final JwtUtil jwtUtil;
    private final AddressMapper addressMapper;
    private final CouponMapper couponMapper;
    private final UserCouponMapper userCouponMapper;
    private final BCryptPasswordEncoder passwordEncoder = new BCryptPasswordEncoder();

    public UserController(UserService userService, JwtUtil jwtUtil,
                          AddressMapper addressMapper, CouponMapper couponMapper,
                          UserCouponMapper userCouponMapper) {
        this.userService = userService;
        this.jwtUtil = jwtUtil;
        this.addressMapper = addressMapper;
        this.couponMapper = couponMapper;
        this.userCouponMapper = userCouponMapper;
    }

    @PostMapping("/register")
    public ApiResponse<Void> register(@RequestBody User user) {
        // 关键修改：用 userService.getByUsername 替代 lambdaQuery
        if (userService.getByUsername(user.getUsername()) != null) {
            return ApiResponse.error("用户名已存在", 409);
        }
        user.setPassword(passwordEncoder.encode(user.getPassword()));
        user.setCreated(LocalDateTime.now());
        user.setPoints(BigDecimal.ZERO);
        user.setLevel(0);
        user.setTotalConsumption(BigDecimal.ZERO);
        userService.save(user);
        return ApiResponse.success("注册成功", null);
    }

    @PostMapping("/login")
    public ApiResponse<Map<String, Object>> login(@RequestBody User loginUser) {
        QueryWrapper<User> wrapper = new QueryWrapper<>();
        wrapper.eq("username", loginUser.getUsername());
        User user = userService.getOne(wrapper);
        if (user == null || !passwordEncoder.matches(loginUser.getPassword(), user.getPassword())) {
            return ApiResponse.error("用户名或密码错误", 401);
        }
        String token = jwtUtil.generateToken(user.getId(), user.getUsername());
        Map<String, Object> result = new HashMap<>();
        result.put("token", token);
        result.put("userId", user.getId());
        result.put("username", user.getUsername());
        result.put("points", user.getPoints());
        return ApiResponse.success(result);
    }

    // 注销（简化，不做黑名单）
    @PostMapping("/logout")
    public ApiResponse<Void> logout() {
        return ApiResponse.success("注销成功", null);
    }

    // 修改密码（简化）
    @PostMapping("/changePassword")
    public ApiResponse<Void> changePassword(@RequestHeader("X-User-Id") Long userId,
                                            @RequestParam String oldPassword,
                                            @RequestParam String newPassword) {
        User user = userService.getById(userId);
        if (user == null || !passwordEncoder.matches(oldPassword, user.getPassword())) {
            return ApiResponse.error("原密码错误", 400);
        }
        user.setPassword(passwordEncoder.encode(newPassword));
        userService.updateById(user);
        return ApiResponse.success("密码修改成功，请重新登录", null);
    }

    @GetMapping("/{id}")
    public ApiResponse<User> getById(@PathVariable Long id) {
        User user = userService.getById(id);
        if (user == null) return ApiResponse.error("用户不存在", 404);
        user.setPassword(null);
        return ApiResponse.success(user);
    }

    @GetMapping("/me")
    public ApiResponse<User> getCurrentUser(@RequestAttribute("userId") Long userId) {
        User user = userService.getById(userId);
        if (user != null) user.setPassword(null);
        return ApiResponse.success(user);
    }

    @GetMapping("/level/{userId}")
    public Integer getUserLevel(@PathVariable Long userId) {
        User user = userService.getById(userId);
        return user != null ? user.getLevel() : 0;
    }

    @PostMapping("/consumption/add")
    public void addConsumption(@RequestParam Long userId, @RequestParam BigDecimal amount) {
        userService.addConsumption(userId, amount);
    }

    @PostMapping("/points/sign")
    public ApiResponse<String> signIn(@RequestAttribute("userId") Long userId) {
        User user = userService.getById(userId);
        LocalDate today = LocalDate.now();
        if (user.getLastSignDate() != null && user.getLastSignDate().equals(today)) {
            return ApiResponse.error("今日已签到", 409);
        }
        user.setPoints(user.getPoints().add(new BigDecimal("0.2")));
        user.setLastSignDate(today);
        userService.updateById(user);
        return ApiResponse.success("签到成功，获得0.2积分", "0.2");
    }

    @GetMapping("/points/balance")
    public BigDecimal getPoints(@RequestAttribute("userId") Long userId) {
        User user = userService.getById(userId);
        return user != null ? user.getPoints() : BigDecimal.ZERO;
    }

    @GetMapping("/points/today-signed")
    public Boolean todaySigned(@RequestAttribute("userId") Long userId) {
        User user = userService.getById(userId);
        return user != null && user.getLastSignDate() != null && user.getLastSignDate().equals(LocalDate.now());
    }

    @PostMapping("/points/deduct")
    public boolean deductPoints(@RequestParam Long userId, @RequestParam BigDecimal points,
                                @RequestParam String reason) {
        User user = userService.getById(userId);
        if (user == null || user.getPoints().compareTo(points) < 0) return false;
        user.setPoints(user.getPoints().subtract(points));
        userService.updateById(user);
        return true;
    }

    @PostMapping("/points/add")
    public boolean addPoints(@RequestParam Long userId, @RequestParam BigDecimal points,
                             @RequestParam String reason) {
        User user = userService.getById(userId);
        if (user == null) return false;
        user.setPoints(user.getPoints().add(points));
        userService.updateById(user);
        return true;
    }

    @GetMapping("/{userId}/addresses")
    public List<Address> getAddresses(@PathVariable Long userId) {
        return addressMapper.selectList(new QueryWrapper<Address>().eq("user_id", userId));
    }

    @PostMapping("/address")
    public ApiResponse<Void> addAddress(@RequestBody Address address) {
        if (address.getIsDefault() == 1) {
            addressMapper.update(null, new UpdateWrapper<Address>()
                    .eq("user_id", address.getUserId())
                    .set("is_default", 0));
        }
        address.setCreatedAt(LocalDateTime.now());
        addressMapper.insert(address);
        return ApiResponse.success("添加成功", null);
    }

    @PutMapping("/address/{id}/default")
    public ApiResponse<Void> setDefaultAddress(@PathVariable Long id) {
        Address address = addressMapper.selectById(id);
        if (address != null) {
            addressMapper.update(null, new UpdateWrapper<Address>()
                    .eq("user_id", address.getUserId())
                    .set("is_default", 0));
            address.setIsDefault(1);
            addressMapper.updateById(address);
        }
        return ApiResponse.success("设置成功", null);
    }

    @DeleteMapping("/address/{id}")
    public ApiResponse<Void> deleteAddress(@PathVariable Long id) {
        addressMapper.deleteById(id);
        return ApiResponse.success("删除成功", null);
    }

    @GetMapping("/address/{addressId}")
    public Address getAddressById(@PathVariable Long addressId) {
        return addressMapper.selectById(addressId);
    }

    @GetMapping("/coupon/templates")
    public List<Coupon> getCouponTemplates() {
        return couponMapper.selectList(new QueryWrapper<Coupon>().eq("status", 1));
    }

    @PostMapping("/coupon/exchange")
    public ApiResponse<Void> exchangeCoupon(@RequestAttribute("userId") Long userId, @RequestParam Long couponId) {
        Coupon coupon = couponMapper.selectById(couponId);
        if (coupon == null || coupon.getStatus() != 1) return ApiResponse.error("优惠券不存在", 400);
        User user = userService.getById(userId);
        if (user.getPoints().compareTo(coupon.getPointsCost()) < 0) return ApiResponse.error("积分不足", 400);
        user.setPoints(user.getPoints().subtract(coupon.getPointsCost()));
        userService.updateById(user);
        UserCoupon uc = new UserCoupon();
        uc.setUserId(userId);
        uc.setCouponId(couponId);
        uc.setUsed(0);
        uc.setExchangeDate(LocalDateTime.now());
        uc.setExpireDate(LocalDateTime.now().plusDays(coupon.getExpireDays()));
        userCouponMapper.insert(uc);
        return ApiResponse.success("兑换成功", null);
    }

    @GetMapping("/coupon/list")
    public List<UserCoupon> getUserCoupons(@RequestAttribute("userId") Long userId) {
        return userCouponMapper.selectList(new QueryWrapper<UserCoupon>().eq("user_id", userId).eq("used", 0));
    }

    @GetMapping("/coupon/discount")
    public BigDecimal getCouponDiscount(@RequestParam Long userId, @RequestParam Long couponId) {
        UserCoupon uc = userCouponMapper.selectOne(new QueryWrapper<UserCoupon>()
                .eq("user_id", userId).eq("coupon_id", couponId).eq("used", 0));
        if (uc == null) return BigDecimal.ZERO;
        Coupon coupon = couponMapper.selectById(couponId);
        return coupon != null ? coupon.getDiscountAmount() : BigDecimal.ZERO;
    }

    @PostMapping("/coupon/use")
    public void useCoupon(@RequestParam Long couponId) {
        UserCoupon uc = userCouponMapper.selectOne(new QueryWrapper<UserCoupon>().eq("coupon_id", couponId).eq("used", 0));
        if (uc != null) {
            uc.setUsed(1);
            userCouponMapper.updateById(uc);
        }
    }

    @GetMapping("/name/{userId}")
    public String getUserName(@PathVariable Long userId) {
        User user = userService.getById(userId);
        return user != null ? user.getUsername() : "未知用户";
    }
}