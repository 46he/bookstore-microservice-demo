package com.bookstore.monolithic.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.bookstore.monolithic.entity.Book;
import com.bookstore.monolithic.mapper.BookMapper;
import com.bookstore.monolithic.service.BookService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class BookServiceImpl extends ServiceImpl<BookMapper, Book> implements BookService {
    private static final Logger log = LoggerFactory.getLogger(BookServiceImpl.class);

    @Override
    @Transactional
    public boolean deductStock(Long bookId, Integer count) {
        // 使用 Mapper 中的乐观锁方法，避免超卖
        int affected = baseMapper.deductStock(bookId, count);
        if (affected > 0) {
            log.info("扣减库存成功, bookId={}, count={}", bookId, count);
            return true;
        } else {
            log.warn("扣减库存失败，库存不足或并发冲突, bookId={}, count={}", bookId, count);
            return false;
        }
    }

    @Override
    @Transactional
    public boolean addStock(Long bookId, Integer count) {
        // 简单增加库存，无需乐观锁（但也可使用 UpdateWrapper）
        Book book = this.getById(bookId);
        if (book == null) return false;
        book.setStock(book.getStock() + count);
        return this.updateById(book);
    }

    @Override
    @Transactional
    public boolean updateImageUrl(Long bookId, String imageUrl) {
        Book book = new Book();
        book.setId(bookId);
        book.setImageUrl(imageUrl);
        return this.updateById(book);
    }

    @Override
    public IPage<Book> searchBooks(Integer pageNum, Integer pageSize, String keyword) {
        Page<Book> page = new Page<>(pageNum, pageSize);
        LambdaQueryWrapper<Book> wrapper = new LambdaQueryWrapper<>();
        if (keyword != null && !keyword.trim().isEmpty()) {
            wrapper.and(w -> w
                    .like(Book::getTitle, keyword)
                    .or()
                    .like(Book::getAuthor, keyword)
                    .or()
                    .like(Book::getCategory, keyword));
        }
        wrapper.orderByDesc(Book::getCreated);
        return this.page(page, wrapper);
    }
}