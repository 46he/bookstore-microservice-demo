package com.bookstore.monolithic.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import java.time.LocalDateTime;

@TableName("cart")
public class Cart {
    @TableId(type = IdType.AUTO)
    private Long id;
    private Long userId;
    private Long bookId;
    private Integer count;
    private String bookTitle;
    private String bookAuthor;
    private String bookCategory;
    private String bookImageUrl;
    private Integer bookType;
    private Integer bookPrice;
    private Integer bookPointsPrice;
    private Integer bookStock;
    private LocalDateTime createdAt;
    private LocalDateTime updatedAt;

    // getters and setters (略，请自行生成或使用 Lombok)
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }
    public Long getUserId() { return userId; }
    public void setUserId(Long userId) { this.userId = userId; }
    public Long getBookId() { return bookId; }
    public void setBookId(Long bookId) { this.bookId = bookId; }
    public Integer getCount() { return count; }
    public void setCount(Integer count) { this.count = count; }
    public String getBookTitle() { return bookTitle; }
    public void setBookTitle(String bookTitle) { this.bookTitle = bookTitle; }
    public String getBookAuthor() { return bookAuthor; }
    public void setBookAuthor(String bookAuthor) { this.bookAuthor = bookAuthor; }
    public String getBookCategory() { return bookCategory; }
    public void setBookCategory(String bookCategory) { this.bookCategory = bookCategory; }
    public String getBookImageUrl() { return bookImageUrl; }
    public void setBookImageUrl(String bookImageUrl) { this.bookImageUrl = bookImageUrl; }
    public Integer getBookType() { return bookType; }
    public void setBookType(Integer bookType) { this.bookType = bookType; }
    public Integer getBookPrice() { return bookPrice; }
    public void setBookPrice(Integer bookPrice) { this.bookPrice = bookPrice; }
    public Integer getBookPointsPrice() { return bookPointsPrice; }
    public void setBookPointsPrice(Integer bookPointsPrice) { this.bookPointsPrice = bookPointsPrice; }
    public Integer getBookStock() { return bookStock; }
    public void setBookStock(Integer bookStock) { this.bookStock = bookStock; }
    public LocalDateTime getCreatedAt() { return createdAt; }
    public void setCreatedAt(LocalDateTime createdAt) { this.createdAt = createdAt; }
    public LocalDateTime getUpdatedAt() { return updatedAt; }
    public void setUpdatedAt(LocalDateTime updatedAt) { this.updatedAt = updatedAt; }
}