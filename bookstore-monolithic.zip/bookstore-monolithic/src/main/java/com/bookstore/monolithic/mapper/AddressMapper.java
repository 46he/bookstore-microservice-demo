package com.bookstore.monolithic.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.bookstore.monolithic.entity.Address;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface AddressMapper extends BaseMapper<Address> {
}