package com.bookstore.monolithic.dto;

import java.math.BigDecimal;

public class OrderItemRequest {
    private Long productId;
    private Integer count;
    private BigDecimal price;
    private Integer orderType;

    // getter/setter
    public Long getProductId() { return productId; }
    public void setProductId(Long productId) { this.productId = productId; }

    public Integer getCount() { return count; }
    public void setCount(Integer count) { this.count = count; }

    public BigDecimal getPrice() { return price; }
    public void setPrice(BigDecimal price) { this.price = price; }

    public Integer getOrderType() { return orderType; }
    public void setOrderType(Integer orderType) { this.orderType = orderType; }
}