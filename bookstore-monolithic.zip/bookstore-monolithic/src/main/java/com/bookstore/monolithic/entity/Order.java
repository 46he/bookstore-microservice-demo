package com.bookstore.monolithic.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import java.math.BigDecimal;
import java.time.LocalDateTime;

@TableName("`order`")
public class Order {
    @TableId(type = IdType.AUTO)
    private Long id;
    private Long userId;
    private Long productId;
    private Integer count;
    private BigDecimal amount;
    private Integer status;
    private LocalDateTime createTime;

    // ========== 新增字段（与微服务和数据库表对齐） ==========
    private Long couponId;
    private BigDecimal couponDiscount;
    private BigDecimal levelDiscount;
    private Long sellerId;
    private Integer orderType;
    private Long addressId;
    private Long logisticsId;
    private BigDecimal pointsUsed;
    private BigDecimal actualPaid;
    private Integer deliveryStatus;
    private LocalDateTime deliveredAt;
    private LocalDateTime receivedAt;

    // 状态常量
    public static final int STATUS_PENDING = 0;
    public static final int STATUS_PAID = 1;
    public static final int STATUS_CANCELLED = 2;
    public static final int STATUS_COMPLETED = 3;

    // 无参构造器
    public Order() {}

    // ========== getters and setters ==========
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public Long getUserId() { return userId; }
    public void setUserId(Long userId) { this.userId = userId; }

    public Long getProductId() { return productId; }
    public void setProductId(Long productId) { this.productId = productId; }

    public Integer getCount() { return count; }
    public void setCount(Integer count) { this.count = count; }

    public BigDecimal getAmount() { return amount; }
    public void setAmount(BigDecimal amount) { this.amount = amount; }

    public Integer getStatus() { return status; }
    public void setStatus(Integer status) { this.status = status; }

    public LocalDateTime getCreateTime() { return createTime; }
    public void setCreateTime(LocalDateTime createTime) { this.createTime = createTime; }

    public Long getCouponId() { return couponId; }
    public void setCouponId(Long couponId) { this.couponId = couponId; }

    public BigDecimal getCouponDiscount() { return couponDiscount; }
    public void setCouponDiscount(BigDecimal couponDiscount) { this.couponDiscount = couponDiscount; }

    public BigDecimal getLevelDiscount() { return levelDiscount; }
    public void setLevelDiscount(BigDecimal levelDiscount) { this.levelDiscount = levelDiscount; }

    public Long getSellerId() { return sellerId; }
    public void setSellerId(Long sellerId) { this.sellerId = sellerId; }

    public Integer getOrderType() { return orderType; }
    public void setOrderType(Integer orderType) { this.orderType = orderType; }

    public Long getAddressId() { return addressId; }
    public void setAddressId(Long addressId) { this.addressId = addressId; }

    public Long getLogisticsId() { return logisticsId; }
    public void setLogisticsId(Long logisticsId) { this.logisticsId = logisticsId; }

    public BigDecimal getPointsUsed() { return pointsUsed; }
    public void setPointsUsed(BigDecimal pointsUsed) { this.pointsUsed = pointsUsed; }

    public BigDecimal getActualPaid() { return actualPaid; }
    public void setActualPaid(BigDecimal actualPaid) { this.actualPaid = actualPaid; }

    public Integer getDeliveryStatus() { return deliveryStatus; }
    public void setDeliveryStatus(Integer deliveryStatus) { this.deliveryStatus = deliveryStatus; }

    public LocalDateTime getDeliveredAt() { return deliveredAt; }
    public void setDeliveredAt(LocalDateTime deliveredAt) { this.deliveredAt = deliveredAt; }

    public LocalDateTime getReceivedAt() { return receivedAt; }
    public void setReceivedAt(LocalDateTime receivedAt) { this.receivedAt = receivedAt; }
}