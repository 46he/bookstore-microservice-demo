package com.bookstore.monolithic.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.bookstore.monolithic.entity.User;
import com.bookstore.monolithic.mapper.UserMapper;
import com.bookstore.monolithic.service.UserService;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.math.BigDecimal;

@Service
public class UserServiceImpl extends ServiceImpl<UserMapper, User> implements UserService {

    @Override
    public User getByUsername(String username) {
        QueryWrapper<User> wrapper = new QueryWrapper<>();
        wrapper.eq("username", username);
        return this.getOne(wrapper);
    }

    @Override
    @Transactional
    public void addConsumption(Long userId, BigDecimal amount) {
        User user = getById(userId);
        if (user == null) return;
        BigDecimal newTotal = user.getTotalConsumption().add(amount);
        user.setTotalConsumption(newTotal);
        int newLevel = 0;
        if (newTotal.compareTo(BigDecimal.valueOf(2000)) >= 0) newLevel = 3;
        else if (newTotal.compareTo(BigDecimal.valueOf(500)) >= 0) newLevel = 2;
        else if (newTotal.compareTo(BigDecimal.valueOf(100)) >= 0) newLevel = 1;
        if (newLevel > user.getLevel()) {
            user.setLevel(newLevel);
        }
        updateById(user);
    }
}