package com.bookstore.monolithic.controller;

import com.bookstore.monolithic.dto.ApiResponse;
import com.bookstore.monolithic.dto.CartItemDTO;
import com.bookstore.monolithic.service.CartService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/cart")
public class CartController {

    @Autowired
    private CartService cartService;

    @PostMapping("/add")
    public ApiResponse<Void> addToCart(@RequestAttribute("userId") Long userId,
                                       @RequestParam Long bookId,
                                       @RequestParam(defaultValue = "1") Integer count) {
        cartService.addToCart(userId, bookId, count);
        return ApiResponse.success("已添加到购物车", null);
    }

    @DeleteMapping("/remove/{bookId}")
    public ApiResponse<Void> removeFromCart(@RequestAttribute("userId") Long userId,
                                            @PathVariable Long bookId) {
        cartService.removeFromCart(userId, bookId);
        return ApiResponse.success("已从购物车移除", null);
    }

    @PutMapping("/update")
    public ApiResponse<Void> updateCartItem(@RequestAttribute("userId") Long userId,
                                            @RequestParam Long bookId,
                                            @RequestParam Integer count) {
        cartService.updateCartItem(userId, bookId, count);
        return ApiResponse.success("数量已更新", null);
    }

    @DeleteMapping("/clear")
    public ApiResponse<Void> clearCart(@RequestAttribute("userId") Long userId) {
        cartService.clearCart(userId);
        return ApiResponse.success("购物车已清空", null);
    }

    @GetMapping("/items")
    public ApiResponse<List<CartItemDTO>> getCartItems(@RequestAttribute("userId") Long userId) {
        List<CartItemDTO> items = cartService.getCartItems(userId);
        return ApiResponse.success(items);
    }

    @GetMapping("/count")
    public ApiResponse<Integer> getCartItemCount(@RequestAttribute("userId") Long userId) {
        int count = cartService.getCartItemCount(userId);
        return ApiResponse.success(count);
    }

    @GetMapping("/validate")
    public ApiResponse<List<CartItemDTO>> validateCartItems(@RequestAttribute("userId") Long userId) {
        List<CartItemDTO> validItems = cartService.validateCartItems(userId);
        return ApiResponse.success(validItems);
    }
}