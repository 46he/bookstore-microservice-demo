package com.bookstore.monolithic.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.bookstore.monolithic.entity.UserCoupon;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface UserCouponMapper extends BaseMapper<UserCoupon> {
}