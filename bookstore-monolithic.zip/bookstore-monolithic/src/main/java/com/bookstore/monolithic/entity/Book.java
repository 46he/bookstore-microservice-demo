package com.bookstore.monolithic.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.fasterxml.jackson.annotation.JsonFormat;
import java.math.BigDecimal;
import java.time.LocalDateTime;

@TableName("book")
public class Book {
    @TableId(type = IdType.AUTO)
    private Long id;
    private String title;
    private String author;
    private BigDecimal price;
    private Integer stock;
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private LocalDateTime created;
    private String description;
    private String category;
    private String imageUrl;

    // ========== 新增字段（与微服务保持一致） ==========
    private Integer type;          // 1电子书 2纸质书
    private String fileUrl;        // 电子书文件地址
    private BigDecimal pointsPrice; // 积分兑换价格
    private Long sellerId;         // 卖家ID
    private Long sellerAddressId;  // 卖家发货地址ID
    private Integer purchaseCount; // 购买次数
    private Integer soldCount;     // 总销量
    private Integer downloadCount; // 下载次数
    private Integer isFree;        // 是否免费（0否 1是）

    // 无参构造器
    public Book() {}

    // ========== getters and setters ==========
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public String getTitle() { return title; }
    public void setTitle(String title) { this.title = title; }

    public String getAuthor() { return author; }
    public void setAuthor(String author) { this.author = author; }

    public BigDecimal getPrice() { return price; }
    public void setPrice(BigDecimal price) { this.price = price; }

    public Integer getStock() { return stock; }
    public void setStock(Integer stock) { this.stock = stock; }

    public LocalDateTime getCreated() { return created; }
    public void setCreated(LocalDateTime created) { this.created = created; }

    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }

    public String getCategory() { return category; }
    public void setCategory(String category) { this.category = category; }

    public String getImageUrl() { return imageUrl; }
    public void setImageUrl(String imageUrl) { this.imageUrl = imageUrl; }

    public Integer getType() { return type; }
    public void setType(Integer type) { this.type = type; }

    public String getFileUrl() { return fileUrl; }
    public void setFileUrl(String fileUrl) { this.fileUrl = fileUrl; }

    public BigDecimal getPointsPrice() { return pointsPrice; }
    public void setPointsPrice(BigDecimal pointsPrice) { this.pointsPrice = pointsPrice; }

    public Long getSellerId() { return sellerId; }
    public void setSellerId(Long sellerId) { this.sellerId = sellerId; }

    public Long getSellerAddressId() { return sellerAddressId; }
    public void setSellerAddressId(Long sellerAddressId) { this.sellerAddressId = sellerAddressId; }

    public Integer getPurchaseCount() { return purchaseCount; }
    public void setPurchaseCount(Integer purchaseCount) { this.purchaseCount = purchaseCount; }

    public Integer getSoldCount() { return soldCount; }
    public void setSoldCount(Integer soldCount) { this.soldCount = soldCount; }

    public Integer getDownloadCount() { return downloadCount; }
    public void setDownloadCount(Integer downloadCount) { this.downloadCount = downloadCount; }

    public Integer getIsFree() { return isFree; }
    public void setIsFree(Integer isFree) { this.isFree = isFree; }
}