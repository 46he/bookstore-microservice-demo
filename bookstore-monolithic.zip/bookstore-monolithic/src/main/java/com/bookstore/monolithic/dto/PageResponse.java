package com.bookstore.monolithic.dto;

import java.util.List;

public class PageResponse<T> {
    private List<T> records;
    private long total;
    private long current;
    private long size;
    private long pages;

    public PageResponse() {}

    public static <T> PageResponse<T> of(List<T> records, long total, long current, long size) {
        PageResponse<T> response = new PageResponse<>();
        response.setRecords(records);
        response.setTotal(total);
        response.setCurrent(current);
        response.setSize(size);
        response.setPages((total + size - 1) / size);
        return response;
    }

    // 所有 getter / setter
    public List<T> getRecords() { return records; }
    public void setRecords(List<T> records) { this.records = records; }

    public long getTotal() { return total; }
    public void setTotal(long total) { this.total = total; }

    public long getCurrent() { return current; }
    public void setCurrent(long current) { this.current = current; }

    public long getSize() { return size; }
    public void setSize(long size) { this.size = size; }

    public long getPages() { return pages; }
    public void setPages(long pages) { this.pages = pages; }
}