package com.bookstore.monolithic.controller;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.bookstore.monolithic.config.ImageUploadConfig;
import com.bookstore.monolithic.dto.ApiResponse;
import com.bookstore.monolithic.entity.Book;
import com.bookstore.monolithic.service.BookService;
import com.bookstore.monolithic.utils.FileUploadUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/book")
public class BookController {

    @Autowired
    private BookService bookService;

    @Autowired
    private ImageUploadConfig imageUploadConfig;

    @PostMapping
    public ApiResponse<Void> addBook(@RequestBody Book book) {
        book.setCreated(LocalDateTime.now());
        bookService.save(book);
        return ApiResponse.success("添加成功", null);
    }

    @GetMapping("/{id}")
    public ApiResponse<Book> getById(@PathVariable Long id) {
        Book book = bookService.getById(id);
        if (book == null) {
            return ApiResponse.error("图书不存在", 404);
        }
        return ApiResponse.success(book);
    }

    /**
     * 图书搜索接口（支持分页和关键词）
     * 返回格式与微服务版本兼容：{ records, total, current, size, pages }
     */
    @GetMapping("/search")
    public ApiResponse<Map<String, Object>> search(@RequestParam(defaultValue = "1") Integer pageNum,
                                                   @RequestParam(defaultValue = "12") Integer pageSize,
                                                   @RequestParam(required = false) String keyword) {
        IPage<Book> pageResult = bookService.searchBooks(pageNum, pageSize, keyword);
        Map<String, Object> result = new HashMap<>();
        result.put("records", pageResult.getRecords());
        result.put("total", pageResult.getTotal());
        result.put("current", pageResult.getCurrent());
        result.put("size", pageResult.getSize());
        result.put("pages", pageResult.getPages());
        return ApiResponse.success(result);
    }

    @PostMapping("/{id}/uploadImage")
    public ApiResponse<String> uploadImage(@PathVariable Long id, @RequestParam("file") MultipartFile file) {
        try {
            String fileName = FileUploadUtil.saveFile(file, imageUploadConfig.getUploadDir());
            String imageUrl = imageUploadConfig.getAccessUrlPrefix() + fileName;
            boolean updated = bookService.updateImageUrl(id, imageUrl);
            if (updated) {
                return ApiResponse.success("图片上传成功", imageUrl);
            } else {
                return ApiResponse.error("图片上传失败（更新数据库失败）", 500);
            }
        } catch (IOException e) {
            return ApiResponse.error("上传失败：" + e.getMessage(), 500);
        }
    }

    // 兼容旧路径：获取所有图书（简单列表）
    @GetMapping("/list")
    public ApiResponse<List<Book>> listAll() {
        List<Book> books = bookService.list();
        return ApiResponse.success(books);
    }
}