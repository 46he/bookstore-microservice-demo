package com.bookstore.monolithic.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.bookstore.monolithic.entity.User;
import java.math.BigDecimal;

public interface UserService extends IService<User> {
    void addConsumption(Long userId, BigDecimal amount);

    // 新增：根据用户名查询用户
    User getByUsername(String username);
}