package com.bookstore.monolithic.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.ResourceHandlerRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

@Configuration
public class ImageUploadConfig implements WebMvcConfigurer {

    @Value("${book.image.upload-dir:./uploads/books/}")
    private String uploadDir;

    @Value("${book.image.access-url-prefix:/uploads/books/}")
    private String accessUrlPrefix;

    @Override
    public void addResourceHandlers(ResourceHandlerRegistry registry) {
        registry.addResourceHandler(accessUrlPrefix + "**")
                .addResourceLocations("file:" + uploadDir);
    }

    public String getUploadDir() {
        return uploadDir;
    }

    public String getAccessUrlPrefix() {
        return accessUrlPrefix;
    }
}