package com.bookstore.monolithic.controller;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.bookstore.monolithic.dto.*;
import com.bookstore.monolithic.entity.Book;
import com.bookstore.monolithic.entity.Order;
import com.bookstore.monolithic.entity.OrderItem;
import com.bookstore.monolithic.mapper.OrderItemMapper;
import com.bookstore.monolithic.service.BookService;
import com.bookstore.monolithic.service.OrderService;
import com.bookstore.monolithic.utils.JwtUtil;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/api/order")
public class OrderController {

    @Autowired
    private OrderService orderService;
    @Autowired
    private JwtUtil jwtUtil;
    @Autowired
    private OrderItemMapper orderItemMapper;
    @Autowired
    private BookService bookService;

    private Long getUserIdFromToken(HttpServletRequest request) {
        String authHeader = request.getHeader("Authorization");
        if (authHeader != null && authHeader.startsWith("Bearer ")) {
            String token = authHeader.substring(7);
            if (jwtUtil.validateToken(token)) {
                return jwtUtil.getUserIdFromToken(token);
            }
        }
        throw new RuntimeException("未登录或 token 无效");
    }

    @PostMapping("/create")
    public ApiResponse<Long> createOrder(@RequestBody CreateOrderRequest request, HttpServletRequest servletRequest) {
        Long userId = getUserIdFromToken(servletRequest);
        List<OrderItemRequest> itemReqs = request.getItems();
        if (itemReqs == null || itemReqs.isEmpty()) {
            return ApiResponse.error("订单商品不能为空", 400);
        }

        List<OrderItem> items = new ArrayList<>();
        for (OrderItemRequest req : itemReqs) {
            OrderItem item = new OrderItem();
            item.setBookId(req.getProductId());
            item.setCount(req.getCount());
            item.setPrice(req.getPrice());
            item.setBookType(req.getOrderType());
            item.setPointsPrice(BigDecimal.ZERO);
            items.add(item);
        }

        try {
            Long orderId = orderService.createOrder(
                    userId,
                    items,
                    request.getPointsUsed(),
                    request.getAddressId(),
                    request.getOrderType(),
                    request.getCouponId(),
                    request.getIdempotentToken()
            );
            return ApiResponse.success("订单创建成功", orderId);
        } catch (Exception e) {
            return ApiResponse.error(e.getMessage(), 400);
        }
    }

    @GetMapping("/user/page")
    public ApiResponse<PageResponse<OrderListDTO>> getUserOrdersPage(@RequestAttribute("userId") Long userId,
                                                                     @RequestParam(defaultValue = "1") Integer page,
                                                                     @RequestParam(defaultValue = "10") Integer size,
                                                                     @RequestParam(required = false) Integer status) {
        Page<Order> pageParam = new Page<>(page, size);
        QueryWrapper<Order> wrapper = new QueryWrapper<>();
        wrapper.eq("user_id", userId);
        if (status != null) wrapper.eq("status", status);
        wrapper.orderByDesc("create_time");
        IPage<Order> orderPage = orderService.page(pageParam, wrapper);
        List<OrderListDTO> records = orderPage.getRecords().stream().map(order -> {
            OrderListDTO dto = new OrderListDTO();
            BeanUtils.copyProperties(order, dto);
            // 获取商品标题和图片
            List<OrderItem> items = orderItemMapper.selectList(new QueryWrapper<OrderItem>().eq("order_id", order.getId()));
            if (items != null && !items.isEmpty()) {
                OrderItem firstItem = items.get(0);
                Book book = bookService.getById(firstItem.getBookId());
                if (book != null) {
                    dto.setProductTitle(book.getTitle());
                    dto.setProductImageUrl(book.getImageUrl());
                } else {
                    dto.setProductTitle("商品已下架");
                }
                dto.setProductCount(firstItem.getCount());
            }
            dto.setSellerName(order.getSellerId() == 0 ? "平台自营" : "卖家" + order.getSellerId());
            return dto;
        }).collect(Collectors.toList());
        PageResponse<OrderListDTO> pageResponse = PageResponse.of(records, orderPage.getTotal(), orderPage.getCurrent(), orderPage.getSize());
        return ApiResponse.success(pageResponse);
    }

    @GetMapping("/{orderId}/detail")
    public ApiResponse<OrderDetailDTO> getOrderDetail(@PathVariable Long orderId) {
        Order order = orderService.getOrderById(orderId);
        if (order == null) return ApiResponse.error("订单不存在", 404);
        OrderDetailDTO dto = new OrderDetailDTO();
        BeanUtils.copyProperties(order, dto);
        List<OrderItem> items = orderItemMapper.selectList(new QueryWrapper<OrderItem>().eq("order_id", orderId));
        List<OrderItemDTO> itemDTOs = items.stream().map(item -> {
            OrderItemDTO itemDTO = new OrderItemDTO();
            itemDTO.setProductId(item.getBookId());
            itemDTO.setCount(item.getCount());
            itemDTO.setPrice(item.getPrice());
            itemDTO.setOrderType(item.getBookType());
            itemDTO.setSubtotal(item.getPrice().multiply(BigDecimal.valueOf(item.getCount())));
            Book book = bookService.getById(item.getBookId());
            if (book != null) {
                itemDTO.setProductTitle(book.getTitle());
                itemDTO.setProductAuthor(book.getAuthor());
                itemDTO.setProductImageUrl(book.getImageUrl());
            } else {
                itemDTO.setProductTitle("商品已下架");
            }
            return itemDTO;
        }).collect(Collectors.toList());
        dto.setItems(itemDTOs);
        dto.setSellerName(order.getSellerId() == 0 ? "平台自营" : "卖家" + order.getSellerId());
        return ApiResponse.success(dto);
    }

    // 其他接口：getOrdersByUserId, getOrderById, pay, cancel 保持不变
    @GetMapping("/user/{userId}")
    public ApiResponse<List<Order>> getOrdersByUserId(@PathVariable Long userId) {
        List<Order> orders = orderService.getOrdersByUserId(userId);
        return ApiResponse.success(orders);
    }

    @GetMapping("/{orderId}")
    public ApiResponse<Order> getOrderById(@PathVariable Long orderId) {
        Order order = orderService.getOrderById(orderId);
        return ApiResponse.success(order);
    }

    @PostMapping("/pay/{orderId}")
    public ApiResponse<Void> payOrder(@PathVariable Long orderId) {
        boolean success = orderService.payOrder(orderId);
        return success ? ApiResponse.success("支付成功", null) : ApiResponse.error("支付失败", 400);
    }

    @PostMapping("/cancel/{orderId}")
    public ApiResponse<Void> cancelOrder(@PathVariable Long orderId) {
        boolean success = orderService.cancelOrder(orderId);
        return success ? ApiResponse.success("订单已取消", null) : ApiResponse.error("取消失败", 400);
    }
}