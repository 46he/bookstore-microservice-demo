package com.bookstore.monolithic.dto;

import java.math.BigDecimal;
import java.time.LocalDateTime;

public class OrderListDTO {
    private Long id;
    private Long userId;
    private Integer status;
    private BigDecimal amount;
    private BigDecimal actualPaid;
    private LocalDateTime createTime;
    private Integer orderType;
    private Integer deliveryStatus;
    private Long logisticsId;
    private String productTitle;
    private String productImageUrl;
    private Integer productCount;
    private String sellerName;

    // getters and setters
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }
    public Long getUserId() { return userId; }
    public void setUserId(Long userId) { this.userId = userId; }
    public Integer getStatus() { return status; }
    public void setStatus(Integer status) { this.status = status; }
    public BigDecimal getAmount() { return amount; }
    public void setAmount(BigDecimal amount) { this.amount = amount; }
    public BigDecimal getActualPaid() { return actualPaid; }
    public void setActualPaid(BigDecimal actualPaid) { this.actualPaid = actualPaid; }
    public LocalDateTime getCreateTime() { return createTime; }
    public void setCreateTime(LocalDateTime createTime) { this.createTime = createTime; }
    public Integer getOrderType() { return orderType; }
    public void setOrderType(Integer orderType) { this.orderType = orderType; }
    public Integer getDeliveryStatus() { return deliveryStatus; }
    public void setDeliveryStatus(Integer deliveryStatus) { this.deliveryStatus = deliveryStatus; }
    public Long getLogisticsId() { return logisticsId; }
    public void setLogisticsId(Long logisticsId) { this.logisticsId = logisticsId; }
    public String getProductTitle() { return productTitle; }
    public void setProductTitle(String productTitle) { this.productTitle = productTitle; }
    public String getProductImageUrl() { return productImageUrl; }
    public void setProductImageUrl(String productImageUrl) { this.productImageUrl = productImageUrl; }
    public Integer getProductCount() { return productCount; }
    public void setProductCount(Integer productCount) { this.productCount = productCount; }
    public String getSellerName() { return sellerName; }
    public void setSellerName(String sellerName) { this.sellerName = sellerName; }
}