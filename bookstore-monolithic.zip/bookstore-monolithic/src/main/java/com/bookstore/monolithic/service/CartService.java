package com.bookstore.monolithic.service;

import com.bookstore.monolithic.dto.CartItemDTO;
import java.util.List;

public interface CartService {
    void addToCart(Long userId, Long bookId, Integer count);
    void removeFromCart(Long userId, Long bookId);
    void updateCartItem(Long userId, Long bookId, Integer count);
    void clearCart(Long userId);
    List<CartItemDTO> getCartItems(Long userId);
    int getCartItemCount(Long userId);
    List<CartItemDTO> validateCartItems(Long userId);
}