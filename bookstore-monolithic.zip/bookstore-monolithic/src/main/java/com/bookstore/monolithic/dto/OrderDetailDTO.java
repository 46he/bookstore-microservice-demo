package com.bookstore.monolithic.dto;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;

public class OrderDetailDTO {
    private Long id;
    private Long userId;
    private Integer status;
    private BigDecimal amount;
    private BigDecimal actualPaid;
    private BigDecimal pointsUsed;
    private LocalDateTime createTime;
    private Integer orderType;
    private Integer deliveryStatus;
    private Long logisticsId;
    private Long addressId;
    private Long couponId;
    private BigDecimal couponDiscount;
    private BigDecimal levelDiscount;
    private Long sellerId;
    private String sellerName;
    private List<OrderItemDTO> items;

    // getters and setters (全部生成)
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }
    public Long getUserId() { return userId; }
    public void setUserId(Long userId) { this.userId = userId; }
    public Integer getStatus() { return status; }
    public void setStatus(Integer status) { this.status = status; }
    public BigDecimal getAmount() { return amount; }
    public void setAmount(BigDecimal amount) { this.amount = amount; }
    public BigDecimal getActualPaid() { return actualPaid; }
    public void setActualPaid(BigDecimal actualPaid) { this.actualPaid = actualPaid; }
    public BigDecimal getPointsUsed() { return pointsUsed; }
    public void setPointsUsed(BigDecimal pointsUsed) { this.pointsUsed = pointsUsed; }
    public LocalDateTime getCreateTime() { return createTime; }
    public void setCreateTime(LocalDateTime createTime) { this.createTime = createTime; }
    public Integer getOrderType() { return orderType; }
    public void setOrderType(Integer orderType) { this.orderType = orderType; }
    public Integer getDeliveryStatus() { return deliveryStatus; }
    public void setDeliveryStatus(Integer deliveryStatus) { this.deliveryStatus = deliveryStatus; }
    public Long getLogisticsId() { return logisticsId; }
    public void setLogisticsId(Long logisticsId) { this.logisticsId = logisticsId; }
    public Long getAddressId() { return addressId; }
    public void setAddressId(Long addressId) { this.addressId = addressId; }
    public Long getCouponId() { return couponId; }
    public void setCouponId(Long couponId) { this.couponId = couponId; }
    public BigDecimal getCouponDiscount() { return couponDiscount; }
    public void setCouponDiscount(BigDecimal couponDiscount) { this.couponDiscount = couponDiscount; }
    public BigDecimal getLevelDiscount() { return levelDiscount; }
    public void setLevelDiscount(BigDecimal levelDiscount) { this.levelDiscount = levelDiscount; }
    public Long getSellerId() { return sellerId; }
    public void setSellerId(Long sellerId) { this.sellerId = sellerId; }
    public String getSellerName() { return sellerName; }
    public void setSellerName(String sellerName) { this.sellerName = sellerName; }
    public List<OrderItemDTO> getItems() { return items; }
    public void setItems(List<OrderItemDTO> items) { this.items = items; }
}