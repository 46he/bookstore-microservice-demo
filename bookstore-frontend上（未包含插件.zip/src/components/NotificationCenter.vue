<template>
  <el-popover placement="bottom" width="350" trigger="click">
    <template #reference>
      <el-badge :value="unreadCount" :hidden="unreadCount === 0" class="notification-badge">
        <el-icon size="20" class="bell-icon"><Bell /></el-icon>
      </el-badge>
    </template>
    <div class="notification-header">
      <h4>消息通知</h4>
      <el-button size="small" type="primary" link @click="handleMarkAllRead" v-if="unreadCount > 0">
        全部已读
      </el-button>
    </div>
    <div class="notification-list">
      <div v-if="loading" class="loading">
        <el-icon class="is-loading"><Loading /></el-icon>
        加载中...
      </div>
      <div v-else-if="error" class="error">
        <el-icon><Warning /></el-icon>
        {{ error }}
      </div>
      <div v-else>
        <div
          v-for="notification in notifications"
          :key="notification.id"
          class="notification-item"
          :class="{ unread: !notification.isRead, [notification.type]: true }"
          @click="handleMarkRead(notification.id)"
        >
          <div class="notification-icon">
            <el-icon :size="16" :class="getIconClass(notification.type)">
              <component :is="getIconComponent(notification.type)" />
            </el-icon>
          </div>
          <div class="notification-content">
            <div class="content">{{ notification.content }}</div>
            <div class="time">{{ formatTime(notification.createdAt) }}</div>
          </div>
          <div v-if="!notification.isRead" class="unread-dot"></div>
        </div>
        <div v-if="notifications.length === 0" class="no-notifications">
          <el-icon size="48" class="empty-icon"><Bell /></el-icon>
          <p>暂无通知</p>
        </div>
      </div>
    </div>
  </el-popover>
</template>

<script setup>
import { onMounted, onUnmounted } from 'vue'
import {
  Bell,
  Loading,
  Warning,
  ShoppingCart,
  Star,
  Present,
  InfoFilled,
  Trophy
} from '@element-plus/icons-vue'
import { useNotifications } from '../composables/useNotifications'

const {
  notifications,
  unreadCount,
  loading,
  error,
  markRead,
  markAllRead,
  formatTime,
  startPolling,
  stopPolling,
  loadNotifications  // 新增：重新加载通知的方法
} = useNotifications()

// 单条消息标记已读
const handleMarkRead = async (id) => {
  // 先尝试调用后端，前端立即更新本地状态
  try {
    await markRead(id)
  } catch (err) {
    console.error('标记已读失败', err)
  }
  // 无论如何，前端主动更新（后端失败也保证前端体验）
  const idx = notifications.value.findIndex(n => n.id === id)
  if (idx !== -1 && notifications.value[idx].isRead === 0) {
    notifications.value[idx].isRead = 1
    unreadCount.value = Math.max(0, unreadCount.value - 1)
  }
}

// 全部已读
const handleMarkAllRead = async () => {
  try {
    await markAllRead()
  } catch (err) {
    console.error('全部已读失败', err)
  }
  // 前端直接全部标为已读
  notifications.value.forEach(n => { n.isRead = 1 })
  unreadCount.value = 0
}

const getIconComponent = (type) => {
  const iconMap = {
    order: ShoppingCart,
    points: Star,
    coupon: Present,
    level_up: Trophy,
    new_book: InfoFilled,
    system: InfoFilled
  }
  return iconMap[type] || InfoFilled
}

const getIconClass = (type) => {
  return `icon-${type}`
}

onMounted(() => {
  startPolling()
})
onUnmounted(() => {
  stopPolling()
})
</script>

<style scoped>
/* 原有样式保持不变 */
.notification-badge {
  cursor: pointer;
}
.bell-icon {
  color: #606266;
}
.notification-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 12px 16px 8px;
  border-bottom: 1px solid #ebeef5;
  margin-bottom: 8px;
}
.notification-header h4 {
  margin: 0;
  font-size: 16px;
  font-weight: 500;
  color: #303133;
}
.notification-list {
  max-height: 400px;
  overflow-y: auto;
}
.loading, .error {
  display: flex;
  align-items: center;
  justify-content: center;
  padding: 20px;
  color: #909399;
}
.error {
  color: #f56c6c;
}
.notification-item {
  display: flex;
  align-items: flex-start;
  padding: 12px 16px;
  border-bottom: 1px solid #f5f7fa;
  cursor: pointer;
  transition: background-color 0.2s;
}
.notification-item:hover {
  background-color: #f5f7fa;
}
.notification-item.unread {
  background-color: #f0f9ff;
}
.notification-item.unread:hover {
  background-color: #e6f7ff;
}
.notification-icon {
  margin-right: 12px;
  margin-top: 2px;
  flex-shrink: 0;
}
.icon-order { color: #67c23a; }
.icon-points { color: #e6a23c; }
.icon-coupon { color: #f56c6c; }
.icon-level_up { color: #909399; }
.icon-new_book { color: #409eff; }
.icon-system { color: #909399; }
.notification-content {
  flex: 1;
  min-width: 0;
}
.content {
  font-size: 14px;
  line-height: 1.4;
  color: #303133;
  margin-bottom: 4px;
  word-break: break-word;
}
.time {
  font-size: 12px;
  color: #909399;
}
.unread-dot {
  width: 8px;
  height: 8px;
  background-color: #409eff;
  border-radius: 50%;
  flex-shrink: 0;
  margin-top: 6px;
  margin-left: 8px;
}
.no-notifications {
  text-align: center;
  padding: 40px 20px;
  color: #909399;
}
.empty-icon {
  color: #c0c4cc;
  margin-bottom: 12px;
}
.no-notifications p {
  margin: 0;
  font-size: 14px;
}
</style>