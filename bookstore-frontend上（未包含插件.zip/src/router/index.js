import { createRouter, createWebHistory } from 'vue-router'
import { useUserStore } from '../stores/user'
import { ElMessage } from 'element-plus'

const routes = [
  {
    path: '/',
    name: 'Home',
    component: () => import('../views/HomeView.vue'),
    meta: { title: '首页 - 基于微服务架构的在线图书商城', requiresAuth: false }
  },
  {
    path: '/login',
    name: 'Login',
    component: () => import('../views/LoginView.vue'),
    meta: { title: '登录 - 基于微服务架构的在线图书商城', requiresAuth: false, guestOnly: true }
  },
  {
    path: '/register',
    name: 'Register',
    component: () => import('../views/RegisterView.vue'),
    meta: { title: '注册 - 基于微服务架构的在线图书商城', requiresAuth: false, guestOnly: true }
  },
  {
    path: '/cart',
    name: 'Cart',
    component: () => import('../views/CartView.vue'),
    meta: { title: '购物车 - 基于微服务架构的在线图书商城', requiresAuth: true }
  },
  {
    path: '/orders',
    name: 'Orders',
    component: () => import('../views/OrdersView.vue'),
    meta: { title: '我的订单 - 基于微服务架构的在线图书商城', requiresAuth: true }
  },
  {
    path: '/orders/:id',
    name: 'OrderDetail',
    component: () => import('../views/OrderDetail.vue'),
    props: true,
    meta: { title: '订单详情 - 基于微服务架构的在线图书商城', requiresAuth: true }
  },
  {
    path: '/profile',
    name: 'Profile',
    component: () => import('../views/ProfileView.vue'),
    meta: { title: '个人中心 - 基于微服务架构的在线图书商城', requiresAuth: true }
  },
  {
    path: '/seller/center',
    name: 'SellerCenter',
    component: () => import('../views/SellerCenter.vue'),
    meta: { title: '卖家中心 - 基于微服务架构的在线图书商城', requiresAuth: true }
  },
  {
    path: '/seller/:sellerId',
    name: 'SellerBooks',
    component: () => import('../views/SellerBooks.vue'),
    props: true,
    meta: { title: '卖家店铺 - 基于微服务架构的在线图书商城', requiresAuth: false }
  },
  {
    path: '/book/:id',
    name: 'BookDetail',
    component: () => import('../views/BookDetail.vue'),
    props: true,
    meta: { title: '图书详情 - 基于微服务架构的在线图书商城', requiresAuth: false }
  },
  {
    path: '/exchange-mall',
    name: 'ExchangeMall',
    component: () => import('../views/ExchangeMall.vue'),
    meta: { title: '积分/优惠券商城 - 基于微服务架构的在线图书商城', requiresAuth: true }
  },
  {
    path: '/daily-sign',
    name: 'DailySign',
    component: () => import('../views/DailySign.vue'),
    meta: { title: '每日签到 - 基于微服务架构的在线图书商城', requiresAuth: true }
  },
  {
    path: '/notification-settings',
    name: 'NotificationSettings',
    component: () => import('../views/NotificationSettings.vue'),
    meta: { title: '通知设置 - 基于微服务架构的在线图书商城', requiresAuth: true }
  },
  {
    path: '/history',
    name: 'History',
    component: () => import('../views/HistoryView.vue'),
    meta: { title: '我的足迹 - 基于微服务架构的在线图书商城', requiresAuth: true }
  },
  {
    path: '/monitor',
    name: 'Monitor',
    component: () => import('../views/MicroServiceMonitor.vue'),
    meta: { title: '微服务架构监控 - 基于微服务架构的在线图书商城', requiresAuth: false }
  },
  {
    path: '/about-microservice',
    name: 'AboutMicroService',
    component: () => import('../views/AboutMicroService.vue'),
    meta: { title: '微服务架构说明 - 基于微服务架构的在线图书商城', requiresAuth: false }
  },
  // ========== 新增：我的图书 & 电子书阅读器 ==========
  {
    path: '/my-books',
    name: 'MyBooks',
    component: () => import('../views/MyBooksView.vue'),
    meta: { title: '我的图书 - 在线图书商城', requiresAuth: true }
  },
  {
    path: '/reader/:id',
    name: 'BookReader',
    component: () => import('../views/BookReader.vue'),
    props: true,
    meta: { title: '电子书阅读器 - 在线图书商城', requiresAuth: true }
  },
  // ========== 404 必须放在最后 ==========
  {
    path: '/:pathMatch(.*)*',
    name: 'NotFound',
    component: () => import('../views/NotFound.vue'),
    meta: { title: '页面未找到 - 基于微服务架构的在线图书商城', requiresAuth: false }
  }
]

const router = createRouter({
  history: createWebHistory(),
  routes,
  scrollBehavior(to, from, savedPosition) {
    if (savedPosition) {
      return savedPosition
    } else {
      return { top: 0, behavior: 'smooth' }
    }
  }
})

// 路由守卫（保留原有逻辑）
router.beforeEach(async (to, from, next) => {
  const userStore = useUserStore()

  if (to.meta.title) {
    document.title = to.meta.title
  }

  if (!userStore.isLogin && localStorage.getItem('token')) {
    await userStore.initializeAuth()
  }

  if (to.meta.requiresAuth && !userStore.isLogin) {
    ElMessage.warning('请先登录')
    next('/login')
    return
  }

  if (to.meta.guestOnly && userStore.isLogin) {
    ElMessage.info('您已经登录')
    next('/')
    return
  }

  next()
})

router.onError((error) => {
  console.error('Router error:', error)
  ElMessage.error('页面加载失败，请刷新重试')
})

export default router