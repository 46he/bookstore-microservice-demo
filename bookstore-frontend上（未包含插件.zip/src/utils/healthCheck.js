// 健康检测工具（模拟版本，用于未来集成真实健康检查）
export async function checkServiceHealth(serviceUrl) {
  try {
    // 尝试请求 /actuator/health 端点（如果后端未启用 actuator 会失败）
    const controller = new AbortController()
    const timeoutId = setTimeout(() => controller.abort(), 3000)
    const response = await fetch(`${serviceUrl}/actuator/health`, {
      method: 'GET',
      signal: controller.signal
    })
    clearTimeout(timeoutId)
    if (response.ok) {
      const data = await response.json()
      return data.status === 'UP'
    }
    return false
  } catch (error) {
    console.warn(`Health check failed for ${serviceUrl}:`, error.message)
    return false
  }
}

// 批量检查（返回每个服务的健康状态）
export async function checkAllServices(services) {
  const results = {}
  for (const service of services) {
    results[service.name] = await checkServiceHealth(service.address)
  }
  return results
}