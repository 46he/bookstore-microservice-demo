import { defineStore } from 'pinia'
import { ref, computed } from 'vue'
import api, { userApi } from '../api'
import { ElMessage } from 'element-plus'

export const useUserStore = defineStore('user', () => {
  const token = ref(localStorage.getItem('token') || '')
  const user = ref(JSON.parse(localStorage.getItem('user') || 'null'))
  const initialized = ref(false)
  const isLogin = computed(() => !!token.value && !!user.value)
  const loading = ref(false)
  const error = ref(null)

  const persistUser = (userData) => {
    user.value = userData
    localStorage.setItem('user', JSON.stringify(userData))
  }

  const setAuth = (newToken, userData) => {
    token.value = newToken
    persistUser(userData)
    localStorage.setItem('token', newToken)
    api.defaults.headers.common['Authorization'] = `Bearer ${newToken}`
    error.value = null
    initialized.value = true
  }

  const logout = () => {
    token.value = ''
    user.value = null
    initialized.value = false
    localStorage.removeItem('token')
    localStorage.removeItem('user')
    delete api.defaults.headers.common['Authorization']
    error.value = null
  }

  const updateUser = (userData) => {
    user.value = { ...user.value, ...userData }
    if (user.value) {
      localStorage.setItem('user', JSON.stringify(user.value))
    }
  }

  const updatePoints = (points) => {
    if (user.value) {
      user.value.points = points
      localStorage.setItem('user', JSON.stringify(user.value))
    }
  }

  const signIn = async () => {
    if (!isLogin.value) {
      throw new Error('请先登录')
    }

    loading.value = true
    try {
      const res = await userApi.signIn()
      const message = res.apiMeta?.message || '签到成功'
      const balanceRes = await userApi.getPointsBalance()
      updatePoints(balanceRes.data)
      return { success: true, message }
    } catch (err) {
      const message = err.response?.data?.message || '签到失败，请稍后重试'
      error.value = message
      return { success: false, message }
    } finally {
      loading.value = false
    }
  }

  const refreshUserInfo = async () => {
    if (!token.value) return

    try {
      const res = await userApi.getCurrentUser()
      updateUser(res.data)
    } catch (err) {
      console.error('Refresh user info error:', err)
      if (err.response?.status === 401) {
        logout()
        ElMessage.warning('登录已过期，请重新登录')
      }
    }
  }

  const initializeAuth = async () => {
    if (initialized.value) return
    initialized.value = true

    if (!token.value) {
      return
    }

    api.defaults.headers.common['Authorization'] = `Bearer ${token.value}`

    try {
      await refreshUserInfo()
    } catch (err) {
      logout()
    }
  }

  return {
    user,
    token,
    isLogin,
    loading,
    error,
    setAuth,
    logout,
    updateUser,
    updatePoints,
    signIn,
    refreshUserInfo,
    initializeAuth
  }
})