import { defineStore } from 'pinia'
import { ref, computed, watch } from 'vue'
import { userApi, bookApi } from '../api'
import { useUserStore } from './user'
import { ElMessage } from 'element-plus'

export const useCartStore = defineStore('cart', () => {
  const items = ref(JSON.parse(localStorage.getItem('cart_items') || '[]'))
  const loading = ref(false)
  const error = ref(null)
  const userStore = useUserStore()

  const totalCount = computed(() => items.value.reduce((sum, i) => sum + i.count, 0))
  const totalPrice = computed(() => items.value.reduce((sum, i) => sum + i.price * i.count, 0))
  const isEmpty = computed(() => items.value.length === 0)

  watch(items, (newItems) => {
    localStorage.setItem('cart_items', JSON.stringify(newItems))
  }, { deep: true })

  const syncToBackend = async () => {
    if (!userStore.isLogin) return
    try {
      for (const item of items.value) {
        await userApi.addToCart(item.id, item.count)
      }
    } catch (err) {
      console.error('Sync cart to backend error:', err)
    }
  }

  const loadFromBackend = async () => {
    if (!userStore.isLogin) return
    loading.value = true
    error.value = null
    try {
      const res = await userApi.getCartItems()
      items.value = res.data.map(item => ({
        id: item.bookId,
        title: item.bookTitle,
        price: Number(item.price),
        pointsPrice: Number(item.pointsPrice) || 0,
        count: item.count,
        stock: Number(item.stock),
        type: item.bookType,
        imageUrl: item.bookImageUrl,
        author: item.bookAuthor,
        category: item.bookCategory
      }))
    } catch (err) {
      error.value = '加载购物车失败，使用本地缓存'
      console.error('Load cart from backend error:', err)
    } finally {
      loading.value = false
    }
  }

  const addItem = async (book, count = 1) => {
    if (!book || !book.id) {
      error.value = '商品信息不完整'
      return false
    }
    let stock = book.stock ? Number(book.stock) : 0
    let type = book.type
    let price = book.price ? Number(book.price) : 0
    if (stock === 0 || type === undefined) {
      try {
        const res = await bookApi.getById(book.id)
        stock = Number(res.data.stock)
        type = res.data.type
        price = Number(res.data.price)
      } catch (e) {
        console.warn('获取商品信息失败', e)
        stock = 0
      }
    }
    if (stock <= 0) {
      ElMessage.warning('商品已售罄')
      return false
    }
    const exist = items.value.find(i => i.id === book.id)
    if (exist) {
      const newCount = exist.count + count
      if (newCount > stock) {
        ElMessage.warning(`《${book.title}》库存不足，最多可添加 ${stock} 件`)
        exist.count = stock
      } else {
        exist.count = newCount
      }
    } else {
      const itemCount = Math.min(count, stock)
      items.value.push({
        id: book.id,
        title: book.title,
        price: price,
        pointsPrice: book.pointsPrice ? Number(book.pointsPrice) : 0,
        count: itemCount,
        stock: stock,
        type: type,
        imageUrl: book.imageUrl,
        author: book.author,
        category: book.category
      })
    }
    if (userStore.isLogin) {
      try {
        await userApi.addToCart(book.id, count)
      } catch (err) {
        console.error('Sync add to cart error:', err)
      }
    }
    ElMessage.success('已添加到购物车')
    return true
  }

  const removeItem = async (id) => {
    const index = items.value.findIndex(i => i.id === id)
    if (index > -1) {
      items.value.splice(index, 1)
      if (userStore.isLogin) {
        try {
          await userApi.removeFromCart(id)
        } catch (err) {
          console.error('Sync remove from cart error:', err)
        }
      }
      ElMessage.success('已从购物车移除')
      return true
    }
    return false
  }

  const updateCount = async (id, count) => {
    const item = items.value.find(i => i.id === id)
    if (item) {
      count = Math.max(1, Math.min(count, item.stock))
      item.count = count
      if (userStore.isLogin) {
        try {
          await userApi.updateCartItem(id, count)
        } catch (err) {
          console.error('Sync update cart error:', err)
        }
      }
      return true
    }
    return false
  }

  const clear = async () => {
    items.value = []
    localStorage.removeItem('cart_items')
    if (userStore.isLogin) {
      try {
        await userApi.clearCart()
      } catch (err) {
        console.error('Sync clear cart error:', err)
      }
    }
  }

  const validateItems = async () => {
    const validItems = []
    const invalidItems = []
    if (userStore.isLogin) {
      try {
        const res = await userApi.validateCartItems()
        validItems.push(...res.data.map(item => ({
          id: item.bookId,
          title: item.bookTitle,
          price: Number(item.price),
          pointsPrice: Number(item.pointsPrice) || 0,
          count: item.count,
          stock: Number(item.stock),
          type: item.bookType,
          imageUrl: item.bookImageUrl,
          author: item.bookAuthor,
          category: item.bookCategory
        })))
      } catch (err) {
        console.error('Validate cart items error:', err)
        items.value.forEach(item => {
          if (item.stock <= 0) {
            invalidItems.push(item.title)
          } else if (item.count > item.stock) {
            item.count = item.stock
            validItems.push(item)
          } else {
            validItems.push(item)
          }
        })
      }
    } else {
      items.value.forEach(item => {
        if (item.stock <= 0) {
          invalidItems.push(item.title)
        } else if (item.count > item.stock) {
          item.count = item.stock
          validItems.push(item)
        } else {
          validItems.push(item)
        }
      })
    }
    items.value = validItems
    if (invalidItems.length > 0) {
      ElMessage.warning(`以下商品已售罄或库存不足，已从购物车移除：${invalidItems.join('、')}`)
    }
    return validItems.length > 0
  }

  const getItemById = (id) => {
    return items.value.find(i => i.id === id)
  }

  return {
    items,
    loading,
    error,
    totalCount,
    totalPrice,
    isEmpty,
    addItem,
    removeItem,
    updateCount,
    clear,
    validateItems,
    getItemById,
    syncToBackend,
    loadFromBackend
  }
})