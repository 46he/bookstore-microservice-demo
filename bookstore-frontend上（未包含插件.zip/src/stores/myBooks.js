import { defineStore } from 'pinia'
import { ref } from 'vue'
import { orderApi, bookApi } from '../api'

export const useMyBooksStore = defineStore('myBooks', () => {
  const books = ref([])
  const loading = ref(false)
  const error = ref(null)

  const groups = ref([])
  const STORAGE_KEY_GROUPS = 'my_books_groups'

  // 初始化分组
  const initGroups = () => {
    const saved = localStorage.getItem(STORAGE_KEY_GROUPS)
    if (saved) {
      groups.value = JSON.parse(saved)
    } else {
      groups.value = [
        { id: 'default', name: '未分组', bookIds: [] }
      ]
    }
  }

  const saveGroups = () => {
    localStorage.setItem(STORAGE_KEY_GROUPS, JSON.stringify(groups.value))
  }

  const createGroup = (name) => {
    const id = Date.now().toString()
    groups.value.push({ id, name, bookIds: [] })
    saveGroups()
    return id
  }

  const renameGroup = (groupId, newName) => {
    const group = groups.value.find(g => g.id === groupId)
    if (group) {
      group.name = newName
      saveGroups()
    }
  }

  const deleteGroup = (groupId) => {
    const groupIndex = groups.value.findIndex(g => g.id === groupId)
    if (groupIndex === -1) return
    const group = groups.value[groupIndex]
    if (group.id === 'default') return
    const defaultGroup = groups.value.find(g => g.id === 'default')
    defaultGroup.bookIds.push(...group.bookIds)
    groups.value.splice(groupIndex, 1)
    saveGroups()
  }

  const moveBookToGroup = (bookId, targetGroupId) => {
    for (const group of groups.value) {
      const idx = group.bookIds.indexOf(bookId)
      if (idx !== -1) group.bookIds.splice(idx, 1)
    }
    const targetGroup = groups.value.find(g => g.id === targetGroupId)
    if (targetGroup && !targetGroup.bookIds.includes(bookId)) {
      targetGroup.bookIds.push(bookId)
    }
    saveGroups()
  }

  const getBooksInGroup = (groupId) => {
    const group = groups.value.find(g => g.id === groupId)
    if (!group) return []
    if (groupId === 'default') {
      const groupedBookIds = new Set()
      for (const g of groups.value) {
        if (g.id !== 'default') {
          g.bookIds.forEach(id => groupedBookIds.add(id))
        }
      }
      return books.value.filter(book => !groupedBookIds.has(book.id))
    } else {
      return books.value.filter(book => group.bookIds.includes(book.id))
    }
  }

  const getAllGroups = () => groups.value

  // 从本地存储加载已购电子书（用户自己存储的）
  const loadLocalEBooks = () => {
    const stored = localStorage.getItem('my_ebooks')
    if (stored) {
      try {
        return JSON.parse(stored)
      } catch(e) {
        return []
      }
    }
    return []
  }

  // 加载已购电子书（合并后端 + 本地）
  const loadPurchasedEBooks = async () => {
    loading.value = true
    error.value = null
    const localEBooks = loadLocalEBooks()
    const mergedMap = new Map()
    // 先加入本地电子书
    localEBooks.forEach(book => {
      mergedMap.set(book.id, book)
    })

    // 尝试从后端获取（如果后端可用）
    try {
      let allOrders = []
      let page = 1
      let hasMore = true
      while (hasMore) {
        const res = await orderApi.getUserOrdersPage(page, 50, null)
        const pageData = res.data
        const orders = pageData.records || []
        allOrders.push(...orders)
        hasMore = pageData.current < Math.ceil(pageData.total / 50)
        page++
      }
      const ebookIdsSet = new Set()
      for (const order of allOrders) {
        if (order.status !== 1 && order.status !== 3) continue
        let items = order.items
        if (!items && order.id) {
          try {
            const detailRes = await orderApi.getOrderDetail(order.id)
            items = detailRes.data?.items || []
          } catch (e) {}
        }
        if (items) {
          for (const item of items) {
            if (item.orderType === 1 || item.bookType === 1) {
              const bookId = item.productId || item.bookId
              if (!ebookIdsSet.has(bookId)) {
                ebookIdsSet.add(bookId)
                if (!mergedMap.has(bookId)) {
                  mergedMap.set(bookId, { id: bookId })
                }
              }
            }
          }
        } else if (order.productId && order.orderType === 1) {
          const bookId = order.productId
          if (!ebookIdsSet.has(bookId)) {
            ebookIdsSet.add(bookId)
            if (!mergedMap.has(bookId)) {
              mergedMap.set(bookId, { id: bookId })
            }
          }
        }
      }
      // 批量获取图书详情（仅对没有详情的 book）
      const needDetails = Array.from(mergedMap.values()).filter(b => !b.title)
      if (needDetails.length) {
        const bookPromises = needDetails.map(b => bookApi.getById(b.id).catch(err => {
          console.error(`获取图书 ${b.id} 详情失败`, err)
          return null
        }))
        const bookResults = await Promise.all(bookPromises)
        for (let i = 0; i < needDetails.length; i++) {
          const res = bookResults[i]
          if (res && res.data) {
            const book = res.data
            mergedMap.set(book.id, {
              id: book.id,
              title: book.title,
              author: book.author,
              imageUrl: book.imageUrl,
              fileUrl: book.fileUrl,
              type: book.type
            })
          }
        }
      }
    } catch (err) {
      console.error('后端加载失败，仅使用本地电子书', err)
      // 不影响，继续使用本地电子书
    }

    books.value = Array.from(mergedMap.values()).filter(b => b.fileUrl || b.id)
    loading.value = false
  }

  // 监听自定义事件，当电子书购买时重新加载
  if (typeof window !== 'undefined') {
    window.addEventListener('ebook-purchased', () => {
      loadPurchasedEBooks()
    })
  }

  return {
    books,
    loading,
    error,
    initGroups,
    loadPurchasedEBooks,
    createGroup,
    renameGroup,
    deleteGroup,
    moveBookToGroup,
    getBooksInGroup,
    getAllGroups
  }
})