<template>
  <div class="notification-settings">
    <el-card class="settings-card">
      <template #header>
        <div class="card-header">
          <span>通知设置</span>
        </div>
      </template>

      <div class="settings-content">
        <el-form :model="settings" label-width="120px">
          <el-form-item label="订单通知">
            <el-switch v-model="settings.orderNotifications" />
            <span class="setting-desc">接收订单状态更新通知</span>
          </el-form-item>

          <el-form-item label="积分通知">
            <el-switch v-model="settings.pointsNotifications" />
            <span class="setting-desc">接收积分变动通知</span>
          </el-form-item>

          <el-form-item label="优惠券通知">
            <el-switch v-model="settings.couponNotifications" />
            <span class="setting-desc">接收优惠券到期提醒</span>
          </el-form-item>

          <el-form-item label="新书通知">
            <el-switch v-model="settings.newBookNotifications" />
            <span class="setting-desc">接收关注的卖家新书上架通知</span>
          </el-form-item>

          <el-form-item label="系统通知">
            <el-switch v-model="settings.systemNotifications" />
            <span class="setting-desc">接收系统公告和重要更新</span>
          </el-form-item>

          <el-form-item label="邮件通知">
            <el-switch v-model="settings.emailNotifications" />
            <span class="setting-desc">通过邮件接收重要通知</span>
          </el-form-item>
        </el-form>

        <div class="actions">
          <el-button type="primary" @click="saveSettings">保存设置</el-button>
          <el-button @click="resetSettings">重置</el-button>
        </div>
      </div>
    </el-card>

    <el-card class="test-card" style="margin-top: 20px;">
      <template #header>
        <div class="card-header">
          <span>测试通知</span>
        </div>
      </template>

      <div class="test-content">
        <p>点击下方按钮发送测试通知：</p>
        <div class="test-buttons">
          <el-button @click="sendTestNotification('order')">订单通知</el-button>
          <el-button @click="sendTestNotification('points')">积分通知</el-button>
          <el-button @click="sendTestNotification('coupon')">优惠券通知</el-button>
          <el-button @click="sendTestNotification('new_book')">新书通知</el-button>
          <el-button @click="sendTestNotification('system')">系统通知</el-button>
        </div>
      </div>
    </el-card>
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue'
import { ElMessage } from 'element-plus'
import { userApi } from '../api'
import { useUserStore } from '../stores/user'

const userStore = useUserStore()

const settings = ref({
  orderNotifications: true,
  pointsNotifications: true,
  couponNotifications: true,
  newBookNotifications: true,
  systemNotifications: true,
  emailNotifications: false
})

const saveSettings = () => {
  // 这里可以保存到后端
  ElMessage.success('设置已保存')
}

const resetSettings = () => {
  settings.value = {
    orderNotifications: true,
    pointsNotifications: true,
    couponNotifications: true,
    newBookNotifications: true,
    systemNotifications: true,
    emailNotifications: false
  }
  ElMessage.info('设置已重置')
}

const sendTestNotification = async (type) => {
  try {
    const userId = userStore.user?.id
    if (!userId) {
      ElMessage.error('请先登录')
      return
    }

    const testData = {
      order: { orderId: 'TEST001', type: 'created', content: '已创建' },
      points: { points: 10, reason: '测试奖励' },
      coupon: { couponName: '测试优惠券', expireDate: '2024-12-31T23:59:59' },
      new_book: { sellerId: 1, bookTitle: '测试图书' },
      system: { content: '这是一条测试系统通知' }
    }

    const data = testData[type]
    if (!data) return

    // 调用对应的通知API
    switch (type) {
      case 'order':
        await userApi.notifyOrder(userId, data.orderId, data.type, data.content)
        break
      case 'points':
        await userApi.notifyPoints(userId, data.points, data.reason)
        break
      case 'coupon':
        await userApi.notifyCouponExpire(userId, data.couponName, data.expireDate)
        break
      case 'new_book':
        await userApi.notifyNewBook(data.sellerId, data.bookTitle)
        break
      case 'system':
        await userApi.notifySystem(data.content)
        break
    }

    ElMessage.success('测试通知已发送')
  } catch (error) {
    ElMessage.error('发送测试通知失败')
    console.error('Send test notification error:', error)
  }
}

onMounted(() => {
  // 这里可以从后端加载用户设置
})
</script>

<style scoped>
.notification-settings {
  max-width: 800px;
  margin: 0 auto;
  padding: 20px;
}

.card-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
}

.settings-content {
  padding: 20px 0;
}

.setting-desc {
  margin-left: 10px;
  color: #909399;
  font-size: 14px;
}

.actions {
  margin-top: 30px;
  text-align: center;
}

.test-content {
  padding: 20px 0;
}

.test-buttons {
  display: flex;
  gap: 10px;
  flex-wrap: wrap;
  margin-top: 15px;
}

.test-buttons .el-button {
  flex: 1;
  min-width: 120px;
}
</style>