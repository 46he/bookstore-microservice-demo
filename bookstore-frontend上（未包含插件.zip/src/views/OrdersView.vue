<template>
  <div class="orders-view">
    <el-card>
      <template #header>
        <div class="header">
          <h2>我的订单</h2>
          <div>
            <el-button type="primary" @click="loadLocalOrders" :loading="loading" size="small">刷新订单</el-button>
            <el-button type="warning" @click="syncFromBackend" size="small">同步后端订单</el-button>
          </div>
        </div>
      </template>

      <el-alert v-if="error" :title="error" type="error" show-icon />

      <el-table :data="displayOrders" stripe v-loading="loading" empty-text="暂无订单">
        <el-table-column label="商品信息" min-width="220">
          <template #default="{ row }">
            <div class="product-info">
              <div class="product-image-wrapper">
                <img :src="row.productImageUrl || '/default-cover.png'" class="product-image" />
                <div class="book-type-badge" :class="row.orderType === 1 ? 'ebook' : 'paper'">
                  {{ row.orderType === 1 ? '📱 电子书' : '📚 纸质书' }}
                </div>
              </div>
              <div class="product-details">
                <p class="product-title">{{ row.productTitle || `订单 ${row.id}` }}</p>
                <p class="product-meta">数量: {{ row.productCount || 1 }}</p>
              </div>
            </div>
          </template>
        </el-table-column>
        <el-table-column prop="id" label="订单号" width="180" />
        <el-table-column label="金额" width="100">
          <template #default="{ row }">¥{{ (row.actualPaid || row.amount) }}</template>
        </el-table-column>
        <el-table-column label="状态" width="100">
          <template #default="{ row }">
            <el-tag :type="statusMap[row.status]?.type || 'info'">
              {{ statusMap[row.status]?.text || '未知' }}
            </el-tag>
          </template>
        </el-table-column>
        <el-table-column label="下单时间" width="160">
          <template #default="{ row }">{{ formatDate(row.createTime) }}</template>
        </el-table-column>
        <el-table-column label="操作" width="200" fixed="right">
          <template #default="{ row }">
            <div class="action-buttons">
              <el-button v-if="row.status === 0" type="success" size="small" @click="showPayDialog(row)">支付</el-button>
              <el-button v-if="row.status === 0" type="danger" size="small" @click="handleCancel(row)">取消</el-button>
              <el-button type="primary" size="small" @click="viewOrderDetail(row.id)">详情</el-button>
            </div>
          </template>
        </el-table-column>
      </el-table>
    </el-card>

    <!-- 模拟支付二维码弹窗 -->
    <el-dialog v-model="qrDialogVisible" title="扫码支付（演示模式）" width="360px" center>
      <div style="text-align: center;">
        <div style="background: #fff; padding: 20px; border-radius: 12px; display: inline-block;">
          <img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAGQAAABkCAYAAABw4pVUAAAABHNCSVQICAgIfAhkiAAAAAlwSFlzAAAN1wAADdcBQiibeAAAABl0RVh0U29mdHdhcmUAd3d3Lmlua3NjYXBlLm9yZ5vuPBoAAAJPSURBVHic7Z1PSiRBFMefAS9h0As4nsBdL+AZBE+g3kDwBILu3cWNu+lGRMhAQERciIiIiIjIP2ZmZU/3pKeqq7u6KzKi+MAH1VXv1/v1uirzI0mSJEmSJEmSJEnSntpoFACNMgAgDcBnAJ/GgUzLLgDAGgcCQGtYFyN4MA4EgNaAAOtrNBoA0iij0TQQAApAazSads6oPgBpTQwHhLQhhB0j+2mMAXYBtBk8qCEMnD4CsGuvGa+AQBrCxsEzAK3REQ4EMx/AnmX2GQAkhAEDBwBojTQIHZ+3AUjjwIIBAEjjQAAQhAUDHMYxAmmtA+FwISAwhBfpeSGOB/VDANIQ5ngwAADzUa9nL83Ml6b2DQBIQ3h4MN9YMNnzGQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACAP+M6in80bQBEY3gFP1j9PEE4CicAiN5AL+Dg9Tm2AAIA0fYtE60xFgACQDQh+x4NEV/rXSgAooW1MxAAifYA0RgAAIAY6wAg2nUcCyAO4EEcgnEiYP/zH7v+x4qA/e2J2P8MiYCNrYm7/hpB7H/iON4fI4j9T2QebzMi9j+ReXwJROx/IvP4LQjZ/0Tm8V8Qpf+JzONoELF/aONL0EFE61/k8f8g2gfhyOOXIOr7GHn8J4jYv48snggR+3eR+fsOsf/zZ+FvP0Ts/8qY+fsJYv+Xh+z/H1K+mCH2f33M/n8Hsf+HxOz/bxD7nyAIIPY/SQiEEEIIAUTrX+aPEEIIgYj9T/CIiIiIiIjI/+QdCJrwpeONhFAAAAAASUVORK5CYII=" style="width: 200px; height: 200px;" />
          <p style="margin-top: 16px; color: #666;">请使用微信/支付宝扫码<br>（演示模式，点击确定即支付成功）</p>
        </div>
      </div>
      <template #footer>
        <el-button @click="qrDialogVisible = false">取消</el-button>
        <el-button type="primary" @click="confirmPay">确认支付</el-button>
      </template>
    </el-dialog>
  </div>
</template>

<script setup>
import { ref, computed, onMounted } from 'vue'
import { useRouter } from 'vue-router'
import { useUserStore } from '../stores/user'
import { orderApi, bookApi } from '../api'
import { ElMessage, ElMessageBox } from 'element-plus'

const router = useRouter()
const userStore = useUserStore()

const localOrders = ref([])
const loading = ref(false)
const error = ref(null)
const qrDialogVisible = ref(false)
let currentPayOrder = null

const statusMap = {
  0: { text: '待支付', type: 'warning' },
  1: { text: '已支付', type: 'success' },
  2: { text: '已取消', type: 'danger' },
  3: { text: '已完成', type: 'success' }
}

const formatDate = (dateStr) => {
  if (!dateStr) return ''
  try {
    return new Date(dateStr).toLocaleString()
  } catch (e) {
    return dateStr
  }
}

// 保存电子书到我的图书（通过 bookId 重新获取完整信息）
const saveEBookByBookId = async (bookId, order) => {
  try {
    const res = await bookApi.getById(bookId)
    const book = res.data
    if (!book) return false
    const bookInfo = {
      id: book.id,
      title: book.title,
      author: book.author,
      imageUrl: book.imageUrl,
      fileUrl: book.fileUrl,
      epubUrl: book.epubUrl || (book.fileUrl ? book.fileUrl.replace(/\.html$/i, '.epub') : ''),
      type: 1
    }
    let myBooks = []
    const stored = localStorage.getItem('my_ebooks')
    if (stored) {
      try { myBooks = JSON.parse(stored) } catch(e) {}
    }
    const exists = myBooks.some(b => b.id === bookInfo.id)
    if (!exists) {
      myBooks.push(bookInfo)
      localStorage.setItem('my_ebooks', JSON.stringify(myBooks))
      window.dispatchEvent(new CustomEvent('ebook-purchased', { detail: bookInfo }))
      return true
    }
    return false
  } catch (err) {
    console.error('保存电子书失败', err)
    return false
  }
}

// 更新本地订单状态
const updateLocalOrderStatus = (orderId, newStatus, extra = {}) => {
  const stored = localStorage.getItem('my_orders')
  if (stored) {
    try {
      let orders = JSON.parse(stored)
      const index = orders.findIndex(o => String(o.id) === String(orderId))
      if (index !== -1) {
        orders[index].status = newStatus
        Object.assign(orders[index], extra)
        localStorage.setItem('my_orders', JSON.stringify(orders))
        const localIdx = localOrders.value.findIndex(o => String(o.id) === String(orderId))
        if (localIdx !== -1) {
          localOrders.value[localIdx].status = newStatus
          Object.assign(localOrders.value[localIdx], extra)
        }
      }
    } catch (e) {}
  }
}

const showPayDialog = (order) => {
  currentPayOrder = order
  qrDialogVisible.value = true
}

const confirmPay = async () => {
  if (!currentPayOrder) return
  const order = currentPayOrder
  qrDialogVisible.value = false

  try {
    // 1. 调用后端支付接口（忽略错误）
    orderApi.pay(order.id).catch(e => console.warn('支付后端失败', e))

    // 2. 获取订单中的商品信息（第一个商品）
    let bookId = null
    if (order.items && order.items.length) {
      bookId = order.items[0].productId
    } else if (order.productId) {
      bookId = order.productId
    }

    // 3. 更新本地订单状态（如果是电子书且支付成功，则添加到我的图书）
    const isEbook = order.orderType === 1 && bookId
    if (isEbook) {
      const success = await saveEBookByBookId(bookId, order)
      if (success) {
        ElMessage.success('支付成功，电子书已添加到“我的图书”')
      } else {
        ElMessage.warning('支付成功，但电子书添加失败，可稍后手动刷新')
      }
    } else {
      ElMessage.success('支付成功')
    }

    // 更新订单状态（待支付 → 已支付/已完成）
    const newStatus = (isEbook && order.orderType === 1) ? 3 : 1
    const extra = (isEbook && order.orderType === 1) ? { deliveryStatus: 2, status: 3 } : { deliveryStatus: 0, status: 1 }
    updateLocalOrderStatus(order.id, newStatus, extra)
    loadLocalOrders()
  } catch (err) {
    ElMessage.error('支付失败，请重试')
  } finally {
    currentPayOrder = null
  }
}

const handleCancel = async (order) => {
  try {
    await ElMessageBox.confirm('确认取消订单吗？', '提示', { type: 'warning' })
    orderApi.cancel(order.id).catch(e => console.warn('取消后端失败', e))
    updateLocalOrderStatus(order.id, 2)
    ElMessage.success('订单已取消')
    loadLocalOrders()
  } catch (err) {
    if (err !== 'cancel') ElMessage.error('取消失败，请重试')
  }
}

const loadLocalOrders = () => {
  const stored = localStorage.getItem('my_orders')
  if (stored) {
    try {
      localOrders.value = JSON.parse(stored)
      localOrders.value.sort((a, b) => new Date(b.createTime) - new Date(a.createTime))
    } catch (e) { localOrders.value = [] }
  } else {
    localOrders.value = []
  }
}

const syncFromBackend = async () => {
  loading.value = true
  error.value = null
  try {
    const res = await orderApi.getUserOrdersPage(1, 100, null)
    const backendOrders = res.data.records || []
    if (backendOrders.length > 0) {
      let merged = [...localOrders.value]
      for (const backendOrder of backendOrders) {
        if (!merged.some(o => o.id === backendOrder.id)) merged.push(backendOrder)
      }
      merged.sort((a, b) => new Date(b.createTime) - new Date(a.createTime))
      localStorage.setItem('my_orders', JSON.stringify(merged))
      localOrders.value = merged
      ElMessage.success(`同步成功，共 ${backendOrders.length} 条新订单`)
    } else {
      ElMessage.info('后端暂无订单')
    }
  } catch (err) {
    error.value = '同步失败'
    ElMessage.error('同步订单失败')
  } finally { loading.value = false }
}

const viewOrderDetail = (orderId) => router.push(`/orders/${orderId}`)
const displayOrders = computed(() => localOrders.value)

onMounted(() => {
  loadLocalOrders()
  window.addEventListener('order-paid', () => loadLocalOrders())
})
</script>

<style scoped>
/* 不变 */
.orders-view {
  max-width: 1400px;
  margin: 0 auto;
  padding: 20px;
}
.header {
  display: flex;
  justify-content: space-between;
  align-items: center;
}
.product-info {
  display: flex;
  align-items: center;
  gap: 12px;
}
.product-image {
  width: 60px;
  height: 60px;
  object-fit: cover;
  border-radius: 4px;
  border: 1px solid #e4e7ed;
  background-color: #f5f7fa;
  flex-shrink: 0;
}
.product-details {
  flex: 1;
  min-width: 0;
}
.product-title {
  margin: 0 0 4px 0;
  font-weight: 500;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}
.product-meta {
  margin: 0;
  font-size: 12px;
  color: #909399;
}
.action-buttons {
  display: flex;
  gap: 8px;
  justify-content: center;
}
.action-btn {
  flex: 1;
  min-width: 0;
  margin: 0 !important;
}
</style>