<template>
  <div class="home-container">
    <!-- 轮播图：使用固定高度，图片 object-fit: cover -->
    <el-carousel :interval="4000" type="card" height="320px" class="carousel">
      <el-carousel-item v-for="item in banners" :key="item.id">
        <div class="banner-item">
          <img :src="item.image" :alt="item.text" class="banner-image" />
          <div class="banner-text">{{ item.text }}</div>
        </div>
      </el-carousel-item>
    </el-carousel>

    <!-- 类型标签页切换 -->
    <el-tabs v-model="activeType" @tab-change="handleTypeChange" class="book-tabs">
      <el-tab-pane label="全部图书" name="all"></el-tab-pane>
      <el-tab-pane label="电子书" name="ebook"></el-tab-pane>
      <el-tab-pane label="纸质书" name="paper"></el-tab-pane>
    </el-tabs>

    <!-- 搜索栏 -->
    <div class="search-section">
      <div class="search-bar">
        <el-input
          v-model="keyword"
          placeholder="输入书名、作者或分类"
          clearable
          size="large"
          style="width:400px"
          @input="searchBooks"
        >
          <template #prefix><el-icon><Search /></el-icon></template>
        </el-input>
        <el-button type="primary" size="large" @click="searchBooks">搜索</el-button>
      </div>

      <!-- 分类标签（A-Z 中图法） -->
      <div class="category-tabs">
        <el-radio-group v-model="currentCategory" size="large" @change="filterByCategory">
          <el-radio-button value="">全部</el-radio-button>
          <el-radio-button value="A">A 马列主义</el-radio-button>
          <el-radio-button value="B">B 哲学宗教</el-radio-button>
          <el-radio-button value="C">C 社科总论</el-radio-button>
          <el-radio-button value="D">D 政治法律</el-radio-button>
          <el-radio-button value="E">E 军事</el-radio-button>
          <el-radio-button value="F">F 经济</el-radio-button>
          <el-radio-button value="G">G 文化科教</el-radio-button>
          <el-radio-button value="H">H 语言文字</el-radio-button>
          <el-radio-button value="I">I 文学</el-radio-button>
          <el-radio-button value="J">J 艺术</el-radio-button>
          <el-radio-button value="K">K 历史地理</el-radio-button>
          <el-radio-button value="N">N 自科总论</el-radio-button>
          <el-radio-button value="O">O 数理化</el-radio-button>
          <el-radio-button value="P">P 天文学地球</el-radio-button>
          <el-radio-button value="Q">Q 生物科学</el-radio-button>
          <el-radio-button value="R">R 医药卫生</el-radio-button>
          <el-radio-button value="S">S 农业科学</el-radio-button>
          <el-radio-button value="T">T 工业技术</el-radio-button>
          <el-radio-button value="U">U 交通运输</el-radio-button>
          <el-radio-button value="V">V 航空航天</el-radio-button>
          <el-radio-button value="X">X 环境安全</el-radio-button>
          <el-radio-button value="Z">Z 综合图书</el-radio-button>
        </el-radio-group>
      </div>
    </div>

    <!-- 图书网格：加载时显示骨架屏 -->
    <SkeletonLoader v-if="loading" />
    <div v-else class="book-grid">
      <div
        v-for="book in books"
        :key="book.id"
        class="book-card"
        @click="goToDetail(book.id)"
      >
        <div class="book-cover">
          <img
            :src="book.imageUrl || `https://picsum.photos/200/280?random=${book.id}`"
            :alt="book.title"
            loading="lazy"
          />
          <div class="book-type-badge" :class="book.type === 1 ? 'ebook' : 'paper'">
            {{ book.type === 1 ? '📱 电子书' : '📚 纸质书' }}
          </div>
          <div v-if="book.stock <= 0 && book.type === 2" class="out-of-stock">已售罄</div>
        </div>
        <div class="book-info">
          <h3>{{ book.title }}</h3>
          <p>作者：{{ book.author }}</p>
          <p>分类：{{ book.category }}</p>
          <div class="price">¥{{ book.price }}</div>
          <div class="stock" :class="{ 'out': book.stock <= 0 && book.type === 2 }">
            {{ book.type === 1 ? '无限库存' : `库存 ${book.stock}` }}
          </div>
          <el-button type="danger" size="small" @click.stop="addToCart(book)">加入购物车</el-button>
        </div>
      </div>
    </div>

    <!-- 分页 -->
    <div class="pagination" v-if="total > 0">
      <el-pagination
        background
        layout="prev, pager, next"
        :total="total"
        :page-size="pageSize"
        v-model:current-page="pageNum"
        @current-change="loadBooks"
      />
    </div>
  </div>
</template>

<script setup>
import { ref, onMounted, watch } from 'vue'
import { useRouter, useRoute } from 'vue-router'
import { bookApi } from '../api'
import { useCartStore } from '../stores/cart'
import { useUserStore } from '../stores/user'
import { ElMessage } from 'element-plus'
import { Search } from '@element-plus/icons-vue'
import SkeletonLoader from '../components/SkeletonLoader.vue'

const router = useRouter()
const route = useRoute()
const cartStore = useCartStore()
const userStore = useUserStore()

const books = ref([])
const total = ref(0)
const pageNum = ref(1)
const pageSize = ref(12)
const keyword = ref('')
const currentCategory = ref('')
const loading = ref(false)
const activeType = ref('all')

const banners = [
  { id: 1, image: 'https://picsum.photos/1200/320?random=1', text: '春季读书节 满100减30' },
  { id: 2, image: 'https://picsum.photos/1200/320?random=2', text: '新书首发 全场包邮' }
]

const loadBooks = async () => {
  loading.value = true
  try {
    let typeParam = null
    if (activeType.value === 'ebook') typeParam = 1
    if (activeType.value === 'paper') typeParam = 2
    
    const res = await bookApi.search({
      pageNum: pageNum.value,
      pageSize: pageSize.value,
      keyword: keyword.value,
      category: currentCategory.value,
      type: typeParam
    })
    books.value = res.data.records || []
    total.value = res.data.total || 0
  } catch (err) {
    ElMessage.error('加载图书失败')
    console.error(err)
  } finally {
    loading.value = false
  }
}

const searchBooks = () => {
  pageNum.value = 1
  loadBooks()
}

const filterByCategory = () => {
  pageNum.value = 1
  loadBooks()
}

const handleTypeChange = () => {
  pageNum.value = 1
  loadBooks()
}

const goToDetail = (id) => router.push(`/book/${id}`)

const addToCart = (book) => {
  if (!userStore.isLogin) {
    ElMessage.warning('请先登录')
    router.push('/login')
    return
  }
  cartStore.addItem(book, 1)
}

watch(() => route.query.type, (newType) => {
  if (newType === 'ebook') {
    activeType.value = 'ebook'
  } else if (newType === 'paper') {
    activeType.value = 'paper'
  } else if (newType === undefined) {
    activeType.value = 'all'
  }
  loadBooks()
}, { immediate: true })

onMounted(() => {
  loadBooks()
})
</script>

<style scoped>
.home-container {
  max-width: 1400px;
  margin: 0 auto;
}

/* 轮播图样式修复：图片不压扁 */
.carousel {
  margin-bottom: 20px;
}
.carousel :deep(.el-carousel__container) {
  height: 320px;
}
.banner-item {
  position: relative;
  width: 100%;
  height: 100%;
  border-radius: 12px;
  overflow: hidden;
}
.banner-image {
  width: 100%;
  height: 100%;
  object-fit: cover;
  display: block;
}
.banner-text {
  position: absolute;
  bottom: 20px;
  left: 20px;
  background: rgba(0,0,0,0.6);
  color: white;
  padding: 6px 12px;
  border-radius: 20px;
  font-size: 14px;
  font-weight: 500;
}

.book-tabs {
  margin: 20px 0;
}
.book-grid {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(260px, 1fr));
  gap: 28px;
  margin-bottom: 40px;
}
.book-card {
  background: white;
  border-radius: 16px;
  overflow: hidden;
  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.08);
  cursor: pointer;
  transition: transform 0.2s;
  position: relative;
}
.book-card:hover {
  transform: translateY(-5px);
}
.book-cover {
  position: relative;
  height: 260px;
  overflow: hidden;
}
.book-cover img {
  width: 100%;
  height: 100%;
  object-fit: cover;
}
.book-type-badge {
  position: absolute;
  top: 10px;
  left: 10px;
  padding: 4px 8px;
  border-radius: 4px;
  font-size: 12px;
  font-weight: bold;
  color: white;
  background: rgba(0,0,0,0.6);
  backdrop-filter: blur(4px);
  z-index: 2;
}
.book-type-badge.ebook {
  background: #409eff;
}
.book-type-badge.paper {
  background: #67c23a;
}
.out-of-stock {
  position: absolute;
  bottom: 10px;
  right: 10px;
  background: rgba(255,255,255,0.9);
  color: #f56c6c;
  padding: 4px 8px;
  border-radius: 4px;
  font-size: 12px;
  font-weight: bold;
}
.book-info {
  padding: 16px;
}
.price {
  font-size: 20px;
  color: #e4393c;
  font-weight: bold;
  margin: 8px 0;
}
.stock {
  font-size: 12px;
  color: #67c23a;
}
.stock.out {
  color: #f56c6c;
}
.pagination {
  display: flex;
  justify-content: center;
  margin-top: 20px;
}
.search-section {
  margin-bottom: 30px;
}
.search-bar {
  display: flex;
  justify-content: center;
  gap: 16px;
  margin-bottom: 20px;
}
.category-tabs {
  display: flex;
  flex-wrap: wrap;
  justify-content: center;
  gap: 8px;
  max-height: 120px;
  overflow-y: auto;
  padding: 8px;
  background: white;
  border-radius: 12px;
}
</style>