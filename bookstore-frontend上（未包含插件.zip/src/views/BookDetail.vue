<template>
  <div class="book-detail">
    <el-card v-loading="loading">
      <template #header>
        <div class="book-title">{{ book.title }}</div>
      </template>

      <el-alert v-if="error" :title="error" type="error" show-icon />

      <div v-else class="detail-container">
        <div class="cover">
          <img
            :src="book.imageUrl || 'https://picsum.photos/300/400'"
            :alt="book.title"
            loading="lazy"
          >
          <div v-if="isOutOfStock" class="out-of-stock">已售罄</div>
        </div>

        <div class="info">
          <h1>{{ book.title }}</h1>
          <p class="author">作者：{{ book.author }}</p>
          <p class="category">分类：{{ book.category }}</p>
          <p class="type">类型：{{ book.type === 1 ? '电子书' : '纸质书' }}</p>

          <div class="price-section">
            <p class="price">价格：¥{{ book.price }}</p>
            <p v-if="book.pointsPrice > 0" class="points-price">或 {{ book.pointsPrice }} 积分</p>
          </div>

          <div class="stats">
            <span>已售 {{ book.purchaseCount || 0 }} 次</span>
            <span :class="{ 'out-stock': isOutOfStock }">库存 {{ book.type === 1 ? '无限' : book.stock }}</span>
          </div>

          <div v-if="book.sellerId && book.sellerId !== 0" class="seller-info">
            <p>卖家：
              <router-link :to="'/seller/' + book.sellerId">{{ sellerName || '卖家' }}</router-link>
            </p>
            <el-button
              v-if="userStore.isLogin && !isFollowing"
              link
              size="small"
              @click="followSeller(book.sellerId)"
            >
              关注卖家
            </el-button>
            <el-tag v-if="isFollowing" type="success" size="small">已关注</el-tag>
          </div>
          <p v-else class="seller-info">卖家：平台自营</p>

          <div class="action-section">
            <div class="quantity">
              <label>数量：</label>
              <el-input-number
                v-model="count"
                :min="1"
                :max="book.type === 1 ? 999 : book.stock"
                :disabled="isOutOfStock"
                size="small"
              />
            </div>

            <div class="buttons">
              <el-button type="danger" @click="addToCart" :disabled="isOutOfStock" size="large">
                加入购物车
              </el-button>
              <el-button type="primary" @click="buyNow" :disabled="isOutOfStock" size="large">
                立即购买
              </el-button>

              <!-- 阅读按钮：仅当已购买或免费时显示 -->
              <el-button
                v-if="canRead"
                type="success"
                size="large"
                @click="readBook"
              >
                阅读电子书
              </el-button>
            </div>
          </div>
        </div>
      </div>

      <div v-if="book.description" class="description">
        <h3>内容简介</h3>
        <p>{{ book.description }}</p>
      </div>

      <el-divider />
      <div class="reviews">
        <h3>用户评论</h3>
        <!-- 评论表单和列表保持不变，省略避免重复 -->
        <div v-if="userStore.isLogin" class="review-form">
          <el-rate v-model="newRating" :max="5" />
          <el-input
            type="textarea"
            v-model="newComment"
            placeholder="写下你的评价..."
            :rows="3"
            maxlength="500"
            show-word-limit
          />
          <el-button type="primary" @click="submitReview" :loading="reviewsLoading">发表评论</el-button>
        </div>
        <div v-else class="login-prompt">
          <el-alert title="请先登录后发表评论" type="info" :closable="false" />
        </div>

        <div class="review-list" v-loading="reviewsLoading">
          <div v-if="reviews.length === 0" class="no-reviews">暂无评论</div>
          <div v-else>
            <div v-for="rev in reviews" :key="rev.id" class="review-item">
              <div class="review-header">
                <div class="user">用户{{ rev.userId }}</div>
                <el-rate v-model="rev.rating" disabled show-score text-color="#ff9900" />
                <div class="review-actions">
                  <el-button
                    v-if="userStore.isLogin && rev.userId === userStore.user.id"
                    type="danger"
                    size="small"
                    link
                    @click="handleDeleteReview(rev.id)"
                    :loading="deletingReviewId === rev.id"
                  >删除</el-button>
                </div>
              </div>
              <div class="comment">{{ rev.comment || rev.content }}</div>
              <div class="time">{{ formatDate(rev.createdAt) }}</div>
            </div>
          </div>
        </div>

        <el-pagination
          v-if="reviewTotal > reviewPageSize"
          background
          layout="prev, pager, next"
          :total="reviewTotal"
          :page-size="reviewPageSize"
          v-model:current-page="reviewPage"
          @current-change="loadReviews"
        />
      </div>
    </el-card>
  </div>
</template>

<script setup>
import { onMounted, computed } from 'vue'
import { useRoute, useRouter } from 'vue-router'
import { ElMessage, ElMessageBox } from 'element-plus'
import { useCartStore } from '../stores/cart'
import { useUserStore } from '../stores/user'
import { useBookDetail } from '../composables/useBookDetail'

const route = useRoute()
const router = useRouter()
const cartStore = useCartStore()
const userStore = useUserStore()

const {
  book,
  count,
  hasPurchased,
  reviews,
  newRating,
  newComment,
  reviewPage,
  reviewPageSize,
  reviewTotal,
  sellerName,
  isFollowing,
  loading,
  reviewsLoading,
  error,
  isOutOfStock,
  loadBook,
  loadReviews,
  submitReview,
  addToCart,
  buyNow,
  formatDate,
  deleteReview,
  deletingReviewId
} = useBookDetail(userStore, cartStore, router)

// 阅读：已购买且为电子书时，跳转到阅读器
const readBook = () => {
  if (book.value.type !== 1) {
    ElMessage.warning('只有电子书支持在线阅读')
    return
  }
  if (!hasPurchased.value && book.value.isFree !== 1) {
    ElMessage.warning('请先购买')
    return
  }
  router.push(`/reader/${book.value.id}`)
}

const canRead = computed(() => {
  return book.value.type === 1 && (hasPurchased.value || book.value.isFree === 1)
})

const handleDeleteReview = async (reviewId) => {
  try {
    await ElMessageBox.confirm('确定删除这条评论吗？', '提示', { type: 'warning' })
    await deleteReview(reviewId)
  } catch (err) {
    if (err !== 'cancel') ElMessage.error(err.message || '删除失败')
  }
}

const saveBrowseHistory = (book) => {
  try {
    const stored = localStorage.getItem('browse_history')
    let history = stored ? JSON.parse(stored) : []
    history = history.filter(item => item.id !== book.id)
    history.unshift({
      id: book.id,
      title: book.title,
      author: book.author,
      category: book.category,
      price: book.price,
      type: book.type,
      imageUrl: book.imageUrl,
      browseTime: new Date().toISOString()
    })
    if (history.length > 30) history.pop()
    localStorage.setItem('browse_history', JSON.stringify(history))
  } catch (e) {}
}

const originalLoadBook = loadBook
const enhancedLoadBook = async (id) => {
  await originalLoadBook(id)
  if (book.value && book.value.id) saveBrowseHistory(book.value)
}

onMounted(async () => {
  const id = route.params.id
  await enhancedLoadBook(id)
  await loadReviews()
})
</script>


<style scoped>
/* 保持不变，复用你原有的样式 */
.book-detail { max-width: 1200px; margin: 20px auto; padding: 0 20px; }
.detail-container { display: flex; gap: 40px; flex-wrap: wrap; }
.cover { flex: 0 0 300px; position: relative; }
.cover img { width: 100%; border-radius: 8px; box-shadow: 0 2px 12px rgba(0,0,0,0.1); }
.out-of-stock { position: absolute; top: 10px; right: 10px; background: rgba(0,0,0,0.7); color: #fff; padding: 4px 8px; border-radius: 4px; font-size: 12px; }
.info { flex: 1; }
.info h1 { font-size: 24px; margin-bottom: 12px; }
.author, .category, .type { color: #666; margin: 8px 0; }
.price-section { margin: 16px 0; }
.price { font-size: 24px; color: #e4393c; font-weight: bold; }
.points-price { color: #ff9800; }
.stats { display: flex; gap: 20px; color: #666; margin: 12px 0; }
.seller-info { margin: 12px 0; }
.action-section { margin-top: 20px; }
.quantity { margin-bottom: 16px; }
.buttons { display: flex; gap: 16px; flex-wrap: wrap; }
.description { margin-top: 30px; }
.description h3 { margin-bottom: 12px; }
.reviews { margin-top: 30px; }
.review-form { margin-bottom: 30px; }
.review-item { border-bottom: 1px solid #eee; padding: 16px 0; }
.review-header { display: flex; align-items: center; gap: 16px; margin-bottom: 8px; }
.user { font-weight: bold; }
.comment { color: #333; line-height: 1.5; margin: 10px 0; }
.time { color: #999; font-size: 12px; }
.no-reviews { text-align: center; padding: 40px; color: #999; }
.login-prompt { margin-bottom: 30px; }
</style>