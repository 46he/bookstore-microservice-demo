<template>
  <div class="profile-container">
    <el-card class="profile-card" v-loading="loading">
      <template #header>
        <div class="card-header">
          <span>个人中心</span>
          <el-button type="primary" size="small" @click="doSignIn" :loading="signInLoading">每日签到</el-button>
        </div>
      </template>

      <el-alert v-if="error" :title="error" type="error" show-icon />

      <el-descriptions :column="2" border>
        <el-descriptions-item label="用户名">{{ userStore.user?.username }}</el-descriptions-item>
        <el-descriptions-item label="积分余额">{{ userStore.user?.points || 0 }}</el-descriptions-item>
        <el-descriptions-item label="会员等级">{{ levelName }}</el-descriptions-item>
        <el-descriptions-item label="累计消费">¥{{ userStore.user?.totalConsumption || 0 }}</el-descriptions-item>
        <el-descriptions-item label="手机号">{{ userStore.user?.phone || '未绑定' }}</el-descriptions-item>
      </el-descriptions>

      <el-divider />
      <h3>收货地址</h3>
      <el-button type="primary" size="small" @click="openAddressDialog(null)">新增地址</el-button>

      <el-table :data="addresses" stripe v-if="addresses && addresses.length > 0">
        <el-table-column prop="receiverName" label="收货人" width="120" />
        <el-table-column prop="phone" label="电话" width="140" />
        <el-table-column label="地址" min-width="250">
          <template #default="{ row }">
            {{ row.province }} {{ row.city }} {{ row.district }} {{ row.detail }}
          </template>
        </el-table-column>
        <el-table-column label="默认" width="80">
          <template #default="{ row }">
            <el-tag v-if="row.isDefault === 1" type="success">默认</el-tag>
          </template>
        </el-table-column>
        <el-table-column label="操作" width="220" fixed="right">
          <template #default="{ row }">
            <div class="action-buttons">
              <el-button size="small" @click="openAddressDialog(row)">编辑</el-button>
              <el-button size="small" @click="setDefault(row.id)">设为默认</el-button>
              <el-button size="small" type="danger" @click="deleteAddress(row.id)">删除</el-button>
            </div>
          </template>
        </el-table-column>
      </el-table>
      <el-empty v-else description="暂无收货地址，请点击新增" />

      <el-divider />
      <h3>关注的卖家</h3>
      <div class="follow-list">
        <div v-for="sellerId in followedSellers" :key="sellerId" class="follow-item">
          <router-link :to="'/seller/' + sellerId">卖家 {{ sellerId }}</router-link>
          <el-button size="small" type="danger" @click="unfollow(sellerId)">取消关注</el-button>
        </div>
      </div>

      <el-divider />
      <h3>我的优惠券</h3>
      <div class="coupon-list">
        <div v-for="uc in userCoupons" :key="uc.id" class="coupon-item">
          <span>{{ uc.couponName }} - 减免 ¥{{ uc.discountAmount }}</span>
          <span>有效期至 {{ uc.expireDate }}</span>
        </div>
      </div>

      <el-divider />
      <h3>账号设置</h3>
      <div class="settings-links">
        <router-link to="/notification-settings" class="settings-link">
          <el-icon><Bell /></el-icon>
          通知设置
        </router-link>
      </div>

      <div class="logout-btn">
        <el-button type="danger" @click="handleLogout">退出登录</el-button>
      </div>
    </el-card>

    <!-- 地址对话框（独立省市输入框） -->
    <el-dialog v-model="showAddressDialog" :title="editingAddress ? '编辑地址' : '新增地址'" width="500px">
      <el-form :model="addressForm" :rules="addressRules" ref="addressFormRef" label-width="80px">
        <el-form-item label="收货人" prop="receiverName">
          <el-input v-model="addressForm.receiverName" placeholder="请输入收货人姓名" />
        </el-form-item>
        <el-form-item label="电话" prop="phone">
          <el-input v-model="addressForm.phone" placeholder="请输入联系电话" />
        </el-form-item>
        <el-form-item label="省份" prop="province">
          <el-input v-model="addressForm.province" placeholder="省/直辖市" />
        </el-form-item>
        <el-form-item label="城市" prop="city">
          <el-input v-model="addressForm.city" placeholder="市" />
        </el-form-item>
        <el-form-item label="区/县" prop="district">
          <el-input v-model="addressForm.district" placeholder="区/县" />
        </el-form-item>
        <el-form-item label="详细地址" prop="detail">
          <el-input v-model="addressForm.detail" placeholder="街道、门牌号" />
        </el-form-item>
        <el-form-item label="设为默认">
          <el-switch v-model="addressForm.isDefault" :active-value="1" :inactive-value="0" />
        </el-form-item>
      </el-form>
      <template #footer>
        <el-button @click="showAddressDialog = false">取消</el-button>
        <el-button type="primary" @click="submitAddress" :loading="submittingAddress">确定</el-button>
      </template>
    </el-dialog>
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue'
import { useUserStore } from '../stores/user'
import { useRouter } from 'vue-router'
import { ElMessage } from 'element-plus'
import { Bell } from '@element-plus/icons-vue'
import { useProfile } from '../composables/useProfile'

const userStore = useUserStore()
const router = useRouter()

const {
  addresses,
  followedSellers,
  userCoupons,
  loading,
  error,
  levelName,
  signInLoading,
  addAddress,
  updateAddress,
  setDefault,
  deleteAddress,
  unfollow,
  doSignIn,
  loadAll
} = useProfile(userStore)

const showAddressDialog = ref(false)
const submittingAddress = ref(false)
const editingAddress = ref(null)
const addressFormRef = ref(null)

const addressForm = ref({
  id: null,
  receiverName: '',
  phone: '',
  province: '',
  city: '',
  district: '',
  detail: '',
  isDefault: 0
})

const addressRules = {
  receiverName: [{ required: true, message: '请输入收货人姓名', trigger: 'blur' }],
  phone: [
    { required: true, message: '请输入联系电话', trigger: 'blur' },
    { pattern: /^1[3-9]\d{9}$/, message: '请输入正确的手机号码', trigger: 'blur' }
  ],
  province: [{ required: true, message: '请输入省份', trigger: 'blur' }],
  city: [{ required: true, message: '请输入城市', trigger: 'blur' }],
  district: [{ required: true, message: '请输入区/县', trigger: 'blur' }],
  detail: [{ required: true, message: '请输入详细地址', trigger: 'blur' }]
}

const openAddressDialog = (address) => {
  if (address) {
    editingAddress.value = address
    addressForm.value = {
      id: address.id,
      receiverName: address.receiverName,
      phone: address.phone,
      province: address.province || '',
      city: address.city || '',
      district: address.district || '',
      detail: address.detail,
      isDefault: address.isDefault === 1 ? 1 : 0
    }
  } else {
    editingAddress.value = null
    addressForm.value = {
      id: null,
      receiverName: '',
      phone: '',
      province: '',
      city: '',
      district: '',
      detail: '',
      isDefault: 0
    }
  }
  showAddressDialog.value = true
}

const submitAddress = async () => {
  try {
    await addressFormRef.value.validate()
    submittingAddress.value = true
    const form = addressForm.value
    const addressData = {
      id: form.id,
      userId: userStore.user.id,
      receiverName: form.receiverName,
      phone: form.phone,
      province: form.province,
      city: form.city,
      district: form.district,
      detail: form.detail,
      isDefault: form.isDefault
    }
    let success
    if (editingAddress.value) {
      success = await updateAddress(addressData)
    } else {
      success = await addAddress(addressData)
    }
    if (success) {
      showAddressDialog.value = false
      await loadAll()
    }
  } catch (err) {
    console.error('地址提交失败', err)
    ElMessage.error('提交失败，请检查表单')
  } finally {
    submittingAddress.value = false
  }
}

const handleLogout = () => {
  userStore.logout()
  router.push('/login')
}

onMounted(() => {
  loadAll()
})
</script>

<style scoped>
.profile-container {
  max-width: 1000px;
  margin: 0 auto;
}
.profile-card {
  border-radius: 16px;
}
.card-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
}
.follow-list, .coupon-list {
  margin-top: 10px;
}
.follow-item, .coupon-item {
  display: flex;
  justify-content: space-between;
  padding: 8px;
  border-bottom: 1px solid #eee;
}
.settings-links {
  display: flex;
  gap: 15px;
  flex-wrap: wrap;
}
.settings-link {
  display: flex;
  align-items: center;
  gap: 8px;
  padding: 10px 15px;
  border: 1px solid #dcdfe6;
  border-radius: 4px;
  text-decoration: none;
  color: #606266;
  transition: all 0.3s;
}
.settings-link:hover {
  border-color: #409eff;
  color: #409eff;
  background-color: #ecf5ff;
}
.logout-btn {
  margin-top: 30px;
  text-align: center;
}
.action-buttons {
  display: flex;
  gap: 6px;
  flex-wrap: nowrap;
}
.action-buttons .el-button {
  margin: 0;
  padding: 5px 8px;
}
</style>