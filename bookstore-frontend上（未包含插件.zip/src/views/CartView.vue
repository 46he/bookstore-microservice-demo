<template>
  <div class="cart">
    <el-card v-loading="loading">
      <template #header>购物车</template>

      <el-alert v-if="error" :title="error" type="error" show-icon />

      <el-empty v-if="cartStore.items.length === 0" description="购物车为空">
        <el-button type="primary" @click="$router.push('/')">去逛逛</el-button>
      </el-empty>

      <div v-else>
        <el-table :data="cartStore.items" stripe>
          <el-table-column prop="title" label="书名" />
          <el-table-column prop="price" label="单价">
            <template #default="{ row }">¥{{ row.price }}</template>
          </el-table-column>
          <el-table-column label="数量">
            <template #default="{ row }">
              <el-input-number
                v-model="row.count"
                :min="1"
                :max="row.stock"
                size="small"
                @change="() => updateCount(row)"
              />
            </template>
          </el-table-column>
          <el-table-column label="小计">
            <template #default="{ row }">¥{{ (row.price * row.count).toFixed(2) }}</template>
          </el-table-column>
          <el-table-column label="操作">
            <template #default="{ row }">
              <el-button type="danger" size="small" @click="cartStore.removeItem(row.id)">删除</el-button>
            </template>
          </el-table-column>
        </el-table>

        <div class="total">总价：¥{{ cartStore.totalPrice.toFixed(2) }}</div>

        <div v-if="userStore.isLogin" class="checkout-section">
          <el-divider />
          <h4>积分抵扣</h4>
          <el-checkbox v-model="usePoints" label="使用积分抵扣" />
          <div v-if="usePoints" class="points-input">
            <el-input-number
              v-model="pointsToUse"
              :min="0"
              :max="maxUsablePoints"
              :step="1"
              placeholder="输入抵扣积分"
            />
            <p>可用积分：{{ userStore.user?.points || 0 }}，最多可抵扣 ¥{{ maxUsablePoints.toFixed(2) }}</p>
          </div>
          <p class="final-amount">抵扣后应付：¥{{ finalAmount.toFixed(2) }}</p>
        </div>

        <div v-if="needAddress" class="address-section">
          <el-divider />
          <h4>收货地址</h4>
          <el-select v-model="selectedAddressId" placeholder="选择收货地址" filterable>
            <el-option
              v-for="addr in addresses"
              :key="addr.id"
              :label="`${addr.receiverName} ${addr.phone} ${addr.province}${addr.city}${addr.district} ${addr.detail}`"
              :value="addr.id"
            />
          </el-select>
          <el-button type="primary" size="small" @click="$router.push('/profile')">管理地址</el-button>
        </div>

        <div v-if="userStore.isLogin" class="coupon-section">
          <el-divider />
          <h4>优惠券</h4>
          <el-select v-model="selectedCouponId" placeholder="选择优惠券" clearable filterable>
            <el-option
              v-for="uc in userCoupons"
              :key="uc.id"
              :label="`${uc.couponName} - 减免 ¥${uc.discountAmount} (有效期至 ${uc.expireDate})`"
              :value="uc.couponId"
            />
          </el-select>
          <p v-if="selectedCouponId" class="coupon-deduction">已选择优惠券可抵扣 ¥{{ couponDiscount.toFixed(2) }}</p>
        </div>

        <el-divider />
        <div class="checkout-actions">
          <el-button type="primary" @click="createOrder" :loading="ordering" size="large">
            下单
          </el-button>
          <el-button @click="$router.push('/')">继续购物</el-button>
        </div>
      </div>
    </el-card>
  </div>
</template>

<script setup>
import { onMounted } from 'vue'
import { useRouter } from 'vue-router'
import { useCartStore } from '../stores/cart'
import { useUserStore } from '../stores/user'
import { useCartCheckout } from '../composables/useCartCheckout'

const router = useRouter()
const cartStore = useCartStore()
const userStore = useUserStore()

const {
  usePoints,
  pointsToUse,
  selectedAddressId,
  selectedCouponId,
  addresses,
  userCoupons,
  ordering,
  loading,
  error,
  needAddress,
  couponDiscount,
  finalAmount,
  maxUsablePoints,
  updateCount,
  createOrder: originalCreateOrder,
  loadAll
} = useCartCheckout(cartStore, userStore, router)

const createOrder = async () => {
  await originalCreateOrder()
}

onMounted(() => {
  loadAll()
})
</script>

<style scoped>
.cart {
  max-width: 1200px;
  margin: 0 auto;
  padding: 20px;
}
.total {
  font-size: 18px;
  font-weight: bold;
  text-align: right;
  margin: 20px 0;
  color: #e4393c;
}
.checkout-section,
.address-section,
.coupon-section {
  margin: 20px 0;
}
.points-input {
  margin-top: 10px;
}
.points-input p {
  margin: 5px 0;
  color: #666;
}
.coupon-deduction {
  margin-top: 10px;
  color: #67c23a;
}
.checkout-actions {
  text-align: center;
  margin-top: 30px;
}
.checkout-actions .el-button {
  margin: 0 10px;
}
</style>