<template>
  <div>
    <h2>卖家 {{ sellerId }} 的书店</h2>
    <div class="book-grid">
      <div v-for="book in books" :key="book.id" class="book-card" @click="goToDetail(book.id)">
        <img :src="book.imageUrl" />
        <h3>{{ book.title }}</h3>
        <p>¥{{ book.price }}</p>
        <p>已售 {{ book.soldCount }}</p>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue'
import { useRoute, useRouter } from 'vue-router'
import { bookApi } from '../api'

const route = useRoute()
const router = useRouter()
const sellerId = route.params.sellerId
const books = ref([])

onMounted(async () => {
  const res = await bookApi.getSellerBooks(sellerId)
  books.value = res.data
})
const goToDetail = (id) => router.push(`/book/${id}`)
</script>

<style scoped>
.book-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(200px,1fr)); gap:20px; margin-top:20px; }
.book-card { cursor: pointer; border-radius: 8px; overflow: hidden; box-shadow: 0 2px 8px rgba(0,0,0,0.1); }
.book-card img { width:100%; height:240px; object-fit: cover; }
</style>