<template>
  <div class="about-microservice">
    <el-card>
      <template #header>
        <h2>📖 微服务架构设计说明</h2>
      </template>

      <div class="content">
        <section>
          <h3>1. 服务拆分与职责</h3>
          <el-table :data="servicesList" stripe>
            <el-table-column prop="name" label="服务名称" width="180" />
            <el-table-column prop="port" label="端口" width="100" />
            <el-table-column prop="responsibility" label="核心职责" />
          </el-table>
        </section>

        <el-divider />

        <section>
          <h3>2. 技术栈与组件</h3>
          <div class="tech-grid">
            <div v-for="tech in techStack" :key="tech.name" class="tech-card">
              <el-tag :type="tech.type" size="large">{{ tech.name }}</el-tag>
              <p>{{ tech.description }}</p>
            </div>
          </div>
        </section>

        <el-divider />

        <section>
          <h3>3. 分布式解决方案</h3>
          <el-descriptions :column="1" border>
            <el-descriptions-item label="服务注册与发现">
              Nacos – 所有服务启动时自动注册，网关通过 lb:// 协议动态路由
            </el-descriptions-item>
            <el-descriptions-item label="API 网关">
              Spring Cloud Gateway – 统一入口、认证鉴权、路由转发、限流熔断
            </el-descriptions-item>
            <el-descriptions-item label="限流熔断">
              Sentinel – 支持 QPS 限流、熔断降级，可动态配置规则
            </el-descriptions-item>
            <el-descriptions-item label="分布式事务">
              Seata (AT 模式) – 预留，可保证跨服务事务一致性（如下单扣库存 + 扣积分）
            </el-descriptions-item>
            <el-descriptions-item label="服务间通信">
              OpenFeign – 声明式 HTTP 客户端，结合负载均衡调用其他服务
            </el-descriptions-item>
            <el-descriptions-item label="认证与鉴权">
              JWT + Redis 黑名单 – 无状态认证，支持注销/改密后 token 立即失效
            </el-descriptions-item>
            <el-descriptions-item label="数据持久化">
              MyBatis-Plus + MySQL (分库: bookstore_user, bookstore_book, bookstore_order)
            </el-descriptions-item>
            <el-descriptions-item label="缓存">
              Redis – 图书详情缓存、JWT 黑名单、购物车快照（用户服务）
            </el-descriptions-item>
          </el-descriptions>
        </section>

        <el-divider />

        <section>
          <h3>4. 调用链路示例</h3>
          <div class="call-chain">
            <div class="chain-step">🌐 前端 (Vue3)</div>
            <div class="chain-arrow">→</div>
            <div class="chain-step">🚪 网关 (8080)</div>
            <div class="chain-arrow">→</div>
            <div class="chain-step">📦 订单服务 (8083)</div>
            <div class="chain-arrow">→ (Feign)</div>
            <div class="chain-step">📖 图书服务 (8082)</div>
            <div class="chain-arrow">→</div>
            <div class="chain-step">🗄️ MySQL</div>
          </div>
          <p class="note">* 下单流程中，订单服务同时调用图书服务（扣库存）和用户服务（扣积分、使用优惠券）。</p>
        </section>

        <el-divider />

        <section>
          <h3>5. 实验模式说明</h3>
          <el-alert title="实验开关（后端配置）" type="info" :closable="false">
            <ul style="margin: 8px 0 0 20px">
              <li><strong>限流实验</strong>：order-service 中设置 <code>sentinel.flow.enabled=true</code> 开启 QPS 限流</li>
              <li><strong>简化模式</strong>：order-service 中设置 <code>order.simplified-mode.enabled=true</code> 跳过真实业务逻辑，用于纯压测</li>
              <li><strong>熔断实验</strong>：order-service 中设置 <code>sentinel.degrade.enabled=true</code>（需动态配置降级规则）</li>
              <li><strong>分布式事务实验</strong>：启用 Seata Server 并取消注释 seata 配置，即可体验 AT 模式</li>
            </ul>
          </el-alert>
        </section>
      </div>
    </el-card>
  </div>
</template>

<script setup>
const servicesList = [
  { name: 'gateway-service', port: 8080, responsibility: '路由转发、统一认证、限流熔断' },
  { name: 'user-service', port: 8081, responsibility: '用户管理、积分、优惠券、购物车、地址、关注、通知' },
  { name: 'book-service', port: 8082, responsibility: '图书管理、库存扣减、评论、浏览记录、电子书上传' },
  { name: 'order-service', port: 8083, responsibility: '订单创建、支付、取消、物流、卖家统计' }
]

const techStack = [
  { name: 'Spring Boot 2.7.18', description: '微服务基础框架', type: 'primary' },
  { name: 'Spring Cloud 2021.0.9', description: '微服务生态组件', type: 'primary' },
  { name: 'Nacos', description: '服务注册与发现 + 配置中心（预留）', type: 'success' },
  { name: 'Spring Cloud Gateway', description: 'API 网关', type: 'warning' },
  { name: 'Sentinel', description: '限流熔断', type: 'danger' },
  { name: 'Seata', description: '分布式事务（预留）', type: 'info' },
  { name: 'OpenFeign', description: '声明式 HTTP 客户端', type: '' },
  { name: 'MyBatis-Plus', description: 'ORM 框架', type: '' },
  { name: 'Redis', description: '缓存 + JWT 黑名单', type: '' },
  { name: 'JWT', description: '身份认证', type: '' }
]
</script>

<style scoped>
.about-microservice {
  max-width: 1200px;
  margin: 0 auto;
  padding: 20px;
}
.content section {
  margin: 24px 0;
}
.tech-grid {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(240px, 1fr));
  gap: 16px;
  margin-top: 16px;
}
.tech-card {
  background: #f5f7fa;
  border-radius: 12px;
  padding: 16px;
  text-align: center;
  transition: transform 0.2s;
}
.tech-card:hover {
  transform: translateY(-2px);
}
.tech-card p {
  margin: 12px 0 0;
  font-size: 13px;
  color: #606266;
}
.call-chain {
  display: flex;
  flex-wrap: wrap;
  align-items: center;
  justify-content: center;
  gap: 12px;
  background: #f0f9ff;
  padding: 20px;
  border-radius: 12px;
  margin: 16px 0;
}
.chain-step {
  background: #409eff;
  color: white;
  padding: 8px 16px;
  border-radius: 24px;
  font-size: 14px;
}
.chain-arrow {
  font-size: 20px;
  color: #909399;
}
.note {
  color: #909399;
  font-size: 13px;
  text-align: center;
}
</style>