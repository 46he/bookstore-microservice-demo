<template>
  <div class="monitor-container">
    <el-row :gutter="20">
      <el-col :xs="24" :sm="24" :md="12" :lg="12">
        <el-card class="service-card">
          <template #header>
            <div class="card-header">
              <span>微服务实例列表</span>
              <el-tag type="success" size="small">已注册到 Nacos</el-tag>
              <el-button size="small" type="primary" plain @click="refreshHealth">刷新健康状态</el-button>
            </div>
          </template>
          <el-table :data="servicesWithHealth" stripe v-loading="healthLoading">
            <el-table-column prop="name" label="服务名称" />
            <el-table-column prop="address" label="地址" />
            <el-table-column label="健康状态" width="100">
              <template #default="{ row }">
                <el-tag :type="row.healthy ? 'success' : 'danger'" size="small">
                  {{ row.healthy ? '健康' : '异常' }}
                </el-tag>
              </template>
            </el-table-column>
            <el-table-column label="响应时间" width="120">
              <template #default="{ row }">
                <span v-if="row.latency !== undefined && row.latency !== null">{{ row.latency }}ms</span>
                <span v-else>--</span>
              </template>
            </el-table-column>
            <el-table-column label="备注" prop="remark" />
          </el-table>
          <div class="health-note">
            <el-text size="small" type="info">
              * 网关健康由下游服务（用户、图书、订单）推断，至少一个服务健康即表示网关正常
            </el-text>
          </div>
        </el-card>
      </el-col>

      <el-col :xs="24" :sm="24" :md="12" :lg="12">
        <el-card class="tech-card">
          <template #header>
            <span>技术栈与组件</span>
          </template>
          <div class="tech-list">
            <div class="tech-item" v-for="tech in techStack" :key="tech.name">
              <el-tag :type="getTagType(tech.type)" size="small">{{ tech.name }}</el-tag>
              <span>{{ tech.description }}</span>
            </div>
          </div>
        </el-card>
      </el-col>
    </el-row>

    <!-- 调用链路拓扑 -->
    <el-card class="arch-card" style="margin-top: 20px">
      <template #header>
        <span>调用链路拓扑（微服务架构）</span>
      </template>
      <div class="arch-diagram">
        <div class="arch-layer client-layer">
          <div class="arch-node">👤 前端(Vue3)</div>
          <div class="arch-arrow">↓</div>
        </div>
        <div class="arch-layer gateway-layer">
          <div class="arch-node">🚪 网关 (Gateway:8080)</div>
          <div class="arch-arrow">↓</div>
        </div>
        <div class="arch-layer services-layer">
          <div class="service-nodes">
            <div class="arch-node">📖 图书服务<br/>(book-service:8082)</div>
            <div class="arch-node">👥 用户服务<br/>(user-service:8081)</div>
            <div class="arch-node">📦 订单服务<br/>(order-service:8083)</div>
          </div>
          <div class="arch-arrow">↓</div>
        </div>
        <div class="arch-layer infra-layer">
          <div class="infra-nodes">
            <div class="arch-node">🗄️ MySQL</div>
            <div class="arch-node">⚡ Redis</div>
            <div class="arch-node">🌐 Nacos</div>
            <div class="arch-node">⛑️ Sentinel</div>
            <div class="arch-node">📡 Seata (AT模式)</div>
          </div>
        </div>
      </div>
      <div class="arch-note">
        <el-text size="small" type="info">
          * 实际请求路径：浏览器 → 网关 → 根据路由规则转发到对应微服务
        </el-text>
      </div>
    </el-card>

    <!-- 限流与熔断卡片 -->
    <el-row :gutter="20" style="margin-top: 20px">
      <el-col :xs="24" :sm="24" :md="12" :lg="12">
        <el-card class="feature-card">
          <template #header>
            <span>⛑️ 限流与熔断 (Sentinel)</span>
          </template>
          <div>
            <p>网关及订单服务已集成 Sentinel，支持动态限流规则。</p>
            <p><strong>当前状态</strong>：限流功能默认关闭（可通过配置文件开启）</p>
            <p><strong>触发效果</strong>：当 QPS 超过阈值时，后端返回 HTTP 429，前端将显示"请求过于频繁"提示。</p>
            <el-button size="small" type="primary" plain @click="showSentinelTip">查看限流演示说明</el-button>
          </div>
        </el-card>
      </el-col>
      <el-col :xs="24" :sm="24" :md="12" :lg="12">
        <el-card class="feature-card">
          <template #header>
            <span>📡 分布式事务 (Seata)</span>
          </template>
          <div>
            <p>已启用 Seata AT 模式，保证跨服务事务一致性（如下单扣库存 + 扣积分）。</p>
            <p><strong>工作原理</strong>：订单服务作为全局事务起点，调用图书服务和用户服务时自动注册分支事务，任一失败则根据 undo_log 回滚。</p>
            <el-button size="small" type="info" plain @click="showSeataTip">了解 Seata 原理</el-button>
          </div>
        </el-card>
      </el-col>
    </el-row>

    <!-- 压测说明 -->
    <el-row :gutter="20" style="margin-top: 20px">
      <el-col :span="24">
        <el-card class="feature-card">
          <template #header>
            <span>📊 压测演示说明（限流效果验证）</span>
          </template>
          <div>
            <p>使用 JMeter 或 Apache Bench (ab) 对网关地址进行压测，可观察限流效果：</p>
            <pre style="background: #f5f7fa; padding: 12px; border-radius: 8px; overflow-x: auto;">
# 示例：对订单创建接口压测（需先登录获取 token）
# 1. 修改 order-service 配置开启限流（sentinel.flow.enabled=true QPS=100）
# 2. 启动 JMeter，设置线程组 200 个并发，循环 10 次
# 3. 添加 HTTP 请求：POST http://localhost:8080/api/order/create
# 4. 添加 HTTP Header Manager：Authorization: Bearer {token}
# 5. 查看结果树，状态码 200 表示成功，429 表示被限流
# 6. 前端会显示"请求过于频繁，请稍后再试"
            </pre>
            <p class="note">* 压测前请联系管理员确认后端服务资源充足，避免影响其他用户。</p>
            <el-button size="small" type="warning" plain @click="showPerfTip">查看详细压测指导</el-button>
          </div>
        </el-card>
      </el-col>
    </el-row>
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue'
import { ElMessageBox } from 'element-plus'
import request from '../api/request'

// 服务健康检查配置
const services = [
  { 
    name: 'gateway-service', 
    remark: 'API 网关',
    isGateway: true
  },
  { 
    name: 'user-service', 
    healthUrl: '/users/level/1', 
    remark: '用户/购物车/积分/优惠券',
    validateStatus: (status) => status < 500 
  },
  { 
    name: 'book-service', 
    healthUrl: '/book/hot?limit=1', 
    remark: '图书/评论/库存',
    validateStatus: (status) => status < 500 
  },
  { 
    name: 'order-service', 
    healthUrl: '/order/seller/statistics?period=week', 
    remark: '订单/物流/统计',
    validateStatus: (status) => status < 500 
  }
]

const servicesWithHealth = ref([])
const healthLoading = ref(false)

const techStack = ref([
  { name: 'Spring Boot 2.7.18', description: '微服务基础框架', type: 'primary' },
  { name: 'Spring Cloud 2021.0.9', description: '微服务生态组件', type: 'primary' },
  { name: 'Nacos', description: '服务注册与发现', type: 'success' },
  { name: 'Spring Cloud Gateway', description: 'API 网关', type: 'warning' },
  { name: 'Sentinel', description: '限流熔断', type: 'danger' },
  { name: 'Seata', description: '分布式事务（AT模式，已启用）', type: 'info' },
  { name: 'OpenFeign', description: '声明式 HTTP 客户端', type: '' },
  { name: 'MyBatis-Plus', description: 'ORM 框架', type: '' },
  { name: 'Redis', description: '缓存 + JWT 黑名单', type: '' },
  { name: 'JWT', description: '身份认证', type: '' }
])

const getTagType = (type) => {
  const allowed = ['primary', 'success', 'info', 'warning', 'danger']
  return allowed.includes(type) ? type : 'info'
}

const checkHealth = async (service) => {
  if (service.isGateway) {
    return { healthy: false, latency: null, isGateway: true }
  }
  const startTime = performance.now()
  try {
    await request.get(service.healthUrl, {
      timeout: 3000,
      validateStatus: service.validateStatus
    })
    const latency = Math.round(performance.now() - startTime)
    return { healthy: true, latency }
  } catch (error) {
    console.warn(`Health check failed for ${service.name}:`, error.message)
    return { healthy: false, latency: null }
  }
}

const refreshHealth = async () => {
  healthLoading.value = true
  const nonGatewayResults = []
  let gatewayHealthy = false

  for (const service of services) {
    if (!service.isGateway) {
      const { healthy, latency } = await checkHealth(service)
      nonGatewayResults.push({
        name: service.name,
        address: '网关代理',
        healthy,
        latency: latency !== null ? latency : '超时',
        remark: service.remark
      })
      if (healthy) gatewayHealthy = true
    }
  }

  nonGatewayResults.push({
    name: 'gateway-service',
    address: '网关代理',
    healthy: gatewayHealthy,
    latency: gatewayHealthy ? '（由下游推断）' : '超时',
    remark: 'API 网关'
  })

  servicesWithHealth.value = nonGatewayResults
  healthLoading.value = false
}

// 所有弹窗都增加 catch 防止取消时报错
const showSentinelTip = () => {
  ElMessageBox.alert(
    '要体验限流效果，请修改 order-service 或 gateway-service 配置：\n\n' +
    '1. 设置 spring.cloud.sentinel.enabled=true\n' +
    '2. 设置 sentinel.flow.enabled=true\n' +
    '3. 使用 JMeter 对 /api/order/create 进行压测，观察 QPS 达到阈值(100) 后返回 429。\n\n' +
    '前端已支持 429 错误提示。',
    'Sentinel 限流演示',
    { confirmButtonText: '知道了', type: 'info' }
  ).catch(() => {})  // 忽略取消
}

const showSeataTip = () => {
  ElMessageBox.alert(
    'Seata AT 模式工作原理：\n\n' +
    '1. 订单服务开启全局事务 @GlobalTransactional\n' +
    '2. 调用库存服务扣减库存（分支事务）\n' +
    '3. 调用用户服务扣减积分（分支事务）\n' +
    '4. 任一失败则自动回滚所有分支事务，保证数据一致性。\n\n' +
    '本系统已启用 Seata，下单流程中的分布式事务由 Seata 管理。',
    'Seata 分布式事务',
    { confirmButtonText: '了解', type: 'info' }
  ).catch(() => {})
}

const showPerfTip = () => {
  ElMessageBox.alert(
    '详细压测步骤：\n\n' +
    '1. 确保后端所有服务正常运行（Nacos、Redis、MySQL）\n' +
    '2. 在 order-service 中开启限流（sentinel.flow.enabled=true）\n' +
    '3. 使用 JMeter 创建测试计划：\n' +
    '   - 线程组：线程数 200，Ramp-up 1 秒，循环次数 10\n' +
    '   - HTTP 请求：POST http://localhost:8080/api/order/create\n' +
    '   - 添加 HTTP Header Manager：Authorization: Bearer {用户token}\n' +
    '   - 添加 JSON Body：{"userId":1,"items":[{"productId":1,"count":1,"price":45,"orderType":2}],"pointsUsed":0}\n' +
    '4. 运行压测，观察聚合报告中的错误率。\n' +
    '5. 在 Sentinel Dashboard 中可看到实时 QPS 和拒绝次数。',
    '压测指导',
    { confirmButtonText: '知道了', type: 'info' }
  ).catch(() => {})
}

onMounted(() => {
  refreshHealth()
})
</script>


<style scoped>
.monitor-container {
  max-width: 1400px;
  margin: 0 auto;
  padding: 20px;
}
.card-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  flex-wrap: wrap;
  gap: 10px;
}
.health-note {
  margin-top: 12px;
  text-align: right;
}
.tech-list {
  display: flex;
  flex-wrap: wrap;
  gap: 12px;
}
.tech-item {
  display: flex;
  align-items: center;
  gap: 8px;
  background: #f5f7fa;
  padding: 6px 12px;
  border-radius: 20px;
}
.arch-diagram {
  text-align: center;
  padding: 20px 0;
}
.arch-layer {
  margin: 16px 0;
}
.arch-node {
  display: inline-block;
  background: #ecf5ff;
  border: 1px solid #b3d8ff;
  border-radius: 8px;
  padding: 10px 20px;
  margin: 0 8px;
  font-weight: 500;
}
.arch-arrow {
  font-size: 24px;
  color: #909399;
  margin: 8px 0;
}
.client-layer .arch-node {
  background: #e6f7e6;
  border-color: #b3e6b3;
}
.gateway-layer .arch-node {
  background: #fff3e0;
  border-color: #ffd966;
}
.services-layer .service-nodes {
  display: flex;
  justify-content: center;
  flex-wrap: wrap;
  gap: 16px;
  margin-bottom: 16px;
}
.infra-layer .infra-nodes {
  display: flex;
  justify-content: center;
  flex-wrap: wrap;
  gap: 12px;
}
.arch-note {
  margin-top: 16px;
  text-align: center;
}
.feature-card p {
  margin: 8px 0;
  line-height: 1.6;
}
pre {
  margin: 12px 0;
  font-size: 12px;
  white-space: pre-wrap;
  word-break: break-all;
}
.note {
  color: #909399;
  font-size: 12px;
  margin-top: 8px;
}
</style>