<template>
  <div class="book-reader">
    <el-card>
      <template #header>
        <div class="header">
          <el-button @click="$router.back()" link>返回</el-button>
          <h2>{{ bookTitle }}</h2>
          <el-dropdown v-if="downloadOptions.length > 0" trigger="click">
            <el-button type="primary" size="small">
              下载文件 <el-icon class="el-icon--right"><arrow-down /></el-icon>
            </el-button>
            <template #dropdown>
              <el-dropdown-menu>
                <el-dropdown-item
                  v-for="opt in downloadOptions"
                  :key="opt.type"
                  @click="downloadFile(opt.url)"
                >
                  {{ opt.label }}
                </el-dropdown-item>
              </el-dropdown-menu>
            </template>
          </el-dropdown>
        </div>
      </template>

      <div v-if="readerError" class="error-message">
        <el-alert :title="readerError" type="error" show-icon />
        <el-button style="margin-top: 16px" @click="$router.back()">返回我的图书</el-button>
      </div>

      <div v-else-if="loading" class="loading">加载中...</div>

      <div v-else-if="fileUrl" class="reader-container">
        <!-- PDF 预览 -->
        <div v-if="isPdf" class="pdf-viewer">
          <iframe 
            :src="pdfViewerUrl" 
            width="100%" 
            height="700px" 
            frameborder="0"
            @error="handlePdfError"
          ></iframe>
          <div v-if="pdfError" class="error-message">
            <el-alert title="PDF加载失败，请检查文件是否存在" type="error" show-icon />
          </div>
        </div>

        <!-- TXT 预览 -->
        <div v-else-if="isTxt && txtContent" class="txt-viewer">
          <div class="txt-content" v-html="formattedTxt"></div>
        </div>

        <!-- HTML 预览：新窗口打开 -->
        <div v-else-if="isHtml" class="html-viewer">
          <el-alert title="即将在新窗口打开 HTML 文件" type="info" show-icon />
          <el-button type="primary" @click="openHtmlInNewTab" style="margin-top: 16px;">点击在线阅读</el-button>
        </div>

        <!-- EPUB 不支持在线预览 -->
        <div v-else-if="isEpub" class="unsupported">
          <el-empty description="EPUB 格式暂不支持在线预览，请点击下载按钮查看" />
        </div>

        <!-- 其他格式 -->
        <div v-else class="unsupported">
          <el-empty description="该格式暂不支持在线预览，请点击下载按钮查看" />
        </div>
      </div>
    </el-card>
  </div>
</template>

<script setup>
import { ref, computed, onMounted } from 'vue'
import { useRoute } from 'vue-router'
import { bookApi } from '../api'
import { ElMessage } from 'element-plus'
import { ArrowDown } from '@element-plus/icons-vue'

const route = useRoute()
const bookId = ref(route.params.id)
const bookTitle = ref('')
const fileUrl = ref('')
const epubUrl = ref('')
const readerError = ref('')
const loading = ref(false)
const pdfError = ref(false)
const txtContent = ref('')
const txtLoading = ref(false)

// 文件类型判断
const isPdf = computed(() => fileUrl.value?.toLowerCase().endsWith('.pdf'))
const isTxt = computed(() => fileUrl.value?.toLowerCase().endsWith('.txt'))
const isHtml = computed(() => fileUrl.value?.toLowerCase().endsWith('.html'))
const isEpub = computed(() => fileUrl.value?.toLowerCase().endsWith('.epub'))

// PDF 查看器 URL
const pdfViewerUrl = computed(() => {
  if (!fileUrl.value) return ''
  if (fileUrl.value.startsWith('/ebooks/')) return fileUrl.value
  return `/ebooks/${fileUrl.value.split('/').pop()}`
})

// 格式化 TXT
const formattedTxt = computed(() => {
  if (!txtContent.value) return ''
  return txtContent.value.replace(/\n/g, '<br>')
})

// 生成下载选项（支持多格式）
const downloadOptions = computed(() => {
  const options = []
  const mainUrl = fileUrl.value
  const epub = epubUrl.value || (mainUrl?.replace(/\.html$/i, '.epub'))

  if (!mainUrl) return options

  const ext = mainUrl.split('.').pop().toLowerCase()
  let mainLabel = ''
  if (ext === 'pdf') mainLabel = '📄 PDF 版'
  else if (ext === 'html') mainLabel = '🌐 HTML 版'
  else if (ext === 'txt') mainLabel = '📝 TXT 版'
  else if (ext === 'epub') mainLabel = '📚 EPUB 版'
  else mainLabel = '📥 下载文件'
  options.push({ type: ext, label: mainLabel, url: mainUrl })

  // 如果主文件是 HTML 且有 EPUB 版本（独立或推断），添加 EPUB 选项
  if (ext === 'html' && epub && epub !== mainUrl) {
    options.push({ type: 'epub', label: '📚 EPUB 下载版', url: epub })
  }

  return options
})

// 下载文件
const downloadFile = (url) => {
  if (!url) return
  const link = document.createElement('a')
  link.href = url
  link.download = url.split('/').pop()
  link.click()
}

// HTML 新窗口打开
const openHtmlInNewTab = () => {
  if (fileUrl.value) {
    window.open(fileUrl.value, '_blank')
  }
}

// 加载图书信息
const loadBook = async () => {
  try {
    loading.value = true
    const res = await bookApi.getById(bookId.value)
    const book = res.data
    bookTitle.value = book.title
    if (!book.fileUrl) {
      readerError.value = '该电子书文件缺失'
      return
    }
    fileUrl.value = book.fileUrl
    epubUrl.value = book.epubUrl || (book.fileUrl ? book.fileUrl.replace(/\.html$/i, '.epub') : '')
    console.log('电子书URL:', fileUrl.value, 'EPUB:', epubUrl.value)

    if (isTxt.value) {
      await loadTxtContent()
    }
  } catch (err) {
    console.error('加载图书信息失败', err)
    readerError.value = '图书信息获取失败'
  } finally {
    loading.value = false
  }
}

// 加载 TXT 内容
const loadTxtContent = async () => {
  txtLoading.value = true
  try {
    const response = await fetch(fileUrl.value)
    if (response.ok) {
      txtContent.value = await response.text()
    } else {
      readerError.value = '无法加载文本文件'
    }
  } catch (err) {
    console.error('加载TXT失败', err)
    readerError.value = '加载文本失败'
  } finally {
    txtLoading.value = false
  }
}

// PDF 错误处理
const handlePdfError = () => {
  pdfError.value = true
  readerError.value = 'PDF文件无法加载，请确认文件是否存在'
}

onMounted(() => {
  loadBook()
})
</script>

<style scoped>
/* 原样式保持不变 */
.book-reader {
  max-width: 1200px;
  margin: 0 auto;
  padding: 20px;
}
.header {
  display: flex;
  align-items: center;
  gap: 16px;
}
.header h2 {
  margin: 0;
  flex: 1;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}
.pdf-viewer {
  width: 100%;
  height: 700px;
}
.pdf-viewer iframe {
  width: 100%;
  height: 100%;
  border: none;
}
.txt-viewer {
  background: #f8f9fa;
  padding: 20px;
  border-radius: 8px;
  max-height: 700px;
  overflow-y: auto;
}
.txt-content {
  white-space: pre-wrap;
  font-family: monospace;
  font-size: 14px;
  line-height: 1.6;
}
.html-viewer,
.unsupported {
  text-align: center;
  padding: 60px;
}
.loading,
.error-message {
  text-align: center;
  padding: 60px;
}
</style>