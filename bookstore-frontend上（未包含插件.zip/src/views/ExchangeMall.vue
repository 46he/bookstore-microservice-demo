<template>
  <div class="exchange-mall">
    <el-card>
      <template #header>
        <div class="header">
          <h2>积分商城</h2>
          <div class="points-info">
            我的积分：{{ userStore.user?.points || 0 }}
            <el-button type="primary" size="small" @click="router.push('/daily-sign')">每日签到</el-button>
          </div>
        </div>
      </template>

      <el-tabs v-model="activeTab">
        <el-tab-pane label="积分兑换商品" name="goods">
          <div v-loading="goodsLoading" class="goods-grid">
            <div v-for="book in pointsBooks" :key="book.id" class="goods-card">
              <div class="goods-cover">
                <img :src="book.imageUrl || 'https://picsum.photos/200/200?random=' + book.id" :alt="book.title" />
                <div class="points-price">{{ book.pointsPrice }} 积分</div>
              </div>
              <div class="goods-info">
                <h3>{{ book.title }}</h3>
                <p>作者：{{ book.author }}</p>
                <p>分类：{{ book.category }}</p>
                <el-button
                  type="primary"
                  size="small"
                  @click="exchangeGoods(book)"
                  :loading="exchangingGoodsId === book.id"
                  :disabled="userStore.user?.points < book.pointsPrice || book.stock <= 0"
                >
                  立即兑换
                </el-button>
              </div>
            </div>
            <el-empty v-if="pointsBooks.length === 0 && !goodsLoading" description="暂无积分兑换商品" />
          </div>
        </el-tab-pane>

        <el-tab-pane label="我的优惠券" name="coupons">
          <div v-loading="couponsLoading" class="coupons-list">
            <div v-for="uc in userCoupons" :key="uc.id" class="coupon-card">
              <div class="coupon-info">
                <div class="coupon-name">{{ uc.couponName }}</div>
                <div class="coupon-discount">减免 ¥{{ uc.discountAmount }}</div>
                <div class="coupon-expire">有效期至：{{ formatDate(uc.expireDate) }}</div>
              </div>
            </div>
            <el-empty v-if="userCoupons.length === 0 && !couponsLoading" description="暂无优惠券" />
          </div>
        </el-tab-pane>

        <el-tab-pane label="可兑换优惠券" name="templates">
          <div v-loading="templatesLoading" class="coupon-templates">
            <div v-for="coupon in couponTemplates" :key="coupon.id" class="coupon-card template">
              <div class="coupon-info">
                <div class="coupon-name">{{ coupon.name }}</div>
                <div class="coupon-discount">减免 ¥{{ coupon.discountAmount }}</div>
                <div class="coupon-cost">所需积分：{{ coupon.pointsCost }}</div>
              </div>
              <el-button
                type="success"
                size="small"
                @click="exchangeCoupon(coupon)"
                :loading="exchangingCouponId === coupon.id"
                :disabled="userStore.user?.points < coupon.pointsCost"
              >
                兑换
              </el-button>
            </div>
            <el-empty v-if="couponTemplates.length === 0 && !templatesLoading" description="暂无可用优惠券模板" />
          </div>
        </el-tab-pane>
      </el-tabs>
    </el-card>
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue'
import { useRouter } from 'vue-router'
import { ElMessage } from 'element-plus'
import { bookApi, userApi, orderApi } from '../api'
import { useUserStore } from '../stores/user'

const router = useRouter()
const userStore = useUserStore()

const activeTab = ref('goods')
const pointsBooks = ref([])
const userCoupons = ref([])
const couponTemplates = ref([])
const goodsLoading = ref(false)
const couponsLoading = ref(false)
const templatesLoading = ref(false)
const exchangingGoodsId = ref(null)
const exchangingCouponId = ref(null)

// 加载积分商品
const loadPointsBooks = async () => {
  goodsLoading.value = true
  try {
    const res = await bookApi.getPointsBooks()
    pointsBooks.value = res.data
  } catch (err) {
    console.error('加载积分商品失败', err)
    ElMessage.error('加载积分商品失败')
  } finally {
    goodsLoading.value = false
  }
}

// 加载我的优惠券
const loadMyCoupons = async () => {
  couponsLoading.value = true
  try {
    const res = await userApi.getUserCoupons()
    userCoupons.value = res.data
  } catch (err) {
    console.error('加载优惠券失败', err)
    ElMessage.error('加载优惠券失败')
  } finally {
    couponsLoading.value = false
  }
}

// 加载可兑换优惠券模板
const loadCouponTemplates = async () => {
  templatesLoading.value = true
  try {
    const res = await userApi.getCouponTemplates()
    couponTemplates.value = res.data
  } catch (err) {
    console.error('加载优惠券模板失败', err)
    ElMessage.error('加载优惠券模板失败')
  } finally {
    templatesLoading.value = false
  }
}

// 生成 UUID 用于幂等性令牌
const generateIdempotentToken = () => {
  return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function(c) {
    const r = Math.random() * 16 | 0, v = c === 'x' ? r : (r & 0x3 | 0x8)
    return v.toString(16)
  })
}

// 兑换商品（使用积分购买）
const exchangeGoods = async (book) => {
  if (userStore.user?.points < book.pointsPrice) {
    ElMessage.warning('积分不足')
    return
  }
  if (book.stock <= 0) {
    ElMessage.warning('商品已售罄')
    return
  }
  exchangingGoodsId.value = book.id
  try {
    const orderRequest = {
      userId: userStore.user.id,
      items: [{
        productId: book.id,
        count: 1,
        price: 0,
        orderType: book.type
      }],
      pointsUsed: book.pointsPrice,
      addressId: null,
      orderType: book.type,
      couponId: null,
      idempotentToken: generateIdempotentToken()
    }
    await orderApi.create(orderRequest)
    ElMessage.success('兑换成功，请去订单列表查看')
    await userStore.refreshUserInfo()
    await loadPointsBooks()
    await loadMyCoupons()
  } catch (err) {
    const msg = err.response?.data?.message || err.message || '兑换失败'
    ElMessage.error(msg)
  } finally {
    exchangingGoodsId.value = null
  }
}

// 兑换优惠券（使用积分兑换优惠券模板）
const exchangeCoupon = async (coupon) => {
  if (userStore.user?.points < coupon.pointsCost) {
    ElMessage.warning('积分不足')
    return
  }
  exchangingCouponId.value = coupon.id
  try {
    await userApi.exchangeCoupon(coupon.id)
    ElMessage.success('兑换成功，请在"我的优惠券"中查看')
    await userStore.refreshUserInfo()
    await loadMyCoupons()
    await loadCouponTemplates()
  } catch (err) {
    const msg = err.response?.data?.message || err.message || '兑换失败'
    ElMessage.error(msg)
  } finally {
    exchangingCouponId.value = null
  }
}

const formatDate = (dateStr) => {
  if (!dateStr) return ''
  try {
    return new Date(dateStr).toLocaleString()
  } catch (e) {
    return dateStr
  }
}

onMounted(() => {
  loadPointsBooks()
  loadMyCoupons()
  loadCouponTemplates()
})
</script>

<style scoped>
.exchange-mall {
  max-width: 1200px;
  margin: 0 auto;
  padding: 20px;
}

.header {
  display: flex;
  justify-content: space-between;
  align-items: center;
}

.points-info {
  display: flex;
  align-items: center;
  gap: 12px;
}

.goods-grid {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(240px, 1fr));
  gap: 24px;
  margin-top: 20px;
}

.goods-card {
  background: #fff;
  border-radius: 12px;
  overflow: hidden;
  box-shadow: 0 2px 12px rgba(0, 0, 0, 0.08);
  transition: transform 0.2s;
}

.goods-card:hover {
  transform: translateY(-4px);
}

.goods-cover {
  position: relative;
  height: 200px;
  overflow: hidden;
}

.goods-cover img {
  width: 100%;
  height: 100%;
  object-fit: cover;
}

.points-price {
  position: absolute;
  bottom: 8px;
  right: 8px;
  background: rgba(0, 0, 0, 0.7);
  color: #ffd966;
  padding: 4px 8px;
  border-radius: 4px;
  font-size: 14px;
  font-weight: bold;
}

.goods-info {
  padding: 12px;
}

.goods-info h3 {
  margin: 0 0 8px 0;
  font-size: 16px;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}

.goods-info p {
  margin: 4px 0;
  font-size: 13px;
  color: #666;
}

.coupons-list,
.coupon-templates {
  display: flex;
  flex-direction: column;
  gap: 12px;
  margin-top: 20px;
}

.coupon-card {
  display: flex;
  justify-content: space-between;
  align-items: center;
  background: linear-gradient(135deg, #fff9e6, #fff);
  border-left: 4px solid #e6a23c;
  border-radius: 8px;
  padding: 12px 16px;
  box-shadow: 0 1px 4px rgba(0, 0, 0, 0.05);
}

.coupon-card.template {
  border-left-color: #67c23a;
}

.coupon-info {
  flex: 1;
}

.coupon-name {
  font-weight: bold;
  font-size: 16px;
  margin-bottom: 4px;
}

.coupon-discount {
  color: #e6a23c;
  font-size: 14px;
}

.coupon-cost,
.coupon-expire {
  font-size: 12px;
  color: #909399;
  margin-top: 4px;
}
</style>