<template>
  <div class="seller-center">
    <el-tabs v-model="activeTab">
      <el-tab-pane label="上架新书" name="publish">
        <el-card>
          <h3>上架二手书</h3>
          <el-form :model="newBook" label-width="100px">
            <el-form-item label="书名"><el-input v-model="newBook.title" /></el-form-item>
            <el-form-item label="作者"><el-input v-model="newBook.author" /></el-form-item>
            <el-form-item label="分类"><el-input v-model="newBook.category" /></el-form-item>
            <el-form-item label="描述"><el-input type="textarea" v-model="newBook.description" /></el-form-item>
            <el-form-item label="价格"><el-input-number v-model="newBook.price" :min="0" /></el-form-item>
            <el-form-item label="积分价"><el-input-number v-model="newBook.pointsPrice" :min="0" /></el-form-item>
            <el-form-item label="类型">
              <el-radio-group v-model="newBook.type"><el-radio :label="1">电子书</el-radio><el-radio :label="2">纸质书</el-radio></el-radio-group>
            </el-form-item>
            <el-form-item label="库存"><el-input-number v-model="newBook.stock" :min="1" /></el-form-item>
            <el-form-item v-if="newBook.type === 2" label="发货地址">
              <el-select v-model="newBook.sellerAddressId">
                <el-option v-for="addr in addresses" :key="addr.id" :label="addr.detail" :value="addr.id" />
              </el-select>
            </el-form-item>
            <el-form-item v-if="newBook.type === 1" label="电子书文件">
              <input type="file" @change="handleFileUpload" />
            </el-form-item>
            <el-button type="primary" @click="publish">上架</el-button>
          </el-form>
        </el-card>
      </el-tab-pane>

      <el-tab-pane label="我的图书" name="mybooks">
        <el-card>
          <h3>我发布的图书</h3>
          <el-table :data="myBooks" stripe>
            <el-table-column prop="title" label="书名" />
            <el-table-column prop="price" label="价格" width="100">
              <template #default="{ row }">¥{{ row.price }}</template>
            </el-table-column>
            <el-table-column label="库存" width="140">
              <template #default="{ row }">
                <el-input-number v-model="row.stock" :min="0" :step="1" size="small" />
              </template>
            </el-table-column>
            <el-table-column prop="soldCount" label="已售" width="100" />
            <el-table-column label="状态" width="120">
              <template #default="{ row }">
                <el-tag :type="row.status === 1 ? 'success' : 'info'">
                  {{ row.status === 1 ? '上架中' : '已下架' }}
                </el-tag>
              </template>
            </el-table-column>
            <el-table-column label="操作" width="240">
              <template #default="{ row }">
                <el-button
                  size="small"
                  :type="row.status === 1 ? 'danger' : 'primary'"
                  @click="toggleShelf(row)"
                >
                  {{ row.status === 1 ? '下架' : '上架' }}
                </el-button>
                <el-button size="small" type="warning" @click="saveStock(row)">保存库存</el-button>
              </template>
            </el-table-column>
          </el-table>
        </el-card>
      </el-tab-pane>

      <!-- 新增：销售统计标签页 -->
      <el-tab-pane label="销售统计" name="statistics">
        <el-card v-loading="statsLoading">
          <div class="stats-header">
            <el-radio-group v-model="statsPeriod" @change="loadStatistics">
              <el-radio-button label="week">近7天</el-radio-button>
              <el-radio-button label="month">近30天</el-radio-button>
            </el-radio-group>
          </div>
          <div class="stats-cards">
            <div class="stat-card">
              <div class="stat-title">总销售额</div>
              <div class="stat-value">¥{{ totalSales.toFixed(2) }}</div>
            </div>
            <div class="stat-card">
              <div class="stat-title">订单数量</div>
              <div class="stat-value">{{ orderCount }}</div>
            </div>
          </div>
          <div v-if="trendData.length" class="chart-container">
            <div ref="chartRef" class="chart"></div>
          </div>
          <el-empty v-else description="暂无销售数据" />
        </el-card>
      </el-tab-pane>
    </el-tabs>
  </div>
</template>

<script setup>
import { ref, onMounted, onUnmounted, watch } from 'vue'
import { ElMessage } from 'element-plus'
import * as echarts from 'echarts'
import { userApi, bookApi, orderApi } from '../api'
import { useUserStore } from '../stores/user'

const userStore = useUserStore()
const activeTab = ref('publish')

const addresses = ref([])
const myBooks = ref([])
const newBook = ref({ type: 1, stock: 1, price: 0, pointsPrice: 0, title: '', author: '', category: '', description: '' })
const selectedFile = ref(null)

// 统计相关
const statsPeriod = ref('week')
const statsLoading = ref(false)
const totalSales = ref(0)
const orderCount = ref(0)
const trendData = ref([])
let chartInstance = null
const chartRef = ref(null)

const loadAddresses = async () => {
  const res = await userApi.getAddresses(userStore.user.id)
  addresses.value = res.data
}
const loadMyBooks = async () => {
  const res = await bookApi.getSellerInventory(userStore.user.id)
  myBooks.value = res.data
}
const handleFileUpload = (e) => { selectedFile.value = e.target.files[0] }
const publish = async () => {
  let fileUrl = ''
  if (selectedFile.value) {
    const formData = new FormData()
    formData.append('file', selectedFile.value)
    const uploadRes = await bookApi.uploadFile(formData)
    fileUrl = uploadRes.data
  }
  await bookApi.sellBook({ ...newBook.value, sellerId: userStore.user.id, fileUrl })
  ElMessage.success('上架成功')
  await loadMyBooks()
  newBook.value = { type: 1, stock: 1, price: 0, pointsPrice: 0, title: '', author: '', category: '', description: '' }
  selectedFile.value = null
}
const toggleShelf = async (row) => {
  if (row.status === 1) {
    await bookApi.offShelf(row.id)
    ElMessage.success('已下架')
  } else {
    await bookApi.onShelf(row.id)
    ElMessage.success('已上架')
  }
  await loadMyBooks()
}
const saveStock = async (row) => {
  try {
    const res = await bookApi.updateStock(row.id, row.stock)
    if (res.data && res.data.success !== false) {
      ElMessage.success('库存已更新')
    } else {
      ElMessage.error(res.data?.message || '更新失败')
    }
  } catch (err) {
    ElMessage.error('更新库存失败')
    console.error(err)
  }
}

// 加载销售统计
const loadStatistics = async () => {
  statsLoading.value = true
  try {
    const res = await orderApi.getSellerStatistics(statsPeriod.value)
    const data = res.data
    totalSales.value = data.totalSales || 0
    orderCount.value = data.orderCount || 0
    trendData.value = data.trend || []
    renderChart()
  } catch (err) {
    console.error('加载销售统计失败', err)
    ElMessage.error('加载销售统计失败')
  } finally {
    statsLoading.value = false
  }
}

// 渲染图表
const renderChart = () => {
  if (!chartRef.value) return
  if (chartInstance) {
    chartInstance.dispose()
  }
  chartInstance = echarts.init(chartRef.value)
  const dates = trendData.value.map(item => item.date)
  const sales = trendData.value.map(item => item.sales)
  chartInstance.setOption({
    tooltip: { trigger: 'axis', axisPointer: { type: 'shadow' } },
    xAxis: { type: 'category', data: dates, name: '日期' },
    yAxis: { type: 'value', name: '销售额 (¥)' },
    series: [{
      data: sales,
      type: 'line',
      smooth: true,
      areaStyle: { opacity: 0.3 },
      lineStyle: { color: '#409eff', width: 2 },
      itemStyle: { color: '#409eff' }
    }]
  })
}

// 监听窗口大小变化，重新调整图表
const handleResize = () => {
  if (chartInstance) {
    chartInstance.resize()
  }
}

onMounted(() => {
  loadAddresses()
  loadMyBooks()
  loadStatistics()
  window.addEventListener('resize', handleResize)
})

onUnmounted(() => {
  if (chartInstance) {
    chartInstance.dispose()
  }
  window.removeEventListener('resize', handleResize)
})

// 切换标签页时如果切换到统计标签，确保图表渲染
watch(activeTab, (val) => {
  if (val === 'statistics') {
    setTimeout(() => {
      renderChart()
    }, 100)
  }
})
</script>

<style scoped>
.seller-center {
  max-width: 1200px;
  margin: 0 auto;
  padding: 20px;
}
.stats-header {
  margin-bottom: 20px;
  text-align: right;
}
.stats-cards {
  display: flex;
  gap: 20px;
  margin-bottom: 30px;
}
.stat-card {
  flex: 1;
  background: #f5f7fa;
  border-radius: 12px;
  padding: 20px;
  text-align: center;
  box-shadow: 0 2px 8px rgba(0,0,0,0.05);
}
.stat-title {
  color: #909399;
  font-size: 14px;
  margin-bottom: 8px;
}
.stat-value {
  font-size: 28px;
  font-weight: bold;
  color: #409eff;
}
.chart-container {
  margin-top: 20px;
}
.chart {
  width: 100%;
  height: 400px;
}
</style>