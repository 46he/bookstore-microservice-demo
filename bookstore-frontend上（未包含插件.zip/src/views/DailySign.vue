<template>
  <div class="sign-container">
    <el-card>
      <h2>每日签到</h2>
      <p>当前积分：{{ userStore.user?.points }}</p>
      <el-button type="primary" @click="doSign" :disabled="signedToday">签到</el-button>
      <p v-if="signedToday">今日已签到，明天再来吧~</p>
    </el-card>
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue'
import { useUserStore } from '../stores/user'
import { ElMessage } from 'element-plus'
import { userApi } from '../api'

const userStore = useUserStore()
const signedToday = ref(false)

const doSign = async () => {
  const result = await userStore.signIn()
  if (result.success) {
    ElMessage.success(result.message)
    signedToday.value = true
  } else {
    ElMessage.warning(result.message)
  }
}

onMounted(async () => {
  try {
    const res = await userApi.getTodaySignStatus()
    signedToday.value = res.data
  } catch (err) {
    console.error('Check sign status failed:', err)
  }
})
</script>