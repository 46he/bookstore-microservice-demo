<template>
  <div class="my-books">
    <el-card>
      <template #header>
        <div class="header">
          <h2>我的图书</h2>
          <el-button type="primary" @click="refreshBooks" :loading="loading">刷新</el-button>
        </div>
      </template>

      <el-alert v-if="error" :title="error" type="error" show-icon />

      <!-- 左侧分组栏 -->
      <div class="books-layout">
        <div class="groups-sidebar">
          <div class="group-actions">
            <el-input v-model="newGroupName" placeholder="新分组名称" size="small" style="width: 120px" />
            <el-button type="success" size="small" @click="handleCreateGroup">创建</el-button>
          </div>
          <el-menu :default-active="activeGroupId" @select="handleGroupSelect">
            <el-menu-item v-for="group in groups" :key="group.id" :index="group.id">
              <span>{{ group.name }}</span>
              <template v-if="group.id !== 'default'">
                <el-button text size="small" @click.stop="editGroup(group)">编辑</el-button>
                <el-button text size="small" type="danger" @click.stop="confirmDeleteGroup(group.id)">删除</el-button>
              </template>
            </el-menu-item>
          </el-menu>
        </div>

        <!-- 右侧图书网格 -->
        <div class="books-grid">
          <div v-if="currentGroupBooks.length === 0 && !loading" class="empty-tip">
            <el-empty description="暂无图书，先去购买电子书吧~" />
          </div>
          <div class="book-cards">
            <div v-for="book in currentGroupBooks" :key="book.id" class="book-card">
              <img :src="book.imageUrl || '/default-cover.png'" class="book-cover" />
              <div class="book-info">
                <h3>{{ book.title }}</h3>
                <p>{{ book.author }}</p>
                <div class="actions">
                  <el-button type="primary" size="small" @click="readBook(book)">阅读</el-button>
                  <el-dropdown trigger="click" @command="(cmd) => moveToGroup(book.id, cmd)">
                    <el-button size="small">移动分组</el-button>
                    <template #dropdown>
                      <el-dropdown-menu>
                        <el-dropdown-item v-for="g in groups" :key="g.id" :command="g.id">
                          {{ g.name }}
                        </el-dropdown-item>
                      </el-dropdown-menu>
                    </template>
                  </el-dropdown>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </el-card>

    <!-- 编辑分组对话框（保持不变） -->
    <el-dialog v-model="editDialogVisible" title="编辑分组" width="30%">
      <el-input v-model="editGroupName" placeholder="分组名称" />
      <template #footer>
        <el-button @click="editDialogVisible = false">取消</el-button>
        <el-button type="primary" @click="saveEditGroup">确定</el-button>
      </template>
    </el-dialog>
  </div>
</template>

<script setup>
import { ref, computed, onMounted } from 'vue'
import { useRouter } from 'vue-router'
import { ElMessage, ElMessageBox } from 'element-plus'
import { useMyBooksStore } from '../stores/myBooks'

const router = useRouter()
const store = useMyBooksStore()
const loading = computed(() => store.loading)
const error = computed(() => store.error)
const books = computed(() => store.books)
const groups = computed(() => store.getAllGroups())

const activeGroupId = ref('default')
const currentGroupBooks = ref([])

const newGroupName = ref('')
const editDialogVisible = ref(false)
const editGroupId = ref('')
const editGroupName = ref('')

const refreshBooks = async () => {
  await store.loadPurchasedEBooks()
  updateCurrentGroupBooks()
}

const updateCurrentGroupBooks = () => {
  currentGroupBooks.value = store.getBooksInGroup(activeGroupId.value)
}

const handleGroupSelect = (groupId) => {
  activeGroupId.value = groupId
  updateCurrentGroupBooks()
}

const handleCreateGroup = () => {
  if (!newGroupName.value.trim()) {
    ElMessage.warning('请输入分组名称')
    return
  }
  store.createGroup(newGroupName.value)
  newGroupName.value = ''
  ElMessage.success('创建成功')
}

const editGroup = (group) => {
  editGroupId.value = group.id
  editGroupName.value = group.name
  editDialogVisible.value = true
}

const saveEditGroup = () => {
  if (!editGroupName.value.trim()) {
    ElMessage.warning('名称不能为空')
    return
  }
  store.renameGroup(editGroupId.value, editGroupName.value)
  editDialogVisible.value = false
  ElMessage.success('修改成功')
}

const confirmDeleteGroup = async (groupId) => {
  try {
    await ElMessageBox.confirm('删除分组后，其中的图书将移到“未分组”，确定删除吗？', '提示', { type: 'warning' })
    store.deleteGroup(groupId)
    if (activeGroupId.value === groupId) {
      activeGroupId.value = 'default'
      updateCurrentGroupBooks()
    }
    ElMessage.success('已删除')
  } catch (err) {}
}

const moveToGroup = (bookId, targetGroupId) => {
  store.moveBookToGroup(bookId, targetGroupId)
  updateCurrentGroupBooks()
  ElMessage.success('已移动')
}

const readBook = (book) => {
  router.push({ name: 'BookReader', params: { id: book.id } })
}

onMounted(async () => {
  store.initGroups()
  await refreshBooks()
})
</script>


<style scoped>
.my-books {
  max-width: 1400px;
  margin: 0 auto;
  padding: 20px;
}
.header {
  display: flex;
  justify-content: space-between;
  align-items: center;
}
.books-layout {
  display: flex;
  gap: 24px;
  margin-top: 20px;
}
.groups-sidebar {
  width: 220px;
  flex-shrink: 0;
  background: #f5f7fa;
  border-radius: 8px;
  padding: 12px;
}
.group-actions {
  display: flex;
  gap: 8px;
  margin-bottom: 16px;
}
.books-grid {
  flex: 1;
}
.book-cards {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(180px, 1fr));
  gap: 20px;
}
.book-card {
  background: white;
  border-radius: 12px;
  overflow: hidden;
  box-shadow: 0 2px 8px rgba(0,0,0,0.08);
  transition: transform 0.2s;
}
.book-card:hover {
  transform: translateY(-4px);
}
.book-cover {
  width: 100%;
  height: 200px;
  object-fit: cover;
}
.book-info {
  padding: 12px;
}
.book-info h3 {
  margin: 0 0 8px 0;
  font-size: 16px;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}
.book-info p {
  margin: 4px 0;
  font-size: 13px;
  color: #666;
}
.actions {
  display: flex;
  justify-content: space-between;
  margin-top: 12px;
}
.empty-tip {
  padding: 60px 0;
  text-align: center;
}
</style>