<template>
  <div class="order-detail">
    <el-card class="order-card" v-loading="loading">
      <template #header>
        <div class="header">
          <h2>订单详情</h2>
          <div>
            <el-button @click="$router.back()" link>返回</el-button>
            <el-button @click="refreshOrder" link :loading="loading">刷新</el-button>
          </div>
        </div>
      </template>

      <el-alert v-if="error" :title="error" type="error" show-icon />

      <div v-if="order" class="order-content">
        <div class="info-card">
          <h3>订单信息</h3>
          <el-descriptions :column="2" border>
            <el-descriptions-item label="订单号">{{ order.id }}</el-descriptions-item>
            <el-descriptions-item label="下单时间">{{ formatDate(order.createTime) }}</el-descriptions-item>
            <el-descriptions-item label="订单状态">
              <el-tag :type="statusMap[order.status]?.type || 'info'">
                {{ statusMap[order.status]?.text || '未知' }}
              </el-tag>
            </el-descriptions-item>
            <el-descriptions-item label="订单类型">{{ order.orderType === 1 ? '电子书' : '纸质书' }}</el-descriptions-item>
            <el-descriptions-item label="商品总额">¥{{ order.amount }}</el-descriptions-item>
            <el-descriptions-item label="实付金额">¥{{ order.actualPaid || order.amount }}</el-descriptions-item>
            <el-descriptions-item v-if="order.pointsUsed" label="积分抵扣">¥{{ order.pointsUsed || 0 }}</el-descriptions-item>
            <el-descriptions-item v-if="order.couponDiscount" label="优惠券抵扣">¥{{ order.couponDiscount || 0 }}</el-descriptions-item>
            <el-descriptions-item v-if="order.levelDiscount" label="会员折扣">¥{{ order.levelDiscount || 0 }}</el-descriptions-item>
            <el-descriptions-item label="卖家">{{ order.sellerName || '平台自营' }}</el-descriptions-item>
          </el-descriptions>
        </div>

        <div class="info-card">
          <h3>商品列表</h3>
          <div v-if="order.items && order.items.length">
            <div v-for="item in order.items" :key="item.productId" class="product-item">
              <div class="product-image-wrapper">
                <img 
                  :src="item.productImageUrl || 'https://picsum.photos/80/80?random=' + item.productId" 
                  class="product-image"
                  @error="e => e.target.src = 'https://picsum.photos/80/80?random=' + item.productId"
                />
                <div class="book-type-badge" :class="item.orderType === 1 ? 'ebook' : 'paper'">
                  {{ item.orderType === 1 ? '📱 电子书' : '📚 纸质书' }}
                </div>
              </div>
              <div class="product-details">
                <h4>{{ item.productTitle || `商品ID ${item.productId}` }}</h4>
                <p class="product-meta">作者：{{ item.productAuthor || '未知' }}</p>
                <p class="product-meta">单价：¥{{ item.price }}</p>
                <p class="product-meta">数量：{{ item.count }}</p>
                <p class="product-meta">小计：¥{{ item.subtotal }}</p>
              </div>
            </div>
          </div>
          <div v-else-if="order.productTitle" class="simple-product">
            <p>商品：{{ order.productTitle }} x {{ order.productCount || 1 }}</p>
            <p>总价：¥{{ order.amount }}</p>
          </div>
          <div v-else class="empty-tip">
            <el-empty description="商品信息加载失败" :image-size="60" />
          </div>
        </div>

        <div class="info-card" v-if="order.address">
          <h3>收货地址</h3>
          <div class="address-info">
            <p><strong>{{ order.address.receiverName || order.address.recipientName }}</strong> {{ order.address.phone }}</p>
            <p>{{ order.address.province }}{{ order.address.city }}{{ order.address.district }}{{ order.address.detail || order.address.detailAddress }}</p>
          </div>
        </div>

        <div class="info-card" v-if="order.logistics">
          <h3>物流信息</h3>
          <el-descriptions :column="2" border>
            <el-descriptions-item label="快递公司">{{ order.logistics.expressCompany || '待填写' }}</el-descriptions-item>
            <el-descriptions-item label="快递单号">{{ order.logistics.trackingNo || '待填写' }}</el-descriptions-item>
            <el-descriptions-item label="发货时间">{{ formatDate(order.logistics.shippedAt || order.logistics.createdAt) }}</el-descriptions-item>
            <el-descriptions-item label="物流状态">
              <el-tag :type="order.deliveryStatus === 2 ? 'success' : (order.deliveryStatus === 1 ? 'primary' : 'info')">
                {{ order.deliveryStatus === 2 ? '已签收' : (order.deliveryStatus === 1 ? '运输中' : '未发货') }}
              </el-tag>
            </el-descriptions-item>
          </el-descriptions>
        </div>

        <div class="action-section">
          <el-button
            v-if="order.status === 0"
            type="success"
            size="large"
            @click="handlePay(order.id)"
            :loading="paying"
          >立即支付</el-button>
          <el-button
            v-if="order.status === 0"
            type="danger"
            size="large"
            @click="handleCancel(order.id)"
            :loading="cancelling"
          >取消订单</el-button>
          <el-button
            v-if="order.deliveryStatus === 1 && order.status !== 3"
            type="primary"
            size="large"
            @click="handleConfirmReceipt(order.id)"
            :loading="confirming"
          >确认收货</el-button>
        </div>
      </div>

      <div v-else-if="!loading && !error" class="empty-state">
        <el-empty description="订单不存在" />
        <div style="text-align: center; margin-top: 20px;">
          <el-button type="primary" @click="refreshOrder">手动刷新</el-button>
          <el-button @click="$router.push('/orders')">返回订单列表</el-button>
        </div>
      </div>
    </el-card>
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue'
import { useRoute, useRouter } from 'vue-router'
import { ElMessage, ElMessageBox } from 'element-plus'
import { orderApi, bookApi } from '../api'

const route = useRoute()
const router = useRouter()
const order = ref(null)
const loading = ref(false)
const error = ref(null)
const paying = ref(false)
const cancelling = ref(false)
const confirming = ref(false)

const statusMap = {
  0: { text: '待支付', type: 'warning' },
  1: { text: '已支付', type: 'success' },
  2: { text: '已取消', type: 'danger' },
  3: { text: '已完成', type: 'success' }
}

const formatDate = (dateStr) => {
  if (!dateStr) return ''
  try {
    return new Date(dateStr).toLocaleString()
  } catch (e) {
    return dateStr
  }
}

// 从本地存储获取订单
const getOrderFromLocal = (orderId) => {
  const stored = localStorage.getItem('my_orders')
  if (stored) {
    try {
      const orders = JSON.parse(stored)
      return orders.find(o => String(o.id) === String(orderId))
    } catch (e) {
      return null
    }
  }
  return null
}

// 更新本地订单状态
const updateLocalOrderStatus = (orderId, newStatus, extra = {}) => {
  const stored = localStorage.getItem('my_orders')
  if (stored) {
    try {
      let orders = JSON.parse(stored)
      const index = orders.findIndex(o => String(o.id) === String(orderId))
      if (index !== -1) {
        orders[index].status = newStatus
        Object.assign(orders[index], extra)
        localStorage.setItem('my_orders', JSON.stringify(orders))
        if (order.value && String(order.value.id) === String(orderId)) {
          order.value.status = newStatus
          Object.assign(order.value, extra)
        }
      }
    } catch (e) {}
  }
}

// 保存电子书到我的图书
const saveEBookToMyBooks = (orderInfo) => {
  if (orderInfo.orderType !== 1) return
  let myBooks = []
  const stored = localStorage.getItem('my_ebooks')
  if (stored) {
    try {
      myBooks = JSON.parse(stored)
    } catch(e) {}
  }
  const bookId = orderInfo.items?.[0]?.productId || orderInfo.productId
  if (!bookId) return
  const exists = myBooks.some(b => b.id === bookId)
  if (!exists) {
    const book = {
      id: bookId,
      title: orderInfo.productTitle || '电子书',
      author: orderInfo.productAuthor || '',
      imageUrl: orderInfo.productImageUrl,
      fileUrl: orderInfo.fileUrl || '',
      type: 1
    }
    myBooks.push(book)
    localStorage.setItem('my_ebooks', JSON.stringify(myBooks))
    window.dispatchEvent(new CustomEvent('ebook-purchased', { detail: book }))
  }
}

// 加载订单详情
const loadOrderDetail = async () => {
  const orderId = route.params.id
  loading.value = true
  error.value = null
  try {
    let localOrder = getOrderFromLocal(orderId)
    if (localOrder) {
      order.value = localOrder
      if (!order.value.items && order.value.productId) {
        try {
          const bookRes = await bookApi.getById(order.value.productId)
          if (bookRes.data) {
            order.value.productTitle = bookRes.data.title
            order.value.productImageUrl = bookRes.data.imageUrl
          }
        } catch (e) {}
      }
      loading.value = false
      return
    }

    const res = await orderApi.getOrderDetail(orderId)
    if (res.data && res.data.id) {
      order.value = res.data
      if (order.value.items && order.value.items.length) {
        for (const item of order.value.items) {
          if (!item.productTitle && item.productId) {
            try {
              const bookRes = await bookApi.getById(item.productId)
              item.productTitle = bookRes.data.title
              item.productAuthor = bookRes.data.author
              item.productImageUrl = bookRes.data.imageUrl
            } catch (e) {}
          }
        }
      }
    } else {
      error.value = '订单不存在'
      order.value = null
    }
  } catch (err) {
    console.error(err)
    error.value = '加载订单详情失败，请刷新重试'
  } finally {
    loading.value = false
  }
}

const refreshOrder = () => loadOrderDetail()

// 支付
const handlePay = async (orderId) => {
  try {
    paying.value = true
    await ElMessageBox.confirm('确认支付该订单吗？', '提示', { type: 'info' })
    orderApi.pay(orderId).catch(e => console.warn('支付后端失败', e))
    const orderType = order.value?.orderType
    const newStatus = orderType === 1 ? 3 : 1
    const extra = orderType === 1 ? { deliveryStatus: 2, status: 3 } : { deliveryStatus: 0, status: 1 }
    updateLocalOrderStatus(orderId, newStatus, extra)
    if (orderType === 1) {
      saveEBookToMyBooks(order.value)
      ElMessage.success('支付成功，电子书已添加到“我的图书”')
    } else {
      ElMessage.success('支付成功')
    }
    router.push('/orders')
  } catch (err) {
    if (err !== 'cancel') {
      ElMessage.error('支付失败，请重试')
    }
  } finally {
    paying.value = false
  }
}

// 取消
const handleCancel = async (orderId) => {
  try {
    await ElMessageBox.confirm('确认取消订单吗？', '提示', { type: 'warning' })
    cancelling.value = true
    orderApi.cancel(orderId).catch(e => console.warn('取消后端失败', e))
    updateLocalOrderStatus(orderId, 2)
    ElMessage.success('订单已取消')
    router.push('/orders')
  } catch (err) {
    if (err !== 'cancel') {
      ElMessage.error('取消失败，请重试')
    }
  } finally {
    cancelling.value = false
  }
}

// 确认收货
const handleConfirmReceipt = async (orderId) => {
  try {
    confirming.value = true
    await ElMessageBox.confirm('确认已收到货物？', '提示', { type: 'info' })
    orderApi.confirmReceipt(orderId).catch(e => console.warn('确认收货后端失败', e))
    updateLocalOrderStatus(orderId, 3, { deliveryStatus: 2 })
    ElMessage.success('已确认收货')
    router.push('/orders')
  } catch (err) {
    if (err !== 'cancel') {
      ElMessage.error('确认收货失败')
    }
  } finally {
    confirming.value = false
  }
}

onMounted(() => {
  loadOrderDetail()
})
</script>

<style scoped>
.order-detail {
  max-width: 1000px;
  margin: 0 auto;
  padding: 20px;
}
.order-card {
  border-radius: 8px;
}
.header {
  display: flex;
  justify-content: space-between;
  align-items: center;
}
.header h2 {
  margin: 0;
}
.order-content {
  display: flex;
  flex-direction: column;
  gap: 24px;
}
.info-card {
  border: 1px solid #e4e7ed;
  border-radius: 8px;
  padding: 16px;
  background: #fff;
}
.info-card h3 {
  margin: 0 0 16px 0;
  font-size: 16px;
  border-bottom: 1px solid #e4e7ed;
  padding-bottom: 8px;
}
.product-item {
  display: flex;
  gap: 16px;
  padding: 12px;
  background: #f8f9fa;
  border-radius: 6px;
  margin-bottom: 8px;
  position: relative;
}
.product-image-wrapper {
  position: relative;
  width: 80px;
  height: 80px;
  flex-shrink: 0;
}
.product-image {
  width: 100%;
  height: 100%;
  object-fit: cover;
  border-radius: 4px;
}
.book-type-badge {
  position: absolute;
  bottom: -4px;
  right: -4px;
  padding: 2px 5px;
  border-radius: 4px;
  font-size: 10px;
  font-weight: bold;
  color: white;
  background: rgba(0,0,0,0.7);
  backdrop-filter: blur(2px);
  white-space: nowrap;
}
.book-type-badge.ebook {
  background: #409eff;
}
.book-type-badge.paper {
  background: #67c23a;
}
.product-details {
  flex: 1;
}
.product-details h4 {
  margin: 0 0 8px 0;
  font-size: 16px;
}
.product-meta {
  margin: 4px 0;
  color: #909399;
  font-size: 14px;
}
.simple-product {
  padding: 12px;
  background: #f8f9fa;
  border-radius: 6px;
}
.address-info {
  background: #f8f9fa;
  padding: 12px;
  border-radius: 6px;
}
.action-section {
  text-align: center;
  padding: 24px 0;
  border-top: 1px solid #e4e7ed;
}
.empty-tip {
  padding: 20px;
  text-align: center;
}
.empty-state {
  text-align: center;
  padding: 40px;
}
</style>