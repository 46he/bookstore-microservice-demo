<template>
  <div class="history-container">
    <el-card>
      <template #header>
        <div class="header">
          <h2>我的足迹</h2>
          <el-button type="danger" size="small" @click="clearHistory" :disabled="historyList.length === 0">
            清空足迹
          </el-button>
        </div>
      </template>

      <!-- 新增提示条 -->
      <el-alert
        title="提示"
        type="info"
        :closable="true"
        show-icon
        class="history-alert"
      >
        <template #default>
          浏览历史仅保存在本地浏览器中，更换设备后无法同步。如需云端同步，敬请期待后续更新。
        </template>
      </el-alert>

      <div v-if="historyList.length === 0" class="empty-history">
        <el-empty description="暂无浏览记录，去逛逛吧~" />
      </div>

      <div v-else class="history-grid">
        <div
          v-for="item in historyList"
          :key="item.id"
          class="history-card"
          @click="goToDetail(item.id)"
        >
          <div class="history-cover">
            <img
              :src="item.imageUrl || 'https://picsum.photos/200/200?random=' + item.id"
              :alt="item.title"
              loading="lazy"
            />
            <div class="book-type-badge" :class="item.type === 1 ? 'ebook' : 'paper'">
              {{ item.type === 1 ? '📱 电子书' : '📚 纸质书' }}
            </div>
          </div>
          <div class="history-info">
            <h3>{{ item.title }}</h3>
            <p>作者：{{ item.author }}</p>
            <p>分类：{{ item.category }}</p>
            <div class="price">¥{{ item.price }}</div>
            <div class="browse-time">浏览时间：{{ formatDate(item.browseTime) }}</div>
          </div>
        </div>
      </div>
    </el-card>
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue'
import { useRouter } from 'vue-router'
import { ElMessageBox, ElMessage } from 'element-plus'

const router = useRouter()
const historyList = ref([])

const loadHistory = () => {
  const stored = localStorage.getItem('browse_history')
  if (stored) {
    try {
      historyList.value = JSON.parse(stored).sort((a, b) => new Date(b.browseTime) - new Date(a.browseTime))
    } catch (e) {
      historyList.value = []
    }
  } else {
    historyList.value = []
  }
}

const clearHistory = async () => {
  try {
    await ElMessageBox.confirm('确认清空所有浏览记录吗？', '提示', { type: 'warning' })
    localStorage.removeItem('browse_history')
    historyList.value = []
    ElMessage.success('足迹已清空')
  } catch {
    // 取消操作
  }
}

const goToDetail = (id) => {
  router.push(`/book/${id}`)
}

const formatDate = (dateStr) => {
  if (!dateStr) return ''
  try {
    return new Date(dateStr).toLocaleString()
  } catch (e) {
    return dateStr
  }
}

onMounted(() => {
  loadHistory()
})
</script>

<style scoped>
.history-container {
  max-width: 1200px;
  margin: 0 auto;
  padding: 20px;
}
.header {
  display: flex;
  justify-content: space-between;
  align-items: center;
}
.history-alert {
  margin-bottom: 20px;
}
.empty-history {
  padding: 40px 0;
}
.history-grid {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(280px, 1fr));
  gap: 24px;
  margin-top: 20px;
}
.history-card {
  background: white;
  border-radius: 12px;
  overflow: hidden;
  box-shadow: 0 2px 12px rgba(0, 0, 0, 0.08);
  cursor: pointer;
  transition: transform 0.2s;
}
.history-card:hover {
  transform: translateY(-4px);
  box-shadow: 0 4px 16px rgba(0, 0, 0, 0.12);
}
.history-cover {
  position: relative;
  height: 200px;
  overflow: hidden;
}
.history-cover img {
  width: 100%;
  height: 100%;
  object-fit: cover;
}
.book-type-badge {
  position: absolute;
  top: 8px;
  left: 8px;
  padding: 4px 8px;
  border-radius: 4px;
  font-size: 12px;
  font-weight: bold;
  color: white;
  background: rgba(0,0,0,0.6);
  backdrop-filter: blur(4px);
}
.book-type-badge.ebook {
  background: #409eff;
}
.book-type-badge.paper {
  background: #67c23a;
}
.history-info {
  padding: 12px;
}
.history-info h3 {
  margin: 0 0 8px 0;
  font-size: 16px;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}
.history-info p {
  margin: 4px 0;
  font-size: 13px;
  color: #666;
}
.price {
  font-size: 18px;
  color: #e4393c;
  font-weight: bold;
  margin: 8px 0;
}
.browse-time {
  font-size: 12px;
  color: #999;
  margin-top: 8px;
}
</style>