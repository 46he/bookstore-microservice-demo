<template>
  <el-container class="app-container">
    <!-- 全局加载遮罩 -->
    <div v-if="globalLoading" class="global-loading">
      <el-icon class="loading-icon"><Loading /></el-icon>
      <div class="loading-text">加载中...</div>
    </div>

    <!-- 全局错误提示 -->
    <el-alert
      v-if="globalError"
      :title="globalError.title"
      :description="globalError.message"
      :type="globalError.type"
      :closable="true"
      @close="clearGlobalError"
      class="global-error"
    />

    <el-header class="app-header">
      <div class="logo" @click="goHome">
        <span class="logo-text">在线图书商城</span>
      </div>
      <div class="nav-menu">
        <el-menu
          mode="horizontal"
          router
          :default-active="$route.path"
          background-color="transparent"
          text-color="#fff"
          active-text-color="#ffd966"
          class="header-menu"
          :ellipsis="false"
        >
          <el-menu-item index="/">首页</el-menu-item>
          <el-menu-item index="/cart">
            购物车
            <el-badge v-if="cartStore.totalCount > 0" :value="cartStore.totalCount" class="cart-badge" />
          </el-menu-item>
          <!-- 新增：我的图书 -->
          <el-menu-item index="/my-books">我的图书</el-menu-item>
          <el-menu-item index="/orders">订单</el-menu-item>
          <el-menu-item index="/profile">个人中心</el-menu-item>
          <el-menu-item v-if="userStore.user?.role === 'seller'" index="/seller/center">卖家中心</el-menu-item>
          <el-menu-item index="/exchange-mall">积分商城</el-menu-item>
          <el-menu-item index="/history">足迹</el-menu-item>
          <el-menu-item index="/monitor">监控</el-menu-item>
        </el-menu>
      </div>
      <div class="user-info">
        <NotificationCenter v-if="userStore.isLogin" />
        <template v-if="userStore.isLogin">
          <span class="username">
            {{ userStore.user?.username }}
            <span v-if="userStore.user?.points !== undefined" class="points-display">
              (积分: {{ userStore.user.points }})
            </span>
          </span>
          <el-button link :bg="false" class="logout-btn" @click="handleLogout">退出</el-button>
        </template>
        <template v-else>
          <el-button type="primary" size="small" @click="router.push('/login')">登录</el-button>
          <el-button size="small" @click="router.push('/register')">注册</el-button>
        </template>
      </div>
    </el-header>

    <el-main class="app-main">
      <router-view v-slot="{ Component, route }">
        <transition name="fade" mode="out-in">
          <component :is="Component" :key="route.path" />
        </transition>
      </router-view>
    </el-main>

    <el-footer class="app-footer">
      <div class="footer-content">
        <div class="footer-links">
          <a href="#" @click.prevent>关于我们</a> |
          <a href="#" @click.prevent>联系方式</a> |
          <a href="#" @click.prevent>帮助中心</a> |
          <a href="#" @click.prevent>隐私政策</a> |
          <router-link to="/about-microservice" style="color: #bdc3c7;">系统架构</router-link>
        </div>
        <div class="copyright">
          © 2026 基于微服务架构的在线图书商城 | 技术支持：智慧书店团队
        </div>
      </div>
    </el-footer>
  </el-container>
</template>

<script setup>
import { ref, onMounted, onUnmounted } from 'vue'
import { useRouter, useRoute } from 'vue-router'
import { Loading } from '@element-plus/icons-vue'
import { ElMessageBox, ElMessage } from 'element-plus'
import { useUserStore } from './stores/user'
import { useCartStore } from './stores/cart'
import NotificationCenter from './components/NotificationCenter.vue'
import { userApi } from './api'

const router = useRouter()
const route = useRoute()
const userStore = useUserStore()
const cartStore = useCartStore()

const globalLoading = ref(false)
const globalError = ref(null)

const clearGlobalError = () => {
  globalError.value = null
}

const setGlobalError = (title, message, type = 'error') => {
  globalError.value = { title, message, type }
}

const goHome = () => {
  router.push('/')
}

const handleLogout = async () => {
  try {
    await ElMessageBox.confirm('确定要退出登录吗？', '提示', {
      confirmButtonText: '确定',
      cancelButtonText: '取消',
      type: 'warning'
    })
    try {
      await userApi.logout()
    } catch (err) {
      console.warn('注销接口调用失败，仍清除本地数据', err)
    }
    userStore.logout()
    cartStore.clear()
    ElMessage.success('已退出登录')
    router.push('/login')
  } catch {
    // 用户取消
  }
}

const scrollToTop = () => {
  window.scrollTo({ top: 0, behavior: 'smooth' })
}

router.afterEach((to) => {
  if (to.meta.scrollTop !== false) {
    scrollToTop()
  }
  clearGlobalError()
})

const handleGlobalError = (error) => {
  if (error && error.message === 'ResizeObserver loop completed with undelivered notifications.') {
    return
  }
  console.error('Global error:', error)
  if (error.response?.status === 401) {
    userStore.logout()
    router.push('/login')
    setGlobalError('认证失败', '登录已过期，请重新登录', 'warning')
  } else if (error.response?.status >= 500) {
    setGlobalError('服务器错误', '服务器暂时不可用，请稍后重试', 'error')
  } else {
    setGlobalError('操作失败', error.message || '未知错误', 'error')
  }
}

const handleUnhandledError = (event) => {
  handleGlobalError(event.error || new Error(event.message))
}

const handleUnhandledRejection = (event) => {
  handleGlobalError(event.reason || new Error('Promise rejected'))
}

onMounted(() => {
  window.addEventListener('error', handleUnhandledError)
  window.addEventListener('unhandledrejection', handleUnhandledRejection)
})

onUnmounted(() => {
  window.removeEventListener('error', handleUnhandledError)
  window.removeEventListener('unhandledrejection', handleUnhandledRejection)
})

if (import.meta.env.DEV) {
  window.setGlobalLoading = (loading) => globalLoading.value = loading
  window.setGlobalError = setGlobalError
  window.clearGlobalError = clearGlobalError
}
</script>

<style>
* {
  margin: 0;
  padding: 0;
  box-sizing: border-box;
}

body {
  font-family: 'Helvetica Neue', Helvetica, 'PingFang SC', 'Hiragino Sans GB', 'Microsoft YaHei', Arial, sans-serif;
  background-color: #f8f9fa;
}

.app-container {
  min-height: 100vh;
  display: flex;
  flex-direction: column;
}

.global-loading {
  position: fixed;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  background-color: rgba(255, 255, 255, 0.8);
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  z-index: 9999;
}

.loading-icon {
  font-size: 48px;
  color: #409eff;
  animation: spin 1s linear infinite;
}

.loading-text {
  margin-top: 16px;
  color: #666;
  font-size: 16px;
}

@keyframes spin {
  from { transform: rotate(0deg); }
  to { transform: rotate(360deg); }
}

.global-error {
  position: fixed;
  top: 20px;
  right: 20px;
  width: 400px;
  z-index: 9998;
  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
}

/* 头部：强制一行，不滚动，无垂直滑动干扰 */
.app-header {
  background: linear-gradient(135deg, #2c3e50 0%, #1a2632 100%);
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 0 20px;
  height: 60px;
  box-shadow: 0 2px 12px rgba(0,0,0,0.1);
  flex-wrap: nowrap;
  position: relative;
  z-index: 1000;
}

.logo {
  display: flex;
  align-items: center;
  color: white;
  font-size: 18px;
  font-weight: 600;
  cursor: pointer;
  white-space: nowrap;
  margin-right: 20px;
}

.nav-menu {
  flex: 1;
  display: flex;
  justify-content: center;
  overflow: visible;
}

.header-menu {
  border-bottom: none !important;
  background: transparent !important;
  display: flex;
  flex-wrap: nowrap !important;
  white-space: nowrap;
}

.header-menu .el-menu-item {
  border-bottom: none !important;
  height: 60px !important;
  line-height: 60px !important;
  margin: 0 2px;
  padding: 0 8px !important;
  border-radius: 4px;
  transition: all 0.2s;
  color: white !important;
  font-size: 13px;
  white-space: nowrap;
}

.header-menu .el-menu-item:hover {
  background-color: rgba(255,255,255,0.1) !important;
}

.header-menu .el-menu-item.is-active {
  background-color: rgba(255,217,102,0.2) !important;
  color: #ffd966 !important;
}

.cart-badge {
  margin-left: 4px;
}

.user-info {
  display: flex;
  gap: 12px;
  align-items: center;
  white-space: nowrap;
  margin-left: 20px;
}

.username {
  color: white;
  font-size: 13px;
  display: flex;
  align-items: center;
  gap: 4px;
}

.points-display {
  color: #ffd966;
  font-size: 12px;
  font-weight: 500;
}

.logout-btn {
  color: #ffd966 !important;
  font-size: 13px;
  padding: 0;
}

.logout-btn:hover {
  color: #ffaa00 !important;
}

.app-main {
  flex: 1;
  background-color: #f8f9fa;
  padding: 20px 30px;
  min-height: calc(100vh - 120px);
}

.app-footer {
  background-color: #2c3e50;
  color: #ecf0f1;
  text-align: center;
  padding: 12px 20px;
  font-size: 13px;
}

.footer-content {
  display: flex;
  flex-direction: column;
  gap: 8px;
}

.footer-links {
  display: flex;
  justify-content: center;
  gap: 20px;
  flex-wrap: wrap;
}

.footer-links a, .footer-links .router-link-active {
  color: #bdc3c7;
  text-decoration: none;
  transition: color 0.2s;
}

.footer-links a:hover, .footer-links .router-link-active:hover {
  color: #ffd966;
}

.copyright {
  color: #95a5a6;
}

.fade-enter-active,
.fade-leave-active {
  transition: opacity 0.3s ease, transform 0.3s ease;
}

.fade-enter-from {
  opacity: 0;
  transform: translateY(20px);
}

.fade-leave-to {
  opacity: 0;
  transform: translateY(-20px);
}

/* 响应式：小屏幕下进一步压缩内边距和字体 */
@media (max-width: 1100px) {
  .header-menu .el-menu-item {
    padding: 0 6px !important;
    font-size: 12px;
  }
  .username {
    font-size: 12px;
  }
  .logout-btn {
    font-size: 12px;
  }
}

@media (max-width: 900px) {
  .header-menu .el-menu-item {
    padding: 0 4px !important;
    font-size: 11px;
  }
}
</style>