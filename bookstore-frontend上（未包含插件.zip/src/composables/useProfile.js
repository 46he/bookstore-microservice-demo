import { ref, computed } from 'vue'
import { userApi } from '../api'
import { ElMessage, ElMessageBox } from 'element-plus'

// 本地存储地址的 key
const ADDRESS_STORAGE_KEY = 'user_addresses'

export function useProfile(userStore) {
  const addresses = ref([])
  const followedSellers = ref([])
  const userCoupons = ref([])
  const loading = ref(false)
  const error = ref(null)
  const signInLoading = ref(false)

  const levelName = computed(() => {
    const level = userStore.user?.level || 0
    return ['普通会员', '白银会员', '黄金会员', '钻石会员'][level]
  })

  // 从 localStorage 加载地址
  const loadAddresses = () => {
    const stored = localStorage.getItem(ADDRESS_STORAGE_KEY)
    if (stored) {
      try {
        addresses.value = JSON.parse(stored)
      } catch (e) {
        addresses.value = []
      }
    } else {
      // 初始化几条示例地址（演示用）
      addresses.value = [
        {
          id: 1,
          userId: userStore.user?.id,
          receiverName: '张三',
          phone: '13800138001',
          province: '北京市',
          city: '北京市',
          district: '朝阳区',
          detail: '建国路1号',
          isDefault: 1,
          createdAt: new Date().toISOString()
        },
        {
          id: 2,
          userId: userStore.user?.id,
          receiverName: '李四',
          phone: '13800138002',
          province: '上海市',
          city: '上海市',
          district: '浦东新区',
          detail: '世纪大道100号',
          isDefault: 0,
          createdAt: new Date().toISOString()
        }
      ]
      saveAddressesToLocal()
    }
  }

  const saveAddressesToLocal = () => {
    localStorage.setItem(ADDRESS_STORAGE_KEY, JSON.stringify(addresses.value))
  }

  // 新增地址
  const addAddress = async (address) => {
    try {
      const newId = Date.now()
      const newAddress = {
        id: newId,
        ...address,
        createdAt: new Date().toISOString()
      }
      // 如果设置为默认，则清除其他默认标记
      if (newAddress.isDefault === 1) {
        addresses.value.forEach(a => a.isDefault = 0)
      }
      addresses.value.push(newAddress)
      saveAddressesToLocal()
      ElMessage.success('地址添加成功（演示模式）')
      return true
    } catch (err) {
      ElMessage.error('添加失败')
      console.error(err)
      return false
    }
  }

  // 更新地址（完全前端模拟）
  const updateAddress = async (address) => {
    try {
      const index = addresses.value.findIndex(a => a.id === address.id)
      if (index !== -1) {
        // 如果设置为默认，则清除其他默认
        if (address.isDefault === 1) {
          addresses.value.forEach(a => a.isDefault = 0)
        }
        addresses.value[index] = { ...addresses.value[index], ...address }
        saveAddressesToLocal()
        ElMessage.success('地址更新成功（演示模式）')
        return true
      } else {
        throw new Error('地址不存在')
      }
    } catch (err) {
      ElMessage.error('更新失败')
      console.error(err)
      return false
    }
  }

  // 设置默认地址
  const setDefault = async (id) => {
    const index = addresses.value.findIndex(a => a.id === id)
    if (index !== -1) {
      addresses.value.forEach(a => a.isDefault = 0)
      addresses.value[index].isDefault = 1
      saveAddressesToLocal()
      ElMessage.success('设置成功')
    } else {
      ElMessage.error('地址不存在')
    }
  }

  // 删除地址
  const deleteAddress = async (id) => {
    try {
      await ElMessageBox.confirm('确认删除该地址？', '提示', { type: 'warning' })
      const index = addresses.value.findIndex(a => a.id === id)
      if (index !== -1) {
        addresses.value.splice(index, 1)
        // 如果删除了默认地址且还有剩余地址，将第一个设为默认
        if (addresses.value.length > 0 && !addresses.value.some(a => a.isDefault === 1)) {
          addresses.value[0].isDefault = 1
        }
        saveAddressesToLocal()
        ElMessage.success('删除成功（演示模式）')
      } else {
        ElMessage.warning('地址不存在')
      }
    } catch (err) {
      if (err !== 'cancel') {
        ElMessage.error('删除失败')
      }
    }
  }

  // 以下方法保持原有（关注、优惠券等真实接口）
  const loadFollowed = async () => {
    try {
      const res = await userApi.getFollowedSellers()
      followedSellers.value = Array.isArray(res.data) ? res.data : []
    } catch (err) {
      console.error('Load followed error:', err)
    }
  }

  const loadUserCoupons = async () => {
    try {
      const res = await userApi.getUserCoupons()
      userCoupons.value = Array.isArray(res.data) ? res.data : []
    } catch (err) {
      console.error('Load coupons error:', err)
    }
  }

  const unfollow = async (sellerId) => {
    try {
      await userApi.unfollowSeller(sellerId)
      ElMessage.success('已取消关注')
      await loadFollowed()
    } catch (err) {
      ElMessage.error('取消关注失败')
      console.error('Unfollow error:', err)
    }
  }

  const doSignIn = async () => {
    signInLoading.value = true
    try {
      const res = await userStore.signIn()
      ElMessage[res.success ? 'success' : 'warning'](res.message)
      await userStore.refreshUserInfo()
    } catch (err) {
      ElMessage.error('签到失败')
      console.error('Sign in error:', err)
    } finally {
      signInLoading.value = false
    }
  }

  const loadAll = async () => {
    // 地址直接从本地加载，不等待异步
    loadAddresses()
    // 其他真实数据仍从后端获取
    await Promise.all([loadFollowed(), loadUserCoupons()])
  }

  return {
    addresses,
    followedSellers,
    userCoupons,
    loading,
    error,
    levelName,
    signInLoading,
    addAddress,
    updateAddress,
    setDefault,
    deleteAddress,
    unfollow,
    doSignIn,
    loadAll
  }
}