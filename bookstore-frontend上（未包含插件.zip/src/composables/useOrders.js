import { ref } from 'vue'
import { useRouter } from 'vue-router'
import { orderApi } from '../api'
import { ElMessage, ElMessageBox } from 'element-plus'

export function useOrders(userStore) {
  const router = useRouter()
  const orders = ref([])
  const loading = ref(false)
  const error = ref(null)
  const currentPage = ref(1)
  const pageSize = ref(10)
  const total = ref(0)

  const statusMap = {
    0: { text: '待支付', type: 'warning' },
    1: { text: '已支付', type: 'success' },
    2: { text: '已取消', type: 'info' },
    3: { text: '已完成', type: 'success' }
  }

  const formatDate = (dateStr) => {
    if (!dateStr) return ''
    try {
      return new Date(dateStr).toLocaleString()
    } catch (e) {
      return dateStr
    }
  }

  const loadOrders = async (page = 1, status = null) => {
    if (!userStore.isLogin) {
      console.warn('未登录，不加载订单')
      return
    }
    loading.value = true
    error.value = null
    try {
      const res = await orderApi.getUserOrdersPage(page, pageSize.value, status)
      const pageData = res.data
      orders.value = (pageData.records || []).map(order => ({
        ...order,
        productTitle: order.productTitle || '商品信息加载中',
        productImageUrl: order.productImageUrl || '/default-cover.png',
        productCount: order.productCount || 1
      }))
      total.value = pageData.total || 0
      currentPage.value = pageData.current || 1
      pageSize.value = pageData.size || 10
      console.log('订单列表加载完成，共', total.value, '条')
    } catch (err) {
      console.error('加载订单失败:', err)
      error.value = '加载订单失败，请刷新页面'
      ElMessage.error('加载订单失败')
    } finally {
      loading.value = false
    }
  }

  const payOrder = async (orderId) => {
    try {
      await ElMessageBox.confirm('确认支付该订单吗？', '提示', { type: 'info' })
      await orderApi.pay(orderId)
      ElMessage.success('支付成功')
      return true
    } catch (err) {
      if (err !== 'cancel') {
        ElMessage.error(err.response?.data?.message || '支付失败')
      }
      return false
    }
  }

  const cancelOrder = async (orderId) => {
    try {
      await ElMessageBox.confirm('确认取消订单吗？', '提示', { type: 'warning' })
      await orderApi.cancel(orderId)
      ElMessage.success('订单已取消')
      return true
    } catch (err) {
      if (err !== 'cancel') {
        ElMessage.error(err.response?.data?.message || '取消失败')
      }
      return false
    }
  }

  const viewOrderDetail = (orderId) => {
    router.push(`/orders/${orderId}`)
  }

  return {
    orders,
    loading,
    error,
    currentPage,
    pageSize,
    total,
    statusMap,
    loadOrders,
    payOrder,
    cancelOrder,
    formatDate,
    viewOrderDetail
  }
}