import { ref, computed, watch } from 'vue'
import { userApi, orderApi, bookApi } from '../api'
import { ElMessage } from 'element-plus'

// 本地地址存储 key（与 useProfile 保持一致）
const ADDRESS_STORAGE_KEY = 'user_addresses'

export function useCartCheckout(cartStore, userStore, router) {
  const usePoints = ref(false)
  const pointsToUse = ref(0)
  const selectedAddressId = ref(null)
  const selectedCouponId = ref(null)
  const addresses = ref([])
  const userCoupons = ref([])
  const ordering = ref(false)
  const loading = ref(false)
  const error = ref(null)

  const needAddress = computed(() => cartStore.items.some(i => i.type === 2))
  const selectedCoupon = computed(() => userCoupons.value.find(c => c.couponId === selectedCouponId.value))
  const couponDiscount = computed(() => selectedCoupon.value?.discountAmount || 0)
  const totalAfterCoupon = computed(() => Math.max(0, cartStore.totalPrice - couponDiscount.value))
  const maxUsablePoints = computed(() => {
    const maxByPoints = userStore.user?.points || 0
    const maxByAmount = Math.floor(totalAfterCoupon.value)
    return Math.min(maxByPoints, maxByAmount)
  })

  const finalAmount = computed(() => {
    let total = totalAfterCoupon.value
    if (usePoints.value) total -= pointsToUse.value
    return Math.max(0, total)
  })

  watch([usePoints, maxUsablePoints, () => pointsToUse.value], () => {
    if (usePoints.value && pointsToUse.value > maxUsablePoints.value) {
      pointsToUse.value = maxUsablePoints.value
    }
  })

  // 从 localStorage 加载地址（与个人中心共享）
  const loadAddresses = () => {
    const stored = localStorage.getItem(ADDRESS_STORAGE_KEY)
    if (stored) {
      try {
        addresses.value = JSON.parse(stored)
      } catch (e) {
        addresses.value = []
      }
    } else {
      // 如果没有地址数据，初始化示例地址
      addresses.value = [
        {
          id: 1,
          userId: userStore.user?.id,
          receiverName: '张三',
          phone: '13800138001',
          province: '北京市',
          city: '北京市',
          district: '朝阳区',
          detail: '建国路1号',
          isDefault: 1,
          createdAt: new Date().toISOString()
        },
        {
          id: 2,
          userId: userStore.user?.id,
          receiverName: '李四',
          phone: '13800138002',
          province: '上海市',
          city: '上海市',
          district: '浦东新区',
          detail: '世纪大道100号',
          isDefault: 0,
          createdAt: new Date().toISOString()
        }
      ]
      localStorage.setItem(ADDRESS_STORAGE_KEY, JSON.stringify(addresses.value))
    }
    // 自动选中默认地址
    if (addresses.value.length && !selectedAddressId.value) {
      const defaultAddr = addresses.value.find(a => a.isDefault === 1)
      if (defaultAddr) selectedAddressId.value = defaultAddr.id
      else selectedAddressId.value = addresses.value[0].id
    }
  }

  const loadUserCoupons = async () => {
    if (!userStore.isLogin) return
    try {
      const res = await userApi.getUserCoupons()
      userCoupons.value = res.data
    } catch (err) {
      console.error('Load coupons error:', err)
    }
  }

  const updateCount = (item) => {
    cartStore.updateCount(item.id, item.count)
  }

  const generateIdempotentToken = () => {
    return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function(c) {
      const r = Math.random() * 16 | 0, v = c === 'x' ? r : (r & 0x3 | 0x8)
      return v.toString(16)
    })
  }

  const createOrder = async () => {
    if (cartStore.items.length === 0) {
      ElMessage.warning('购物车为空')
      return
    }

    ordering.value = true
    try {
      // 1. 从后端获取最新价格和库存
      const updatedItems = []
      for (const item of cartStore.items) {
        try {
          const res = await bookApi.getById(item.id)
          const latest = res.data
          item.price = latest.price
          item.stock = latest.stock
          if (item.type === 2 && latest.stock < item.count) {
            ElMessage.warning(`《${item.title}》库存不足，当前仅剩 ${latest.stock} 件`)
            return
          }
          updatedItems.push({
            productId: item.id,
            count: item.count,
            price: latest.price,
            orderType: item.type
          })
        } catch (err) {
          ElMessage.error(`获取商品 ${item.title} 信息失败，请稍后重试`)
          return
        }
      }

      if (needAddress.value && !selectedAddressId.value) {
        ElMessage.warning('请选择收货地址')
        return
      }

      if (usePoints.value && pointsToUse.value > (userStore.user?.points || 0)) {
        ElMessage.warning('积分不足')
        return
      }
      if (usePoints.value && pointsToUse.value > totalAfterCoupon.value) {
        ElMessage.warning('积分抵扣不能超过订单应付金额')
        return
      }

      const orderRequest = {
        userId: userStore.user.id,
        items: updatedItems,
        pointsUsed: usePoints.value ? pointsToUse.value : 0,
        addressId: needAddress.value ? selectedAddressId.value : null,
        orderType: needAddress.value ? 2 : 1,
        couponId: selectedCouponId.value || null,
        totalAmount: cartStore.totalPrice,
        totalCount: cartStore.totalCount,
        idempotentToken: generateIdempotentToken()
      }

      const response = await orderApi.create(orderRequest)
      console.log('下单成功，订单ID:', response.data)

      // 构造本地订单对象（存储到 localStorage）
      const firstItem = cartStore.items[0]
      const localOrder = {
        id: response.data,
        userId: userStore.user.id,
        amount: cartStore.totalPrice,
        actualPaid: finalAmount.value,
        status: 0,
        createTime: new Date().toISOString(),
        orderType: needAddress.value ? 2 : 1,
        deliveryStatus: 0,
        productTitle: firstItem?.title || '商品',
        productImageUrl: firstItem?.imageUrl || '/default-cover.png',
        productCount: cartStore.totalCount,
        sellerName: '平台自营',
        items: updatedItems.map(item => {
          const cartItem = cartStore.items.find(i => i.id === item.productId)
          return {
            productId: item.productId,
            productTitle: cartItem?.title || '商品',
            productImageUrl: cartItem?.imageUrl || '/default-cover.png',
            count: item.count,
            price: item.price,
            subtotal: item.price * item.count,
            orderType: item.orderType
          }
        })
      }

      let orders = []
      const storedOrders = localStorage.getItem('my_orders')
      if (storedOrders) {
        try { orders = JSON.parse(storedOrders) } catch(e) {}
      }
      orders.unshift(localOrder)
      localStorage.setItem('my_orders', JSON.stringify(orders))

      await cartStore.clear()
      ElMessage.success('下单成功！正在跳转到订单列表...')
      router.push('/orders')
    } catch (err) {
      console.error('下单失败:', err)
      let errorMsg = err.response?.data?.message || err.message || '下单失败'
      if (errorMsg.includes('价格已变更')) {
        errorMsg = '商品价格已更新，请刷新购物车后重试'
      }
      ElMessage.error(errorMsg)
    } finally {
      ordering.value = false
    }
  }

  const loadAll = async () => {
    loadAddresses()           // 加载本地地址
    await loadUserCoupons()   // 加载优惠券（真实接口）
  }

  return {
    usePoints,
    pointsToUse,
    selectedAddressId,
    selectedCouponId,
    addresses,
    userCoupons,
    ordering,
    loading,
    error,
    needAddress,
    couponDiscount,
    finalAmount,
    maxUsablePoints,
    loadAddresses,
    loadUserCoupons,
    updateCount,
    createOrder,
    loadAll
  }
}