import { ref, computed } from 'vue'
import { bookApi, userApi, orderApi } from '../api'
import { ElMessage } from 'element-plus'

export function useBookDetail(userStore, cartStore, router) {
  const book = ref({})
  const count = ref(1)
  const hasPurchased = ref(false)
  const reviews = ref([])
  const newRating = ref(5)
  const newComment = ref('')
  const reviewPage = ref(1)
  const reviewPageSize = ref(5)
  const reviewTotal = ref(0)
  const sellerName = ref('')
  const isFollowing = ref(false)
  const loading = ref(false)
  const reviewsLoading = ref(false)
  const error = ref(null)
  const deletingReviewId = ref(null)

  const canDownload = computed(() => book.value.type === 1 && hasPurchased.value)
  const isOutOfStock = computed(() => book.value.type === 2 && book.value.stock <= 0)

  const loadBook = async (id) => {
    loading.value = true
    error.value = null
    try {
      const res = await bookApi.getById(id)
      book.value = res.data

      if (book.value.sellerId && book.value.sellerId !== 0) {
        try {
          const userRes = await userApi.getInfo(book.value.sellerId)
          sellerName.value = userRes.data.username
          if (userStore.isLogin) {
            const follows = await userApi.getFollowedSellers()
            isFollowing.value = follows.data.includes(book.value.sellerId)
          }
        } catch (err) {
          console.error('Load seller info error:', err)
        }
      }

      if (userStore.isLogin) {
        try {
          const orders = await orderApi.getUserOrders(userStore.user.id)
          hasPurchased.value = orders.data.some(o => o.productId == id && o.status === 1)
        } catch (err) {
          console.error('Check purchase error:', err)
        }
      }
    } catch (err) {
      error.value = '加载图书详情失败'
      console.error('Load book error:', err)
    } finally {
      loading.value = false
    }
  }

  const loadReviews = async () => {
    if (!book.value.id) return
    reviewsLoading.value = true
    try {
      const res = await bookApi.getReviews(book.value.id, reviewPage.value, reviewPageSize.value)
      reviews.value = res.data.records || res.data
      reviewTotal.value = res.data.total || reviews.value.length
    } catch (err) {
      console.error('Load reviews error:', err)
    } finally {
      reviewsLoading.value = false
    }
  }

  const submitReview = async () => {
    if (!userStore.isLogin) {
      ElMessage.warning('请先登录')
      router.push('/login')
      return
    }
    if (!newComment.value.trim()) {
      ElMessage.warning('请输入评论内容')
      return
    }
    try {
      await bookApi.addReview({
        bookId: book.value.id,
        rating: newRating.value,
        content: newComment.value.trim(),
        comment: newComment.value.trim()
      })
      ElMessage.success('评论成功')
      newComment.value = ''
      newRating.value = 5
      await loadReviews()
    } catch (err) {
      ElMessage.error(err.response?.data?.message || '评论失败')
      console.error('Submit review error:', err)
    }
  }

  // 【修改】删除评论：后端可能未实现，前端本地移除 + 提示
  const deleteReview = async (reviewId) => {
    if (!userStore.isLogin) return
    deletingReviewId.value = reviewId
    try {
      // 尝试调用后端（如果后端未实现，会报错但不影响前端体验）
      await bookApi.deleteReview(reviewId).catch(() => {})
      // 前端本地删除
      const index = reviews.value.findIndex(r => r.id === reviewId)
      if (index !== -1) {
        reviews.value.splice(index, 1)
        reviewTotal.value -= 1
      }
      ElMessage.success('评论已从列表移除（演示模式，数据库未实际删除）')
    } catch (err) {
      // 即使后端失败，也移除前端评论并提示
      const index = reviews.value.findIndex(r => r.id === reviewId)
      if (index !== -1) {
        reviews.value.splice(index, 1)
        reviewTotal.value -= 1
      }
      ElMessage.warning('后端删除接口未实现，已从本地移除')
    } finally {
      deletingReviewId.value = null
    }
  }

  const addToCart = () => {
    if (isOutOfStock.value) {
      ElMessage.warning('商品已售罄')
      return
    }
    cartStore.addItem({ ...book.value, count: count.value })
    ElMessage.success('已加入购物车')
  }

  const buyNow = () => {
    if (isOutOfStock.value) {
      ElMessage.warning('商品已售罄')
      return
    }
    router.push({
      path: '/cart',
      query: { buyNow: JSON.stringify({ ...book.value, count: count.value }) }
    })
  }

  // 【修改】电子书下载：后端返回重定向，直接使用 window.open
  const downloadEBook = async () => {
    if (!canDownload.value) return
    // 后端接口会重定向到文件真实 URL，直接用 window.open 即可
    window.open(`/api/book/download/${book.value.id}`, '_blank')
    ElMessage.success('下载已开始，请检查浏览器下载列表')
  }

  const followSeller = async (sellerId) => {
    if (!userStore.isLogin) {
      ElMessage.warning('请先登录')
      router.push('/login')
      return
    }
    try {
      await userApi.followSeller(sellerId)
      ElMessage.success('关注成功')
      isFollowing.value = true
    } catch (err) {
      ElMessage.error('关注失败')
      console.error('Follow seller error:', err)
    }
  }

  const formatDate = (d) => d ? new Date(d).toLocaleString() : ''

  return {
    book,
    count,
    hasPurchased,
    reviews,
    newRating,
    newComment,
    reviewPage,
    reviewPageSize,
    reviewTotal,
    sellerName,
    isFollowing,
    loading,
    reviewsLoading,
    error,
    canDownload,
    isOutOfStock,
    loadBook,
    loadReviews,
    submitReview,
    deleteReview,
    deletingReviewId,
    addToCart,
    buyNow,
    downloadEBook,
    followSeller,
    formatDate
  }
}