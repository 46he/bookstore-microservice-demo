import { ref } from 'vue'
import { userApi } from '../api'
import { ElMessage } from 'element-plus'

export function useAuth(userStore, router) {
  const formRef = ref()
  const loading = ref(false)
  const form = ref({
    username: '',
    password: ''
  })

  const rules = {
    username: [
      { required: true, message: '请输入用户名', trigger: 'blur' },
      { min: 3, max: 20, message: '用户名长度在 3 到 20 个字符', trigger: 'blur' }
    ],
    password: [
      { required: true, message: '请输入密码', trigger: 'blur' },
      { min: 6, message: '密码至少6位', trigger: 'blur' }
    ]
  }

  const login = async () => {
    try {
      await formRef.value.validate()
      loading.value = true

      // 调用登录接口
      const res = await userApi.login(form.value)

      // 响应拦截器已经处理了错误和数据结构，成功时 res.data 就是 { token, userId, username, points }
      // 注意：根据你的后端实际返回，可能需要调整字段名
      const { token, userId, username, points } = res.data

      // 保存用户信息到 store
      userStore.setAuth(token, {
        id: userId,
        username: username,
        points: points || 0
      })

      ElMessage.success('登录成功')
      router.push('/')
    } catch (err) {
      const message = err.response?.data?.message || '登录失败，请检查用户名和密码'
      ElMessage.error(message)
      console.error('Login error:', err)
    } finally {
      loading.value = false
    }
  }

  const register = async () => {
    try {
      await formRef.value.validate()
      loading.value = true

      const res = await userApi.register(form.value)

      ElMessage.success(res.data?.message || '注册成功')
      router.push('/login')
    } catch (err) {
      const message = err.response?.data?.message || '注册失败'
      ElMessage.error(message)
      console.error('Register error:', err)
    } finally {
      loading.value = false
    }
  }

  return {
    formRef,
    loading,
    form,
    rules,
    login,
    register
  }
}