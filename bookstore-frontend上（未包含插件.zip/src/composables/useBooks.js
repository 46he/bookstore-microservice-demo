import { ref, computed } from 'vue'
import { bookApi } from '../api'

// 手动实现一个简单的 debounce 函数
function debounce(fn, delay) {
  let timer = null
  return function (...args) {
    if (timer) clearTimeout(timer)
    timer = setTimeout(() => {
      fn.apply(this, args)
    }, delay)
  }
}

export function useBooks() {
  const books = ref([])
  const total = ref(0)
  const pageNum = ref(1)
  const pageSize = ref(12)
  const keyword = ref('')
  const currentCategory = ref('')
  const loading = ref(false)
  const error = ref(null)
  const cache = new Map()
  const searchHistory = ref(JSON.parse(localStorage.getItem('bookSearchHistory') || '[]'))

  const cacheKey = computed(() => `${pageNum.value}-${pageSize.value}-${keyword.value}-${currentCategory.value}`)

  const loadBooks = async () => {
    const key = cacheKey.value
    if (cache.has(key)) {
      books.value = cache.get(key).records
      total.value = cache.get(key).total
      return
    }

    loading.value = true
    error.value = null
    try {
      const res = await bookApi.search({
        pageNum: pageNum.value,
        pageSize: pageSize.value,
        keyword: keyword.value,
        category: currentCategory.value
      })
      books.value = res.data.records || []
      total.value = res.data.total || 0
      pageNum.value = res.data.current || 1
      pageSize.value = res.data.size || 12
      cache.set(key, { records: books.value, total: total.value })
    } catch (err) {
      error.value = '加载图书失败，请稍后重试'
      console.error('Load books error:', err)
    } finally {
      loading.value = false
    }
  }

  const searchBooks = debounce(() => {
    if (keyword.value.trim()) {
      addToSearchHistory(keyword.value.trim())
    }
    pageNum.value = 1
    loadBooks()
  }, 300)

  const addToSearchHistory = (searchTerm) => {
    const history = searchHistory.value
    const index = history.indexOf(searchTerm)
    if (index > -1) {
      history.splice(index, 1)
    }
    history.unshift(searchTerm)
    if (history.length > 10) {
      history.splice(10)
    }
    searchHistory.value = history
    localStorage.setItem('bookSearchHistory', JSON.stringify(history))
  }

  const clearSearchHistory = () => {
    searchHistory.value = []
    localStorage.removeItem('bookSearchHistory')
  }

  const removeFromHistory = (term) => {
    const index = searchHistory.value.indexOf(term)
    if (index > -1) {
      searchHistory.value.splice(index, 1)
      localStorage.setItem('bookSearchHistory', JSON.stringify(searchHistory.value))
    }
  }

  const filterByCategory = () => {
    pageNum.value = 1
    loadBooks()
  }

  const resetSearch = () => {
    keyword.value = ''
    currentCategory.value = ''
    pageNum.value = 1
    loadBooks()
  }

  return {
    books,
    total,
    pageNum,
    pageSize,
    keyword,
    currentCategory,
    loading,
    error,
    searchHistory,
    loadBooks,
    searchBooks,
    filterByCategory,
    resetSearch,
    clearSearchHistory,
    removeFromHistory
  }
}