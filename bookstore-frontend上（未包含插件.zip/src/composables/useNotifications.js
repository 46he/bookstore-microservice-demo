import { ref } from 'vue'
import { userApi } from '../api'

export function useNotifications() {
  const notifications = ref([])
  const unreadCount = ref(0)
  const loading = ref(false)
  const error = ref(null)
  let timer

  // 加载通知（从后端获取最新数据）
  const loadNotifications = async () => {
    if (loading.value) return
    loading.value = true
    error.value = null
    try {
      // 获取所有通知（不传参数或传 false）
      const res = await userApi.getNotifications(false)
      let data = res.data || []
      // 确保每条通知有 isRead 字段（可能后端返回的是 0/1 或 boolean）
      notifications.value = data.map(n => ({
        ...n,
        isRead: n.isRead === 1 || n.isRead === true ? 1 : 0
      }))
      // 计算未读数量
      unreadCount.value = notifications.value.filter(n => n.isRead === 0).length
    } catch (err) {
      error.value = '加载通知失败，请稍后重试'
      console.error('Notification load error:', err)
    } finally {
      loading.value = false
    }
  }

  // 标记单条已读
  const markRead = async (id) => {
    try {
      await userApi.markNotificationRead(id)
    } catch (err) {
      console.error('Mark read error:', err)
    }
    // 无论后端是否成功，前端立即更新
    const idx = notifications.value.findIndex(n => n.id === id)
    if (idx !== -1 && notifications.value[idx].isRead === 0) {
      notifications.value[idx].isRead = 1
      unreadCount.value = Math.max(0, unreadCount.value - 1)
    }
  }

  // 全部标记已读
  const markAllRead = async () => {
    try {
      const unreadIds = notifications.value.filter(n => n.isRead === 0).map(n => n.id)
      for (const id of unreadIds) {
        await userApi.markNotificationRead(id)
      }
    } catch (err) {
      console.error('Mark all read error:', err)
    }
    // 前端直接全部标为已读
    notifications.value.forEach(n => { n.isRead = 1 })
    unreadCount.value = 0
  }

  const formatTime = (dateStr) => {
    if (!dateStr) return ''
    try {
      return new Date(dateStr).toLocaleString()
    } catch (e) {
      return dateStr
    }
  }

  const startPolling = () => {
    loadNotifications()
    timer = setInterval(loadNotifications, 30000)
  }

  const stopPolling = () => {
    if (timer) clearInterval(timer)
  }

  return {
    notifications,
    unreadCount,
    loading,
    error,
    loadNotifications,
    markRead,
    markAllRead,
    formatTime,
    startPolling,
    stopPolling
  }
}