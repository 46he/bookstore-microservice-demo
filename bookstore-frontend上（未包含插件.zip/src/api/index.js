import axios from 'axios'

const api = axios.create({
  baseURL: import.meta.env.VITE_API_BASE_URL || '/api',
  timeout: 30000
})

const storedToken = localStorage.getItem('token')
if (storedToken) {
  api.defaults.headers.common['Authorization'] = `Bearer ${storedToken}`
}

api.interceptors.request.use(config => {
  const token = localStorage.getItem('token')
  if (token) config.headers.Authorization = `Bearer ${token}`
  if (config.data && typeof config.data === 'object') {
    validateRequestData(config.data)
  }
  return config
})

api.interceptors.response.use(
  res => {
    if (res.data && typeof res.data === 'object' && 'success' in res.data) {
      if (!res.data.success) {
        const error = new Error(res.data.message || '请求失败')
        error.response = { data: res.data, status: res.data.code || 400 }
        return Promise.reject(error)
      }
      return { ...res, data: res.data.data }
    }
    return res
  },
  err => {
    if (err.response?.status === 401) {
      localStorage.removeItem('token')
      localStorage.removeItem('user')
      delete api.defaults.headers.common['Authorization']
      window.location.href = '/login'
    } else if (err.response?.status === 400) {
      console.error('请求参数错误:', err.response.data)
    } else if (err.response?.status >= 500) {
      console.error('服务器错误:', err.response.data)
    }
    return Promise.reject(err)
  }
)

function validateRequestData(data) {
  for (const key in data) {
    if (typeof data[key] === 'string') {
      if (data[key].includes('<script>') || data[key].includes('javascript:')) {
        throw new Error('检测到潜在的安全威胁')
      }
    }
  }
}

export const userApi = {
  login: (data) => {
    if (!data.username || !data.password) throw new Error('用户名和密码不能为空')
    return api.post('/users/login', data)
  },
  register: (data) => {
    if (!data.username || !data.password || !data.email) throw new Error('请填写完整信息')
    return api.post('/users/register', data)
  },
  logout: () => {
    return api.post('/users/logout')
  },
  getInfo: (id) => {
    if (!id) throw new Error('用户ID不能为空')
    return api.get(`/users/${id}`)
  },
  getLevel: (userId) => api.get(`/users/level/${userId}`),
  getAddresses: (userId) => api.get(`/users/${userId}/addresses`),
  addAddress: (data) => {
    if (!data.receiverName || !data.phone || !data.detail) throw new Error('收货信息不完整')
    return api.post('/users/address', data)
  },
  // 新增：更新地址（需要后端支持 PUT /users/address）
  updateAddress: (data) => {
    if (!data.id) throw new Error('地址ID不能为空')
    return api.put('/users/address', data)
  },
  setDefaultAddress: (id) => api.put(`/users/address/${id}/default`),
  deleteAddress: (id) => api.delete(`/users/address/${id}`),
  signIn: () => api.post('/users/points/sign'),
  getPointsBalance: () => api.get('/users/points/balance'),
  getTodaySignStatus: () => api.get('/users/points/today-signed'),
  exchangeCoupon: (couponId) => {
    if (!couponId) throw new Error('优惠券ID不能为空')
    return api.post(`/users/coupon/exchange?couponId=${couponId}`)
  },
  getUserCoupons: () => api.get('/users/coupon/list'),
  getCouponTemplates: () => api.get('/users/coupon/templates'),
  getCurrentUser: () => api.get('/users/me'),
  followSeller: (sellerId) => api.post(`/users/follow?sellerId=${sellerId}`),
  unfollowSeller: (sellerId) => api.post(`/users/unfollow?sellerId=${sellerId}`),
  getFollowedSellers: () => api.get('/users/follow/list'),
  getNotifications: (unreadOnly = false) => api.get(`/users/notifications?unreadOnly=${unreadOnly}`),
  markNotificationRead: (id) => api.post(`/users/notification/read/${id}`),
  notifyOrder: (userId, orderId, type, content) => api.post('/users/notify/order', { userId, orderId, type, content }),
  notifyPoints: (userId, points, reason) => api.post('/users/notify/points', { userId, points, reason }),
  notifyCouponExpire: (userId, couponName, expireDate) => api.post('/users/notify/coupon-expire', { userId, couponName, expireDate }),
  notifyNewBook: (sellerId, bookTitle) => api.post('/users/notify/newbook', { sellerId, bookTitle }),
  notifySystem: (content) => api.post('/users/notify/system', { content }),
  addToCart: (bookId, count = 1) => api.post(`/cart/add?bookId=${bookId}&count=${count}`),
  removeFromCart: (bookId) => api.delete(`/cart/remove/${bookId}`),
  updateCartItem: (bookId, count) => api.put(`/cart/update?bookId=${bookId}&count=${count}`),
  clearCart: () => api.delete('/cart/clear'),
  getCartItems: () => api.get('/cart/items'),
  getCartItemCount: () => api.get('/cart/count'),
  validateCartItems: () => api.get('/cart/validate'),
}

export const bookApi = {
  getById: async (id) => {
    if (!id) throw new Error('图书ID不能为空')
    const res = await api.get(`/book/${id}`)
    if (res.data) {
      if (res.data.stock !== undefined) res.data.stock = Number(res.data.stock)
      if (res.data.price !== undefined) res.data.price = Number(res.data.price)
    }
    return res
  },
  search: (params) => api.get('/book/search', { 
    params: {
      page: params.pageNum,
      size: params.pageSize,
      keyword: params.keyword,
      category: params.category,
      type: params.type
    }
  }),
  getHotBooks: (limit = 10) => api.get(`/book/hot?limit=${limit}`),
  getRecommendations: (browsedIds) => {
    if (!Array.isArray(browsedIds) || browsedIds.length === 0) throw new Error('浏览记录不能为空')
    return api.post('/book/recommend', browsedIds)
  },
  recordBrowse: (bookId) => api.post(`/book/browse?bookId=${bookId}`),
  addReview: (data) => {
    if (!data.bookId || !data.rating || !data.content) throw new Error('评论信息不完整')
    return api.post('/book/review', data)
  },
  getReviews: (bookId, page, size) => api.get(`/book/${bookId}/reviews?page=${page}&size=${size}`),
  getRating: (bookId) => api.get(`/book/${bookId}/rating`),
  getSellerBooks: (sellerId) => api.get(`/book/seller/${sellerId}`),
  getSellerInventory: (sellerId) => api.get(`/book/seller/${sellerId}/inventory`),
  sellBook: (data) => {
    if (!data.title || !data.price || !data.stock) throw new Error('图书信息不完整')
    return api.post('/book/sell', data)
  },
  offShelf: (id) => api.post(`/book/sell/${id}/off`),
  onShelf: (id) => api.post(`/book/sell/${id}/on`),
  updateStock: (id, stock) => api.post(`/book/sell/${id}/stock`, null, { params: { stock } }),
  downloadEBook: (bookId) => api.get(`/book/download/${bookId}`, { responseType: 'blob' }),
  getPointsBooks: () => api.get('/book/pointsBooks'),
  uploadFile: (formData) => {
    const file = formData.get('file')
    if (file) {
      const allowedTypes = ['application/pdf', 'text/plain', 'application/epub+zip']
      if (!allowedTypes.includes(file.type)) {
        throw new Error('文件类型不支持，仅支持 PDF、TXT、EPUB')
      }
      if (file.size > 10 * 1024 * 1024) {
        throw new Error('文件大小超过限制（10MB）')
      }
    }
    return api.post('/book/uploadFile', formData)
  },
  deleteReview: (reviewId) => {
    console.warn('删除评论接口后端未实现，模拟操作')
    return Promise.resolve({ data: { success: true, message: '模拟删除成功' } })
  },
}

export const orderApi = {
  create: (data) => api.post('/order/create', data),
  getUserOrders: (userId, page = 1, size = 10) => api.get(`/order/user/${userId}?page=${page}&size=${size}`),
  getUserOrdersPage: (page = 1, size = 10, status) => {
    const params = { page, size };
    if (status !== undefined && status !== null) params.status = status;
    return api.get('/order/user/page', { params });
  },
  getOrderDetail: (orderId) => api.get(`/order/${orderId}/detail`),
  pay: (orderId) => api.post(`/order/pay/${orderId}`),
  cancel: (orderId) => api.post(`/order/cancel/${orderId}`),
  deliver: (orderId, expressCompany, trackingNo) => api.post(`/order/deliver/${orderId}?expressCompany=${expressCompany}&trackingNo=${trackingNo}`),
  confirmReceipt: (orderId) => api.post(`/order/confirm/${orderId}`),
  getLogistics: (logisticsId) => api.get(`/order/logistics/${logisticsId}`),
  getSellerStatistics: (period = 'week') => api.get(`/order/seller/statistics?period=${period}`),
}

export default api