import axios from 'axios'
import { ElMessage } from 'element-plus'

// 创建请求实例
const request = axios.create({
  baseURL: import.meta.env.VITE_API_BASE_URL || '/api',
  timeout: 15000,
  headers: {
    'Content-Type': 'application/json'
  }
})

// 请求重试配置
const RETRY_CONFIG = {
  maxRetries: 3,
  retryDelay: 1000,
  retryCondition: (error) => {
    return (
      !error.response ||
      error.response.status >= 500 ||
      error.code === 'ECONNABORTED'
    )
  }
}

// 请求取消管理
const pendingRequests = new Map()

const generateRequestKey = (config) => {
  return `${config.method?.toUpperCase()}_${config.url}_${JSON.stringify(config.params)}_${JSON.stringify(config.data)}`
}

const removePendingRequest = (key) => {
  const cancel = pendingRequests.get(key)
  if (cancel) {
    cancel()
    pendingRequests.delete(key)
  }
}

const addPendingRequest = (config) => {
  const key = generateRequestKey(config)
  removePendingRequest(key)

  const cancelToken = axios.CancelToken.source()
  config.cancelToken = cancelToken.token

  pendingRequests.set(key, () => {
    cancelToken.cancel('Request cancelled by user')
  })
}

request.interceptors.request.use(
  config => {
    if (!config.skipCancel) {
      addPendingRequest(config)
    }

    const token = localStorage.getItem('token')
    if (token) {
      config.headers.Authorization = `Bearer ${token}`
    }

    if (config.method?.toUpperCase() === 'GET') {
      config.params = {
        ...config.params,
        _t: Date.now()
      }
    }

    config.metadata = {
      requestId: Math.random().toString(36).substr(2, 9),
      startTime: Date.now()
    }

    return config
  },
  error => {
    console.error('Request interceptor error:', error)
    return Promise.reject(error)
  }
)

request.interceptors.response.use(
  response => {
    const key = generateRequestKey(response.config)
    removePendingRequest(key)

    const duration = Date.now() - response.config.metadata.startTime
    console.log(`Request ${response.config.metadata.requestId} completed in ${duration}ms`)

    const { data } = response
    if (data && typeof data === 'object') {
      if (data.code !== undefined && data.code !== 200 && data.code !== 0) {
        const error = new Error(data.message || '请求失败')
        error.code = data.code
        error.response = response
        return Promise.reject(error)
      }
    }

    return response
  },
  async error => {
    const config = error.config
    const key = generateRequestKey(config)
    removePendingRequest(key)

    if (axios.isCancel(error)) {
      return Promise.reject(error)
    }

    config.__retryCount = config.__retryCount || 0

    if (
      config.__retryCount < RETRY_CONFIG.maxRetries &&
      RETRY_CONFIG.retryCondition(error)
    ) {
      config.__retryCount += 1
      console.warn(`Retrying request ${config.metadata?.requestId} (${config.__retryCount}/${RETRY_CONFIG.maxRetries})`)
      await new Promise(resolve => setTimeout(resolve, RETRY_CONFIG.retryDelay * config.__retryCount))
      return request(config)
    }

    let errorMessage = '网络请求失败，请稍后重试'

    if (error.response) {
      const { status, data } = error.response

      switch (status) {
        case 400:
          errorMessage = data?.message || '请求参数错误'
          break
        case 401:
          errorMessage = '登录已过期，请重新登录'
          localStorage.removeItem('token')
          localStorage.removeItem('remember_username')
          setTimeout(() => {
            window.location.href = '/login'
          }, 1500)
          break
        case 403:
          errorMessage = '权限不足'
          break
        case 404:
          errorMessage = '请求的资源不存在'
          break
        case 422:
          errorMessage = data?.message || '数据验证失败'
          break
        case 429:   // 【新增】限流友好提示
          errorMessage = '请求过于频繁，请稍后再试（后端限流已触发）'
          break
        case 500:
          errorMessage = '服务器内部错误'
          break
        case 502:
        case 503:
        case 504:
          errorMessage = '服务器暂时不可用'
          break
        default:
          errorMessage = `请求失败 (${status})`
      }
    } else if (error.code === 'ECONNABORTED') {
      errorMessage = '请求超时，请检查网络连接'
    } else if (!navigator.onLine) {
      errorMessage = '网络连接已断开'
    }

    if (!config.skipErrorMessage) {
      ElMessage.error(errorMessage)
    }

    console.error('API Error:', {
      url: config.url,
      method: config.method,
      status: error.response?.status,
      message: errorMessage,
      requestId: config.metadata?.requestId
    })

    return Promise.reject({
      ...error,
      message: errorMessage,
      code: error.response?.status || error.code
    })
  }
)

export const cancelAllRequests = () => {
  pendingRequests.forEach(cancel => cancel())
  pendingRequests.clear()
}

export const createCancelableRequest = () => {
  const cancelToken = axios.CancelToken.source()
  return {
    cancel: cancelToken.cancel,
    request: (config) => {
      return request({
        ...config,
        cancelToken: cancelToken.token
      })
    }
  }
}

export default request