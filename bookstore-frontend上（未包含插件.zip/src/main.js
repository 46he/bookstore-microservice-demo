import { createApp } from 'vue'
import { createPinia } from 'pinia'
import ElementPlus from 'element-plus'
import 'element-plus/dist/index.css'
import zhCn from 'element-plus/dist/locale/zh-cn.mjs'
import router from './router'
import App from './App.vue'
import { useUserStore } from './stores/user'
import { useCartStore } from './stores/cart'
import api from './api'

// 创建应用实例
const app = createApp(App)

// 使用插件
app.use(createPinia())
app.use(router)
app.use(ElementPlus, { locale: zhCn })

// 获取store实例
const userStore = useUserStore()
const cartStore = useCartStore()

// 全局错误处理
app.config.errorHandler = (err, instance, info) => {
  console.error('Global error:', err, info)
  // 可以在这里发送错误报告到服务器
}

// 全局警告处理
app.config.warnHandler = (warn, instance, trace) => {
  console.warn('Global warning:', warn, trace)
}

// 初始化应用状态
const initializeApp = async () => {
  try {
    // 初始化用户认证状态
    await userStore.initializeAuth()

    // 如果用户已登录，从后端加载购物车数据
    if (userStore.isLogin) {
      await cartStore.loadFromBackend()
    } else {
      // 验证本地购物车商品有效性
      cartStore.validateItems()
    }

    console.log('App initialized successfully')
  } catch (error) {
    console.error('App initialization error:', error)
  }
}

// 挂载应用
app.mount('#app')

// 初始化应用
initializeApp()

// 导出应用实例（可选，用于调试）
if (import.meta.env.DEV) {
  window.app = app
  window.userStore = userStore
  window.cartStore = cartStore
  window.api = api
}