import { defineConfig } from 'vite'
import vue from '@vitejs/plugin-vue'

export default defineConfig({
  plugins: [vue()],
  server: {
    port: 5173,
    proxy: {
      '/api': {
        target: 'http://localhost:8080',//8080:微服务,8085:单体
        changeOrigin: true
      },
      // 新增：将 /ebooks 请求代理到 book-service 的 8082 端口（避免嵌套）
      '/ebooks': {
        target: 'http://localhost:8082',
        changeOrigin: true
      }
    }
  }
})